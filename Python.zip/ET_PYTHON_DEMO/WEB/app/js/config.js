// const baseUrl = "http://localhost:8084/ET-PHP-Demo/API_SERVER";
const baseUrl = "http://localhost:8080";

const merchantAppId = "850259476582401";
