const priceList = [100, 20, 50, 100, 200, 500, 1000];

let price = 120;

function selectProduct(itemIndex) {
  // reset all item style
  let selectItems = document.getElementsByClassName("per-act");
  if (selectItems.length > 0) {
    for (let i = 0; i < selectItems.length; i++) {
      selectItems[i].setAttribute("class", "per perb");
    }
  }

  // set current selected item style
  let productList = document.getElementById("product_list");
  productList.children[itemIndex].setAttribute("class", "per per-act");

  // set button style
  let btn = document.getElementById("buy");
  btn.setAttribute("class", "c");
  btn.innerText = "Recharge: " + priceList[itemIndex];
  price = priceList[itemIndex];
}

async function startPay() {
  window.handleinitDataCallback = function () {
    window.location.href = window.location.origin;
  };
  if (!price) {
    return;
  }
const resp = await axios.post( 
    baseUrl + "/create/order", 
    { 
      title: "diamond_" + price, 
      amount: price + "", 
    }, 
    { 
      headers: { 
        "content-type": "application/json", 
        "Access-Control-Allow-Origin": "*", 
      }, 
    } 
  ); 
  if(!resp.data){
    return
  }
  if(!window.consumerapp){
    console.log("this page is not open in app");
    return;
  }
window.consumerapp.evaluate(
          JSON.stringify({
            functionName: "js_fun_start_pay",
            params: {
              rawRequest: rawRequest,
              functionCallBackName: "handleinitDataCallback",
            },
          })
  );
}
