function startPay() {
  //this function handel's the redirect callback
  window.handleinitDataCallback = function () {
    window.location.href = window.location.origin;
  };

  window.handleCancelCallback = function () {
    window.location.assign("https://www.w3schools.com");
  };

  if (!price) return null;
  let loading = weui.loading("loading", {});
  window
    .fetch(baseUrl + "/create/order", {
      method: "post",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: "diamond_" + price,
        amount: price + "",
      }),
    })
    .then((res) => res.text())
    .then((rawRequest) => {
      try {
        if (!rawRequest) return;
        if (!window.consumerapp) {
          console.log("this page is not open in app");
          return;
        }
        window.consumerapp.evaluate(
          JSON.stringify({
            functionName: "js_fun_start_pay",
            params: {
              rawRequest: rawRequest,
              functionCallBackName: "handleinitDataCallback",
            },
          })
        );
        console.log("************SUCCESS********");
      } catch (ex) {
        console.log("************EXCEPTION********");
        window.consumerapp.evaluate(
          JSON.stringify({
            functionName: "js_fun_start_pay",
            params: {
              rawRequest: rawRequest,
              functionCallBackName: "handleCancelCallback",
            },
          })
        );
      }
    })
    .catch((err) => console.log("ERROR: ", err))
    .finally(() => {
      loading.hide();
    });
}
