//use your own end point
router.post("/api/payment", (req, res) => {
  let notifyResp = req.body;
  console.log({ paymentNotify: notifyResp });
  //you can implement your own business logic here!!
});
