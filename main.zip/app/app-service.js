var __maAppData=__maAppData||{};
var __maRoute=__maRoute||"";
var __layer__='service';
var __maAppCode__=__maAppCode__||{};
var global=global||{};
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false}; 
var Component=Component||function(){};


/* maml-transpiler v22.12.0 2022-12-29 11:21:52 */
window.__maml_transpiler_version__='v22.12.0'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'onDetail']);
      Z([3,'buy']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'button']);
      Z([3,'Listen Sample Audio Book'])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([11,[3,'https://afroreadapp.com/audio/sample/'],[[7],[3,"bookId"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()

  
  d_["./pages/index/index.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var oC=_ctn("scroll-view");var oD=_setAttrs(z,"button",["bind:tap",0,"class",1,"data-itemid",1,"type",2],e,s,gg);var oE=_o(z,4,e,s,gg);_ac(oD,oE);_ac(oC,oD);_ac(r,oC);
    return r;
  };
  e_["./pages/index/index.maml"]={f:m0,j:[],i:[],ti:[],ic:[]};

  d_["./pages/product-detail/product-detail.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var oG=_ctn("web-view");_setAttr(z,oG,'src',0,e,s,gg);_ac(r,oG);
    return r;
  };
  e_["./pages/product-detail/product-detail.maml"]={f:m1,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

__maAppCode__['app.json']={"pages":["pages/index/index","pages/product-detail/product-detail"],"window":{"backgroundTextStyle":"light","navigationBarBackgroundColor":"#fff","navigationBarTitleText":"Macle","navigationBarTextStyle":"black","capsuleTheme":"light"},"style":"v2","sitemapLocation":"sitemap.json","entryPagePath":"pages/index/index"};
__maAppCode__['pages/index/index.json']={"usingComponents":{}};
__maAppCode__['pages/index/index.maml']=$gma('./pages/index/index.maml');
__maAppCode__['pages/product-detail/product-detail.json']={"navigationBarTitleText":"","usingComponents":{}};
__maAppCode__['pages/product-detail/product-detail.maml']=$gma('./pages/product-detail/product-detail.maml');

define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
App({onLaunch(){},onShow(){}});
});
define("pages/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{},onDetail(){ma.navigateTo({url:"../product-detail/product-detail"})}});
});
define("pages/product-detail/product-detail.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{bookId:"7e71f9d2-fb20-4123-beb4-5b89a32f9c9d",product:null}});
});
define("utils/jsencrypt.min.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
var t,e;t=this,e=function(t){function e(t,e,i){null!=t&&("number"==typeof t?this.fromNumber(t,e,i):null==e&&"string"!=typeof t?this.fromString(t,256):this.fromString(t,e))}function i(){return new e(null)}function s(t){return A.charAt(t)}function r(t,e){var i=U[t.charCodeAt(e)];return null==i?-1:i}function n(t){var e=i();return e.fromInt(t),e}function o(t){var e,i=1;return 0!=(e=t>>>16)&&(t=e,i+=16),0!=(e=t>>8)&&(t=e,i+=8),0!=(e=t>>4)&&(t=e,i+=4),0!=(e=t>>2)&&(t=e,i+=2),0!=(e=t>>1)&&(t=e,i+=1),i}function h(t){this.m=t}function a(t){this.m=t,this.mp=t.invDigit(),this.mpl=32767&this.mp,this.mph=this.mp>>15,this.um=(1<<t.DB-15)-1,this.mt2=2*t.t}function u(t,e){return t&e}function c(t,e){return t|e}function f(t,e){return t^e}function p(t,e){return t&~e}function l(t){if(0==t)return-1;var e=0;return 0==(65535&t)&&(t>>=16,e+=16),0==(255&t)&&(t>>=8,e+=8),0==(15&t)&&(t>>=4,e+=4),0==(3&t)&&(t>>=2,e+=2),0==(1&t)&&++e,e}function d(t){for(var e=0;0!=t;)t&=t-1,++e;return e}function g(){}function m(t){return t}function y(t){this.r2=i(),this.q3=i(),e.ONE.dlShiftTo(2*t.t,this.r2),this.mu=this.r2.divide(t),this.m=t}function b(){this.i=0,this.j=0,this.S=new Array}function T(){if(null==N){for(N=new b;P>I;){var t=Math.floor(65536*Math.random());J[I++]=255&t}for(N.init(J),I=0;I<J.length;++I)J[I]=0;I=0}return N.next()}function S(){}function R(t,i){return new e(t,i)}function E(t,i){if(i<t.length+11)return null;for(var s=new Array,r=t.length-1;r>=0&&i>0;){var n=t.charCodeAt(r--);128>n?s[--i]=n:n>127&&2048>n?(s[--i]=63&n|128,s[--i]=n>>6|192):(s[--i]=63&n|128,s[--i]=n>>6&63|128,s[--i]=n>>12|224)}s[--i]=0;for(var o=new S,h=new Array;i>2;){for(h[0]=0;0==h[0];)o.nextBytes(h);s[--i]=h[0]}return s[--i]=2,s[--i]=0,new e(s)}function D(){this.n=null,this.e=0,this.d=null,this.p=null,this.q=null,this.dmp1=null,this.dmq1=null,this.coeff=null}function w(t){var e,i,s="";for(e=0;e+3<=t.length;e+=3)i=parseInt(t.substring(e,e+3),16),s+=C.charAt(i>>6)+C.charAt(63&i);for(e+1==t.length?(i=parseInt(t.substring(e,e+1),16),s+=C.charAt(i<<2)):e+2==t.length&&(i=parseInt(t.substring(e,e+2),16),s+=C.charAt(i>>2)+C.charAt((3&i)<<4));(3&s.length)>0;)s+=H;return s}var x;"Microsoft Internet Explorer"==navigator.appName?(e.prototype.am=function(t,e,i,s,r,n){for(var o=32767&e,h=e>>15;--n>=0;){var a=32767&this[t],u=this[t++]>>15,c=h*a+u*o;r=((a=o*a+((32767&c)<<15)+i[s]+(1073741823&r))>>>30)+(c>>>15)+h*u+(r>>>30),i[s++]=1073741823&a}return r},x=30):"Netscape"!=navigator.appName?(e.prototype.am=function(t,e,i,s,r,n){for(;--n>=0;){var o=e*this[t++]+i[s]+r;r=Math.floor(o/67108864),i[s++]=67108863&o}return r},x=26):(e.prototype.am=function(t,e,i,s,r,n){for(var o=16383&e,h=e>>14;--n>=0;){var a=16383&this[t],u=this[t++]>>14,c=h*a+u*o;r=((a=o*a+((16383&c)<<14)+i[s]+r)>>28)+(c>>14)+h*u,i[s++]=268435455&a}return r},x=28),e.prototype.DB=x,e.prototype.DM=(1<<x)-1,e.prototype.DV=1<<x,e.prototype.FV=Math.pow(2,52),e.prototype.F1=52-x,e.prototype.F2=2*x-52;var B,K,A="0123456789abcdefghijklmnopqrstuvwxyz",U=new Array;for(B="0".charCodeAt(0),K=0;9>=K;++K)U[B++]=K;for(B="a".charCodeAt(0),K=10;36>K;++K)U[B++]=K;for(B="A".charCodeAt(0),K=10;36>K;++K)U[B++]=K;h.prototype.convert=function(t){return t.s<0||t.compareTo(this.m)>=0?t.mod(this.m):t},h.prototype.revert=function(t){return t},h.prototype.reduce=function(t){t.divRemTo(this.m,null,t)},h.prototype.mulTo=function(t,e,i){t.multiplyTo(e,i),this.reduce(i)},h.prototype.sqrTo=function(t,e){t.squareTo(e),this.reduce(e)},a.prototype.convert=function(t){var s=i();return t.abs().dlShiftTo(this.m.t,s),s.divRemTo(this.m,null,s),t.s<0&&s.compareTo(e.ZERO)>0&&this.m.subTo(s,s),s},a.prototype.revert=function(t){var e=i();return t.copyTo(e),this.reduce(e),e},a.prototype.reduce=function(t){for(;t.t<=this.mt2;)t[t.t++]=0;for(var e=0;e<this.m.t;++e){var i=32767&t[e],s=i*this.mpl+((i*this.mph+(t[e]>>15)*this.mpl&this.um)<<15)&t.DM;for(t[i=e+this.m.t]+=this.m.am(0,s,t,e,0,this.m.t);t[i]>=t.DV;)t[i]-=t.DV,t[++i]++}t.clamp(),t.drShiftTo(this.m.t,t),t.compareTo(this.m)>=0&&t.subTo(this.m,t)},a.prototype.mulTo=function(t,e,i){t.multiplyTo(e,i),this.reduce(i)},a.prototype.sqrTo=function(t,e){t.squareTo(e),this.reduce(e)},e.prototype.copyTo=function(t){for(var e=this.t-1;e>=0;--e)t[e]=this[e];t.t=this.t,t.s=this.s},e.prototype.fromInt=function(t){this.t=1,this.s=0>t?-1:0,t>0?this[0]=t:-1>t?this[0]=t+this.DV:this.t=0},e.prototype.fromString=function(t,i){var s;if(16==i)s=4;else if(8==i)s=3;else if(256==i)s=8;else if(2==i)s=1;else if(32==i)s=5;else{if(4!=i)return void this.fromRadix(t,i);s=2}this.t=0,this.s=0;for(var n=t.length,o=!1,h=0;--n>=0;){var a=8==s?255&t[n]:r(t,n);0>a?"-"==t.charAt(n)&&(o=!0):(o=!1,0==h?this[this.t++]=a:h+s>this.DB?(this[this.t-1]|=(a&(1<<this.DB-h)-1)<<h,this[this.t++]=a>>this.DB-h):this[this.t-1]|=a<<h,(h+=s)>=this.DB&&(h-=this.DB))}8==s&&0!=(128&t[0])&&(this.s=-1,h>0&&(this[this.t-1]|=(1<<this.DB-h)-1<<h)),this.clamp(),o&&e.ZERO.subTo(this,this)},e.prototype.clamp=function(){for(var t=this.s&this.DM;this.t>0&&this[this.t-1]==t;)--this.t},e.prototype.dlShiftTo=function(t,e){var i;for(i=this.t-1;i>=0;--i)e[i+t]=this[i];for(i=t-1;i>=0;--i)e[i]=0;e.t=this.t+t,e.s=this.s},e.prototype.drShiftTo=function(t,e){for(var i=t;i<this.t;++i)e[i-t]=this[i];e.t=Math.max(this.t-t,0),e.s=this.s},e.prototype.lShiftTo=function(t,e){var i,s=t%this.DB,r=this.DB-s,n=(1<<r)-1,o=Math.floor(t/this.DB),h=this.s<<s&this.DM;for(i=this.t-1;i>=0;--i)e[i+o+1]=this[i]>>r|h,h=(this[i]&n)<<s;for(i=o-1;i>=0;--i)e[i]=0;e[o]=h,e.t=this.t+o+1,e.s=this.s,e.clamp()},e.prototype.rShiftTo=function(t,e){e.s=this.s;var i=Math.floor(t/this.DB);if(i>=this.t)e.t=0;else{var s=t%this.DB,r=this.DB-s,n=(1<<s)-1;e[0]=this[i]>>s;for(var o=i+1;o<this.t;++o)e[o-i-1]|=(this[o]&n)<<r,e[o-i]=this[o]>>s;s>0&&(e[this.t-i-1]|=(this.s&n)<<r),e.t=this.t-i,e.clamp()}},e.prototype.subTo=function(t,e){for(var i=0,s=0,r=Math.min(t.t,this.t);r>i;)s+=this[i]-t[i],e[i++]=s&this.DM,s>>=this.DB;if(t.t<this.t){for(s-=t.s;i<this.t;)s+=this[i],e[i++]=s&this.DM,s>>=this.DB;s+=this.s}else{for(s+=this.s;i<t.t;)s-=t[i],e[i++]=s&this.DM,s>>=this.DB;s-=t.s}e.s=0>s?-1:0,-1>s?e[i++]=this.DV+s:s>0&&(e[i++]=s),e.t=i,e.clamp()},e.prototype.multiplyTo=function(t,i){var s=this.abs(),r=t.abs(),n=s.t;for(i.t=n+r.t;--n>=0;)i[n]=0;for(n=0;n<r.t;++n)i[n+s.t]=s.am(0,r[n],i,n,0,s.t);i.s=0,i.clamp(),this.s!=t.s&&e.ZERO.subTo(i,i)},e.prototype.squareTo=function(t){for(var e=this.abs(),i=t.t=2*e.t;--i>=0;)t[i]=0;for(i=0;i<e.t-1;++i){var s=e.am(i,e[i],t,2*i,0,1);(t[i+e.t]+=e.am(i+1,2*e[i],t,2*i+1,s,e.t-i-1))>=e.DV&&(t[i+e.t]-=e.DV,t[i+e.t+1]=1)}t.t>0&&(t[t.t-1]+=e.am(i,e[i],t,2*i,0,1)),t.s=0,t.clamp()},e.prototype.divRemTo=function(t,s,r){var n=t.abs();if(!(n.t<=0)){var h=this.abs();if(h.t<n.t)return null!=s&&s.fromInt(0),void(null!=r&&this.copyTo(r));null==r&&(r=i());var a=i(),u=this.s,c=t.s,f=this.DB-o(n[n.t-1]);f>0?(n.lShiftTo(f,a),h.lShiftTo(f,r)):(n.copyTo(a),h.copyTo(r));var p=a.t,l=a[p-1];if(0!=l){var d=l*(1<<this.F1)+(p>1?a[p-2]>>this.F2:0),g=this.FV/d,m=(1<<this.F1)/d,v=1<<this.F2,y=r.t,b=y-p,T=null==s?i():s;for(a.dlShiftTo(b,T),r.compareTo(T)>=0&&(r[r.t++]=1,r.subTo(T,r)),e.ONE.dlShiftTo(p,T),T.subTo(a,a);a.t<p;)a[a.t++]=0;for(;--b>=0;){var S=r[--y]==l?this.DM:Math.floor(r[y]*g+(r[y-1]+v)*m);if((r[y]+=a.am(0,S,r,b,0,p))<S)for(a.dlShiftTo(b,T),r.subTo(T,r);r[y]<--S;)r.subTo(T,r)}null!=s&&(r.drShiftTo(p,s),u!=c&&e.ZERO.subTo(s,s)),r.t=p,r.clamp(),f>0&&r.rShiftTo(f,r),0>u&&e.ZERO.subTo(r,r)}}},e.prototype.invDigit=function(){if(this.t<1)return 0;var t=this[0];if(0==(1&t))return 0;var e=3&t;return(e=(e=(e=(e=e*(2-(15&t)*e)&15)*(2-(255&t)*e)&255)*(2-((65535&t)*e&65535))&65535)*(2-t*e%this.DV)%this.DV)>0?this.DV-e:-e},e.prototype.isEven=function(){return 0==(this.t>0?1&this[0]:this.s)},e.prototype.exp=function(t,s){if(t>4294967295||1>t)return e.ONE;var r=i(),n=i(),h=s.convert(this),a=o(t)-1;for(h.copyTo(r);--a>=0;)if(s.sqrTo(r,n),(t&1<<a)>0)s.mulTo(n,h,r);else{var u=r;r=n,n=u}return s.revert(r)},e.prototype.toString=function(t){if(this.s<0)return"-"+this.negate().toString(t);var e;if(16==t)e=4;else if(8==t)e=3;else if(2==t)e=1;else if(32==t)e=5;else{if(4!=t)return this.toRadix(t);e=2}var i,r=(1<<e)-1,n=!1,o="",h=this.t,a=this.DB-h*this.DB%e;if(h-- >0)for(a<this.DB&&(i=this[h]>>a)>0&&(n=!0,o=s(i));h>=0;)e>a?(i=(this[h]&(1<<a)-1)<<e-a,i|=this[--h]>>(a+=this.DB-e)):(i=this[h]>>(a-=e)&r,0>=a&&(a+=this.DB,--h)),i>0&&(n=!0),n&&(o+=s(i));return n?o:"0"},e.prototype.negate=function(){var t=i();return e.ZERO.subTo(this,t),t},e.prototype.abs=function(){return this.s<0?this.negate():this},e.prototype.compareTo=function(t){var e=this.s-t.s;if(0!=e)return e;var i=this.t;if(0!=(e=i-t.t))return this.s<0?-e:e;for(;--i>=0;)if(0!=(e=this[i]-t[i]))return e;return 0},e.prototype.bitLength=function(){return this.t<=0?0:this.DB*(this.t-1)+o(this[this.t-1]^this.s&this.DM)},e.prototype.mod=function(t){var s=i();return this.abs().divRemTo(t,null,s),this.s<0&&s.compareTo(e.ZERO)>0&&t.subTo(s,s),s},e.prototype.modPowInt=function(t,e){var i;return i=256>t||e.isEven()?new h(e):new a(e),this.exp(t,i)},e.ZERO=n(0),e.ONE=n(1),g.prototype.convert=m,g.prototype.revert=m,g.prototype.mulTo=function(t,e,i){t.multiplyTo(e,i)},g.prototype.sqrTo=function(t,e){t.squareTo(e)},y.prototype.convert=function(t){if(t.s<0||t.t>2*this.m.t)return t.mod(this.m);if(t.compareTo(this.m)<0)return t;var e=i();return t.copyTo(e),this.reduce(e),e},y.prototype.revert=function(t){return t},y.prototype.reduce=function(t){for(t.drShiftTo(this.m.t-1,this.r2),t.t>this.m.t+1&&(t.t=this.m.t+1,t.clamp()),this.mu.multiplyUpperTo(this.r2,this.m.t+1,this.q3),this.m.multiplyLowerTo(this.q3,this.m.t+1,this.r2);t.compareTo(this.r2)<0;)t.dAddOffset(1,this.m.t+1);for(t.subTo(this.r2,t);t.compareTo(this.m)>=0;)t.subTo(this.m,t)},y.prototype.mulTo=function(t,e,i){t.multiplyTo(e,i),this.reduce(i)},y.prototype.sqrTo=function(t,e){t.squareTo(e),this.reduce(e)};var O=[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193,197,199,211,223,227,229,233,239,241,251,257,263,269,271,277,281,283,293,307,311,313,317,331,337,347,349,353,359,367,373,379,383,389,397,401,409,419,421,431,433,439,443,449,457,461,463,467,479,487,491,499,503,509,521,523,541,547,557,563,569,571,577,587,593,599,601,607,613,617,619,631,641,643,647,653,659,661,673,677,683,691,701,709,719,727,733,739,743,751,757,761,769,773,787,797,809,811,821,823,827,829,839,853,857,859,863,877,881,883,887,907,911,919,929,937,941,947,953,967,971,977,983,991,997],V=(1<<26)/O[O.length-1];e.prototype.chunkSize=function(t){return Math.floor(Math.LN2*this.DB/Math.log(t))},e.prototype.toRadix=function(t){if(null==t&&(t=10),0==this.signum()||2>t||t>36)return"0";var e=this.chunkSize(t),s=Math.pow(t,e),r=n(s),o=i(),h=i(),a="";for(this.divRemTo(r,o,h);o.signum()>0;)a=(s+h.intValue()).toString(t).substr(1)+a,o.divRemTo(r,o,h);return h.intValue().toString(t)+a},e.prototype.fromRadix=function(t,i){this.fromInt(0),null==i&&(i=10);for(var s=this.chunkSize(i),n=Math.pow(i,s),o=!1,h=0,a=0,u=0;u<t.length;++u){var c=r(t,u);0>c?"-"==t.charAt(u)&&0==this.signum()&&(o=!0):(a=i*a+c,++h>=s&&(this.dMultiply(n),this.dAddOffset(a,0),h=0,a=0))}h>0&&(this.dMultiply(Math.pow(i,h)),this.dAddOffset(a,0)),o&&e.ZERO.subTo(this,this)},e.prototype.fromNumber=function(t,i,s){if("number"==typeof i)if(2>t)this.fromInt(1);else for(this.fromNumber(t,s),this.testBit(t-1)||this.bitwiseTo(e.ONE.shiftLeft(t-1),c,this),this.isEven()&&this.dAddOffset(1,0);!this.isProbablePrime(i);)this.dAddOffset(2,0),this.bitLength()>t&&this.subTo(e.ONE.shiftLeft(t-1),this);else{var r=new Array,n=7&t;r.length=1+(t>>3),i.nextBytes(r),n>0?r[0]&=(1<<n)-1:r[0]=0,this.fromString(r,256)}},e.prototype.bitwiseTo=function(t,e,i){var s,r,n=Math.min(t.t,this.t);for(s=0;n>s;++s)i[s]=e(this[s],t[s]);if(t.t<this.t){for(r=t.s&this.DM,s=n;s<this.t;++s)i[s]=e(this[s],r);i.t=this.t}else{for(r=this.s&this.DM,s=n;s<t.t;++s)i[s]=e(r,t[s]);i.t=t.t}i.s=e(this.s,t.s),i.clamp()},e.prototype.changeBit=function(t,i){var s=e.ONE.shiftLeft(t);return this.bitwiseTo(s,i,s),s},e.prototype.addTo=function(t,e){for(var i=0,s=0,r=Math.min(t.t,this.t);r>i;)s+=this[i]+t[i],e[i++]=s&this.DM,s>>=this.DB;if(t.t<this.t){for(s+=t.s;i<this.t;)s+=this[i],e[i++]=s&this.DM,s>>=this.DB;s+=this.s}else{for(s+=this.s;i<t.t;)s+=t[i],e[i++]=s&this.DM,s>>=this.DB;s+=t.s}e.s=0>s?-1:0,s>0?e[i++]=s:-1>s&&(e[i++]=this.DV+s),e.t=i,e.clamp()},e.prototype.dMultiply=function(t){this[this.t]=this.am(0,t-1,this,0,0,this.t),++this.t,this.clamp()},e.prototype.dAddOffset=function(t,e){if(0!=t){for(;this.t<=e;)this[this.t++]=0;for(this[e]+=t;this[e]>=this.DV;)this[e]-=this.DV,++e>=this.t&&(this[this.t++]=0),++this[e]}},e.prototype.multiplyLowerTo=function(t,e,i){var s,r=Math.min(this.t+t.t,e);for(i.s=0,i.t=r;r>0;)i[--r]=0;for(s=i.t-this.t;s>r;++r)i[r+this.t]=this.am(0,t[r],i,r,0,this.t);for(s=Math.min(t.t,e);s>r;++r)this.am(0,t[r],i,r,0,e-r);i.clamp()},e.prototype.multiplyUpperTo=function(t,e,i){--e;var s=i.t=this.t+t.t-e;for(i.s=0;--s>=0;)i[s]=0;for(s=Math.max(e-this.t,0);s<t.t;++s)i[this.t+s-e]=this.am(e-s,t[s],i,0,0,this.t+s-e);i.clamp(),i.drShiftTo(1,i)},e.prototype.modInt=function(t){if(0>=t)return 0;var e=this.DV%t,i=this.s<0?t-1:0;if(this.t>0)if(0==e)i=this[0]%t;else for(var s=this.t-1;s>=0;--s)i=(e*i+this[s])%t;return i},e.prototype.millerRabin=function(t){var s=this.subtract(e.ONE),r=s.getLowestSetBit();if(0>=r)return!1;var n=s.shiftRight(r);(t=t+1>>1)>O.length&&(t=O.length);for(var o=i(),h=0;t>h;++h){o.fromInt(O[Math.floor(Math.random()*O.length)]);var a=o.modPow(n,this);if(0!=a.compareTo(e.ONE)&&0!=a.compareTo(s)){for(var u=1;u++<r&&0!=a.compareTo(s);)if(0==(a=a.modPowInt(2,this)).compareTo(e.ONE))return!1;if(0!=a.compareTo(s))return!1}}return!0},e.prototype.clone=function(){var t=i();return this.copyTo(t),t},e.prototype.intValue=function(){if(this.s<0){if(1==this.t)return this[0]-this.DV;if(0==this.t)return-1}else{if(1==this.t)return this[0];if(0==this.t)return 0}return(this[1]&(1<<32-this.DB)-1)<<this.DB|this[0]},e.prototype.byteValue=function(){return 0==this.t?this.s:this[0]<<24>>24},e.prototype.shortValue=function(){return 0==this.t?this.s:this[0]<<16>>16},e.prototype.signum=function(){return this.s<0?-1:this.t<=0||1==this.t&&this[0]<=0?0:1},e.prototype.toByteArray=function(){var t=this.t,e=new Array;e[0]=this.s;var i,s=this.DB-t*this.DB%8,r=0;if(t-- >0)for(s<this.DB&&(i=this[t]>>s)!=(this.s&this.DM)>>s&&(e[r++]=i|this.s<<this.DB-s);t>=0;)8>s?(i=(this[t]&(1<<s)-1)<<8-s,i|=this[--t]>>(s+=this.DB-8)):(i=this[t]>>(s-=8)&255,0>=s&&(s+=this.DB,--t)),0!=(128&i)&&(i|=-256),0==r&&(128&this.s)!=(128&i)&&++r,(r>0||i!=this.s)&&(e[r++]=i);return e},e.prototype.equals=function(t){return 0==this.compareTo(t)},e.prototype.min=function(t){return this.compareTo(t)<0?this:t},e.prototype.max=function(t){return this.compareTo(t)>0?this:t},e.prototype.and=function(t){var e=i();return this.bitwiseTo(t,u,e),e},e.prototype.or=function(t){var e=i();return this.bitwiseTo(t,c,e),e},e.prototype.xor=function(t){var e=i();return this.bitwiseTo(t,f,e),e},e.prototype.andNot=function(t){var e=i();return this.bitwiseTo(t,p,e),e},e.prototype.not=function(){for(var t=i(),e=0;e<this.t;++e)t[e]=this.DM&~this[e];return t.t=this.t,t.s=~this.s,t},e.prototype.shiftLeft=function(t){var e=i();return 0>t?this.rShiftTo(-t,e):this.lShiftTo(t,e),e},e.prototype.shiftRight=function(t){var e=i();return 0>t?this.lShiftTo(-t,e):this.rShiftTo(t,e),e},e.prototype.getLowestSetBit=function(){for(var t=0;t<this.t;++t)if(0!=this[t])return t*this.DB+l(this[t]);return this.s<0?this.t*this.DB:-1},e.prototype.bitCount=function(){for(var t=0,e=this.s&this.DM,i=0;i<this.t;++i)t+=d(this[i]^e);return t},e.prototype.testBit=function(t){var e=Math.floor(t/this.DB);return e>=this.t?0!=this.s:0!=(this[e]&1<<t%this.DB)},e.prototype.setBit=function(t){return this.changeBit(t,c)},e.prototype.clearBit=function(t){return this.changeBit(t,p)},e.prototype.flipBit=function(t){return this.changeBit(t,f)},e.prototype.add=function(t){var e=i();return this.addTo(t,e),e},e.prototype.subtract=function(t){var e=i();return this.subTo(t,e),e},e.prototype.multiply=function(t){var e=i();return this.multiplyTo(t,e),e},e.prototype.divide=function(t){var e=i();return this.divRemTo(t,e,null),e},e.prototype.remainder=function(t){var e=i();return this.divRemTo(t,null,e),e},e.prototype.divideAndRemainder=function(t){var e=i(),s=i();return this.divRemTo(t,e,s),new Array(e,s)},e.prototype.modPow=function(t,e){var s,r,u=t.bitLength(),c=n(1);if(0>=u)return c;s=18>u?1:48>u?3:144>u?4:768>u?5:6,r=8>u?new h(e):e.isEven()?new y(e):new a(e);var f=new Array,p=3,l=s-1,d=(1<<s)-1;if(f[1]=r.convert(this),s>1){var g=i();for(r.sqrTo(f[1],g);d>=p;)f[p]=i(),r.mulTo(g,f[p-2],f[p]),p+=2}var m,v,b=t.t-1,T=!0,S=i();for(u=o(t[b])-1;b>=0;){for(u>=l?m=t[b]>>u-l&d:(m=(t[b]&(1<<u+1)-1)<<l-u,b>0&&(m|=t[b-1]>>this.DB+u-l)),p=s;0==(1&m);)m>>=1,--p;if((u-=p)<0&&(u+=this.DB,--b),T)f[m].copyTo(c),T=!1;else{for(;p>1;)r.sqrTo(c,S),r.sqrTo(S,c),p-=2;p>0?r.sqrTo(c,S):(v=c,c=S,S=v),r.mulTo(S,f[m],c)}for(;b>=0&&0==(t[b]&1<<u);)r.sqrTo(c,S),v=c,c=S,S=v,--u<0&&(u=this.DB-1,--b)}return r.revert(c)},e.prototype.modInverse=function(t){var i=t.isEven();if(this.isEven()&&i||0==t.signum())return e.ZERO;for(var s=t.clone(),r=this.clone(),o=n(1),h=n(0),a=n(0),u=n(1);0!=s.signum();){for(;s.isEven();)s.rShiftTo(1,s),i?(o.isEven()&&h.isEven()||(o.addTo(this,o),h.subTo(t,h)),o.rShiftTo(1,o)):h.isEven()||h.subTo(t,h),h.rShiftTo(1,h);for(;r.isEven();)r.rShiftTo(1,r),i?(a.isEven()&&u.isEven()||(a.addTo(this,a),u.subTo(t,u)),a.rShiftTo(1,a)):u.isEven()||u.subTo(t,u),u.rShiftTo(1,u);s.compareTo(r)>=0?(s.subTo(r,s),i&&o.subTo(a,o),h.subTo(u,h)):(r.subTo(s,r),i&&a.subTo(o,a),u.subTo(h,u))}return 0!=r.compareTo(e.ONE)?e.ZERO:u.compareTo(t)>=0?u.subtract(t):u.signum()<0?(u.addTo(t,u),u.signum()<0?u.add(t):u):u},e.prototype.pow=function(t){return this.exp(t,new g)},e.prototype.gcd=function(t){var e=this.s<0?this.negate():this.clone(),i=t.s<0?t.negate():t.clone();if(e.compareTo(i)<0){var s=e;e=i,i=s}var r=e.getLowestSetBit(),n=i.getLowestSetBit();if(0>n)return e;for(n>r&&(n=r),n>0&&(e.rShiftTo(n,e),i.rShiftTo(n,i));e.signum()>0;)(r=e.getLowestSetBit())>0&&e.rShiftTo(r,e),(r=i.getLowestSetBit())>0&&i.rShiftTo(r,i),e.compareTo(i)>=0?(e.subTo(i,e),e.rShiftTo(1,e)):(i.subTo(e,i),i.rShiftTo(1,i));return n>0&&i.lShiftTo(n,i),i},e.prototype.isProbablePrime=function(t){var e,i=this.abs();if(1==i.t&&i[0]<=O[O.length-1]){for(e=0;e<O.length;++e)if(i[0]==O[e])return!0;return!1}if(i.isEven())return!1;for(e=1;e<O.length;){for(var s=O[e],r=e+1;r<O.length&&V>s;)s*=O[r++];for(s=i.modInt(s);r>e;)if(s%O[e++]==0)return!1}return i.millerRabin(t)},e.prototype.square=function(){var t=i();return this.squareTo(t),t},b.prototype.init=function(t){var e,i,s;for(e=0;256>e;++e)this.S[e]=e;for(i=0,e=0;256>e;++e)i=i+this.S[e]+t[e%t.length]&255,s=this.S[e],this.S[e]=this.S[i],this.S[i]=s;this.i=0,this.j=0},b.prototype.next=function(){var t;return this.i=this.i+1&255,this.j=this.j+this.S[this.i]&255,t=this.S[this.i],this.S[this.i]=this.S[this.j],this.S[this.j]=t,this.S[t+this.S[this.i]&255]};var N,J,I,P=256;if(null==J){var M;if(J=new Array,I=0,window.crypto&&window.crypto.getRandomValues){var L=new Uint32Array(256);for(window.crypto.getRandomValues(L),M=0;M<L.length;++M)J[I++]=255&L[M]}var q=function(t){if(this.count=this.count||0,this.count>=256||I>=P)window.removeEventListener?window.removeEventListener("mousemove",q,!1):window.detachEvent&&window.detachEvent("onmousemove",q);else try{var e=t.x+t.y;J[I++]=255&e,this.count+=1}catch(i){}};window.addEventListener?window.addEventListener("mousemove",q,!1):window.attachEvent&&window.attachEvent("onmousemove",q)}S.prototype.nextBytes=function(t){var e;for(e=0;e<t.length;++e)t[e]=T()},D.prototype.doPublic=function(t){return t.modPowInt(this.e,this.n)},D.prototype.setPublic=function(t,e){null!=t&&null!=e&&t.length>0&&e.length>0&&(this.n=R(t,16),this.e=parseInt(e,16))},D.prototype.encrypt=function(t){var e=E(t,this.n.bitLength()+7>>3);if(null==e)return null;var i=this.doPublic(e);if(null==i)return null;var s=i.toString(16);return 0==(1&s.length)?s:"0"+s},D.prototype.doPrivate=function(t){if(null==this.p||null==this.q)return t.modPow(this.d,this.n);for(var e=t.mod(this.p).modPow(this.dmp1,this.p),i=t.mod(this.q).modPow(this.dmq1,this.q);e.compareTo(i)<0;)e=e.add(this.p);return e.subtract(i).multiply(this.coeff).mod(this.p).multiply(this.q).add(i)},D.prototype.setPrivate=function(t,e,i){null!=t&&null!=e&&t.length>0&&e.length>0&&(this.n=R(t,16),this.e=parseInt(e,16),this.d=R(i,16))},D.prototype.setPrivateEx=function(t,e,i,s,r,n,o,h){null!=t&&null!=e&&t.length>0&&e.length>0&&(this.n=R(t,16),this.e=parseInt(e,16),this.d=R(i,16),this.p=R(s,16),this.q=R(r,16),this.dmp1=R(n,16),this.dmq1=R(o,16),this.coeff=R(h,16))},D.prototype.generate=function(t,i){var s=new S,r=t>>1;this.e=parseInt(i,16);for(var n=new e(i,16);;){for(;this.p=new e(t-r,1,s),0!=this.p.subtract(e.ONE).gcd(n).compareTo(e.ONE)||!this.p.isProbablePrime(10););for(;this.q=new e(r,1,s),0!=this.q.subtract(e.ONE).gcd(n).compareTo(e.ONE)||!this.q.isProbablePrime(10););if(this.p.compareTo(this.q)<=0){var o=this.p;this.p=this.q,this.q=o}var h=this.p.subtract(e.ONE),a=this.q.subtract(e.ONE),u=h.multiply(a);if(0==u.gcd(n).compareTo(e.ONE)){this.n=this.p.multiply(this.q),this.d=n.modInverse(u),this.dmp1=this.d.mod(h),this.dmq1=this.d.mod(a),this.coeff=this.q.modInverse(this.p);break}}},D.prototype.decrypt=function(t){var e=R(t,16),i=this.doPrivate(e);return null==i?null:function(t,e){for(var i=t.toByteArray(),s=0;s<i.length&&0==i[s];)++s;if(i.length-s!=e-1||2!=i[s])return null;for(++s;0!=i[s];)if(++s>=i.length)return null;for(var r="";++s<i.length;){var n=255&i[s];128>n?r+=String.fromCharCode(n):n>191&&224>n?(r+=String.fromCharCode((31&n)<<6|63&i[s+1]),++s):(r+=String.fromCharCode((15&n)<<12|(63&i[s+1])<<6|63&i[s+2]),s+=2)}return r}(i,this.n.bitLength()+7>>3)},D.prototype.generateAsync=function(t,s,r){var n=new S,o=t>>1;this.e=parseInt(s,16);var h=new e(s,16),a=this,u=function(){var s=function(){if(a.p.compareTo(a.q)<=0){var t=a.p;a.p=a.q,a.q=t}var i=a.p.subtract(e.ONE),s=a.q.subtract(e.ONE),n=i.multiply(s);0==n.gcd(h).compareTo(e.ONE)?(a.n=a.p.multiply(a.q),a.d=h.modInverse(n),a.dmp1=a.d.mod(i),a.dmq1=a.d.mod(s),a.coeff=a.q.modInverse(a.p),setTimeout((function(){r()}),0)):setTimeout(u,0)},c=function(){a.q=i(),a.q.fromNumberAsync(o,1,n,(function(){a.q.subtract(e.ONE).gcda(h,(function(t){0==t.compareTo(e.ONE)&&a.q.isProbablePrime(10)?setTimeout(s,0):setTimeout(c,0)}))}))},f=function(){a.p=i(),a.p.fromNumberAsync(t-o,1,n,(function(){a.p.subtract(e.ONE).gcda(h,(function(t){0==t.compareTo(e.ONE)&&a.p.isProbablePrime(10)?setTimeout(c,0):setTimeout(f,0)}))}))};setTimeout(f,0)};setTimeout(u,0)},e.prototype.gcda=function(t,e){var i=this.s<0?this.negate():this.clone(),s=t.s<0?t.negate():t.clone();if(i.compareTo(s)<0){var r=i;i=s,s=r}var n=i.getLowestSetBit(),o=s.getLowestSetBit();if(0>o)e(i);else{o>n&&(o=n),o>0&&(i.rShiftTo(o,i),s.rShiftTo(o,s));var h=function(){(n=i.getLowestSetBit())>0&&i.rShiftTo(n,i),(n=s.getLowestSetBit())>0&&s.rShiftTo(n,s),i.compareTo(s)>=0?(i.subTo(s,i),i.rShiftTo(1,i)):(s.subTo(i,s),s.rShiftTo(1,s)),i.signum()>0?setTimeout(h,0):(o>0&&s.lShiftTo(o,s),setTimeout((function(){e(s)}),0))};setTimeout(h,10)}},e.prototype.fromNumberAsync=function(t,i,s,r){if("number"==typeof i)if(2>t)this.fromInt(1);else{this.fromNumber(t,s),this.testBit(t-1)||this.bitwiseTo(e.ONE.shiftLeft(t-1),c,this),this.isEven()&&this.dAddOffset(1,0);var n=this,o=function(){n.dAddOffset(2,0),n.bitLength()>t&&n.subTo(e.ONE.shiftLeft(t-1),n),n.isProbablePrime(i)?setTimeout((function(){r()}),0):setTimeout(o,0)};setTimeout(o,0)}else{var h=new Array,a=7&t;h.length=1+(t>>3),i.nextBytes(h),a>0?h[0]&=(1<<a)-1:h[0]=0,this.fromString(h,256)}};var C="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",H="=",j=j||{};j.env=j.env||{};var F=j,k=Object.prototype,_=["toString","valueOf"];j.env.parseUA=function(t){var e,i=function(t){var e=0;return parseFloat(t.replace(/\./g,(function(){return 1==e++?"":"."})))},s=navigator,r={ie:0,opera:0,gecko:0,webkit:0,chrome:0,mobile:null,air:0,ipad:0,iphone:0,ipod:0,ios:null,android:0,webos:0,caja:s&&s.cajaVersion,secure:!1,os:null},n=t||navigator&&navigator.userAgent,o=window&&window.location,h=o&&o.href;return r.secure=h&&0===h.toLowerCase().indexOf("https"),n&&(/windows|win32/i.test(n)?r.os="windows":/macintosh/i.test(n)?r.os="macintosh":/rhino/i.test(n)&&(r.os="rhino"),/KHTML/.test(n)&&(r.webkit=1),(e=n.match(/AppleWebKit\/([^\s]*)/))&&e[1]&&(r.webkit=i(e[1]),/ Mobile\//.test(n)?(r.mobile="Apple",(e=n.match(/OS ([^\s]*)/))&&e[1]&&(e=i(e[1].replace("_","."))),r.ios=e,r.ipad=r.ipod=r.iphone=0,(e=n.match(/iPad|iPod|iPhone/))&&e[0]&&(r[e[0].toLowerCase()]=r.ios)):((e=n.match(/NokiaN[^\/]*|Android \d\.\d|webOS\/\d\.\d/))&&(r.mobile=e[0]),/webOS/.test(n)&&(r.mobile="WebOS",(e=n.match(/webOS\/([^\s]*);/))&&e[1]&&(r.webos=i(e[1]))),/ Android/.test(n)&&(r.mobile="Android",(e=n.match(/Android ([^\s]*);/))&&e[1]&&(r.android=i(e[1])))),(e=n.match(/Chrome\/([^\s]*)/))&&e[1]?r.chrome=i(e[1]):(e=n.match(/AdobeAIR\/([^\s]*)/))&&(r.air=e[0])),r.webkit||((e=n.match(/Opera[\s\/]([^\s]*)/))&&e[1]?(r.opera=i(e[1]),(e=n.match(/Version\/([^\s]*)/))&&e[1]&&(r.opera=i(e[1])),(e=n.match(/Opera Mini[^;]*/))&&(r.mobile=e[0])):(e=n.match(/MSIE\s([^;]*)/))&&e[1]?r.ie=i(e[1]):(e=n.match(/Gecko\/([^\s]*)/))&&(r.gecko=1,(e=n.match(/rv:([^\s\)]*)/))&&e[1]&&(r.gecko=i(e[1]))))),r},j.env.ua=j.env.parseUA(),j.isFunction=function(t){return"function"==typeof t||"[object Function]"===k.toString.apply(t)},j._IEEnumFix=j.env.ua.ie?function(t,e){var i,s,r;for(i=0;i<_.length;i+=1)r=e[s=_[i]],F.isFunction(r)&&r!=k[s]&&(t[s]=r)}:function(){},j.extend=function(t,e,i){if(!e||!t)throw new Error("extend failed, please check that all dependencies are included.");var s,r=function(){};if(r.prototype=e.prototype,t.prototype=new r,t.prototype.constructor=t,t.superclass=e.prototype,e.prototype.constructor==k.constructor&&(e.prototype.constructor=e),i){for(s in i)F.hasOwnProperty(i,s)&&(t.prototype[s]=i[s]);F._IEEnumFix(t.prototype,i)}},"undefined"!=typeof KJUR&&KJUR||(KJUR={}),void 0!==KJUR.asn1&&KJUR.asn1||(KJUR.asn1={}),KJUR.asn1.ASN1Util=new function(){this.integerToByteHex=function(t){var e=t.toString(16);return e.length%2==1&&(e="0"+e),e},this.bigIntToMinTwosComplementsHex=function(t){var i=t.toString(16);if("-"!=i.substr(0,1))i.length%2==1?i="0"+i:i.match(/^[0-7]/)||(i="00"+i);else{var s=i.substr(1).length;s%2==1?s+=1:i.match(/^[0-7]/)||(s+=2);for(var r="",n=0;s>n;n++)r+="f";i=new e(r,16).xor(t).add(e.ONE).toString(16).replace(/^-/,"")}return i},this.getPEMStringFromHex=function(t,e){var i=CryptoJS.enc.Hex.parse(t),s=CryptoJS.enc.Base64.stringify(i).replace(/(.{64})/g,"$1\r\n");return"-----BEGIN "+e+"-----\r\n"+(s=s.replace(/\r\n$/,""))+"\r\n-----END "+e+"-----\r\n"}},KJUR.asn1.ASN1Object=function(){this.getLengthHexFromValue=function(){if(void 0===this.hV||null==this.hV)throw"this.hV is null or undefined.";if(this.hV.length%2==1)throw"value hex must be even length: n="+"".length+",v="+this.hV;var t=this.hV.length/2,e=t.toString(16);if(e.length%2==1&&(e="0"+e),128>t)return e;var i=e.length/2;if(i>15)throw"ASN.1 length too long to represent by 8x: n = "+t.toString(16);return(128+i).toString(16)+e},this.getEncodedHex=function(){return(null==this.hTLV||this.isModified)&&(this.hV=this.getFreshValueHex(),this.hL=this.getLengthHexFromValue(),this.hTLV=this.hT+this.hL+this.hV,this.isModified=!1),this.hTLV},this.getValueHex=function(){return this.getEncodedHex(),this.hV},this.getFreshValueHex=function(){return""}},KJUR.asn1.DERAbstractString=function(t){KJUR.asn1.DERAbstractString.superclass.constructor.call(this),this.getString=function(){return this.s},this.setString=function(t){this.hTLV=null,this.isModified=!0,this.s=t,this.hV=stohex(this.s)},this.setStringHex=function(t){this.hTLV=null,this.isModified=!0,this.s=null,this.hV=t},this.getFreshValueHex=function(){return this.hV},void 0!==t&&(void 0!==t.str?this.setString(t.str):void 0!==t.hex&&this.setStringHex(t.hex))},j.extend(KJUR.asn1.DERAbstractString,KJUR.asn1.ASN1Object),KJUR.asn1.DERAbstractTime=function(t){KJUR.asn1.DERAbstractTime.superclass.constructor.call(this),this.localDateToUTC=function(t){return utc=t.getTime()+6e4*t.getTimezoneOffset(),new Date(utc)},this.formatDate=function(t,e){var i=this.zeroPadding,s=this.localDateToUTC(t),r=String(s.getFullYear());return"utc"==e&&(r=r.substr(2,2)),r+i(String(s.getMonth()+1),2)+i(String(s.getDate()),2)+i(String(s.getHours()),2)+i(String(s.getMinutes()),2)+i(String(s.getSeconds()),2)+"Z"},this.zeroPadding=function(t,e){return t.length>=e?t:new Array(e-t.length+1).join("0")+t},this.getString=function(){return this.s},this.setString=function(t){this.hTLV=null,this.isModified=!0,this.s=t,this.hV=stohex(this.s)},this.setByDateValue=function(t,e,i,s,r,n){var o=new Date(Date.UTC(t,e-1,i,s,r,n,0));this.setByDate(o)},this.getFreshValueHex=function(){return this.hV}},j.extend(KJUR.asn1.DERAbstractTime,KJUR.asn1.ASN1Object),KJUR.asn1.DERAbstractStructured=function(t){KJUR.asn1.DERAbstractString.superclass.constructor.call(this),this.setByASN1ObjectArray=function(t){this.hTLV=null,this.isModified=!0,this.asn1Array=t},this.appendASN1Object=function(t){this.hTLV=null,this.isModified=!0,this.asn1Array.push(t)},this.asn1Array=new Array,void 0!==t&&void 0!==t.array&&(this.asn1Array=t.array)},j.extend(KJUR.asn1.DERAbstractStructured,KJUR.asn1.ASN1Object),KJUR.asn1.DERBoolean=function(){KJUR.asn1.DERBoolean.superclass.constructor.call(this),this.hT="01",this.hTLV="0101ff"},j.extend(KJUR.asn1.DERBoolean,KJUR.asn1.ASN1Object),KJUR.asn1.DERInteger=function(t){KJUR.asn1.DERInteger.superclass.constructor.call(this),this.hT="02",this.setByBigInteger=function(t){this.hTLV=null,this.isModified=!0,this.hV=KJUR.asn1.ASN1Util.bigIntToMinTwosComplementsHex(t)},this.setByInteger=function(t){var i=new e(String(t),10);this.setByBigInteger(i)},this.setValueHex=function(t){this.hV=t},this.getFreshValueHex=function(){return this.hV},void 0!==t&&(void 0!==t.bigint?this.setByBigInteger(t.bigint):void 0!==t.int?this.setByInteger(t.int):void 0!==t.hex&&this.setValueHex(t.hex))},j.extend(KJUR.asn1.DERInteger,KJUR.asn1.ASN1Object),KJUR.asn1.DERBitString=function(t){KJUR.asn1.DERBitString.superclass.constructor.call(this),this.hT="03",this.setHexValueIncludingUnusedBits=function(t){this.hTLV=null,this.isModified=!0,this.hV=t},this.setUnusedBitsAndHexValue=function(t,e){if(0>t||t>7)throw"unused bits shall be from 0 to 7: u = "+t;var i="0"+t;this.hTLV=null,this.isModified=!0,this.hV=i+e},this.setByBinaryString=function(t){var e=8-(t=t.replace(/0+$/,"")).length%8;8==e&&(e=0);for(var i=0;e>=i;i++)t+="0";var s="";for(i=0;i<t.length-1;i+=8){var r=t.substr(i,8),n=parseInt(r,2).toString(16);1==n.length&&(n="0"+n),s+=n}this.hTLV=null,this.isModified=!0,this.hV="0"+e+s},this.setByBooleanArray=function(t){for(var e="",i=0;i<t.length;i++)e+=1==t[i]?"1":"0";this.setByBinaryString(e)},this.newFalseArray=function(t){for(var e=new Array(t),i=0;t>i;i++)e[i]=!1;return e},this.getFreshValueHex=function(){return this.hV},void 0!==t&&(void 0!==t.hex?this.setHexValueIncludingUnusedBits(t.hex):void 0!==t.bin?this.setByBinaryString(t.bin):void 0!==t.array&&this.setByBooleanArray(t.array))},j.extend(KJUR.asn1.DERBitString,KJUR.asn1.ASN1Object),KJUR.asn1.DEROctetString=function(t){KJUR.asn1.DEROctetString.superclass.constructor.call(this,t),this.hT="04"},j.extend(KJUR.asn1.DEROctetString,KJUR.asn1.DERAbstractString),KJUR.asn1.DERNull=function(){KJUR.asn1.DERNull.superclass.constructor.call(this),this.hT="05",this.hTLV="0500"},j.extend(KJUR.asn1.DERNull,KJUR.asn1.ASN1Object),KJUR.asn1.DERObjectIdentifier=function(t){var i=function(t){var e=t.toString(16);return 1==e.length&&(e="0"+e),e},s=function(t){var s="",r=new e(t,10).toString(2),n=7-r.length%7;7==n&&(n=0);for(var o="",h=0;n>h;h++)o+="0";for(r=o+r,h=0;h<r.length-1;h+=7){var a=r.substr(h,7);h!=r.length-7&&(a="1"+a),s+=i(parseInt(a,2))}return s};KJUR.asn1.DERObjectIdentifier.superclass.constructor.call(this),this.hT="06",this.setValueHex=function(t){this.hTLV=null,this.isModified=!0,this.s=null,this.hV=t},this.setValueOidString=function(t){if(!t.match(/^[0-9.]+$/))throw"malformed oid string: "+t;var e="",r=t.split("."),n=40*parseInt(r[0])+parseInt(r[1]);e+=i(n),r.splice(0,2);for(var o=0;o<r.length;o++)e+=s(r[o]);this.hTLV=null,this.isModified=!0,this.s=null,this.hV=e},this.setValueName=function(t){if(void 0===KJUR.asn1.x509.OID.name2oidList[t])throw"DERObjectIdentifier oidName undefined: "+t;var e=KJUR.asn1.x509.OID.name2oidList[t];this.setValueOidString(e)},this.getFreshValueHex=function(){return this.hV},void 0!==t&&(void 0!==t.oid?this.setValueOidString(t.oid):void 0!==t.hex?this.setValueHex(t.hex):void 0!==t.name&&this.setValueName(t.name))},j.extend(KJUR.asn1.DERObjectIdentifier,KJUR.asn1.ASN1Object),KJUR.asn1.DERUTF8String=function(t){KJUR.asn1.DERUTF8String.superclass.constructor.call(this,t),this.hT="0c"},j.extend(KJUR.asn1.DERUTF8String,KJUR.asn1.DERAbstractString),KJUR.asn1.DERNumericString=function(t){KJUR.asn1.DERNumericString.superclass.constructor.call(this,t),this.hT="12"},j.extend(KJUR.asn1.DERNumericString,KJUR.asn1.DERAbstractString),KJUR.asn1.DERPrintableString=function(t){KJUR.asn1.DERPrintableString.superclass.constructor.call(this,t),this.hT="13"},j.extend(KJUR.asn1.DERPrintableString,KJUR.asn1.DERAbstractString),KJUR.asn1.DERTeletexString=function(t){KJUR.asn1.DERTeletexString.superclass.constructor.call(this,t),this.hT="14"},j.extend(KJUR.asn1.DERTeletexString,KJUR.asn1.DERAbstractString),KJUR.asn1.DERIA5String=function(t){KJUR.asn1.DERIA5String.superclass.constructor.call(this,t),this.hT="16"},j.extend(KJUR.asn1.DERIA5String,KJUR.asn1.DERAbstractString),KJUR.asn1.DERUTCTime=function(t){KJUR.asn1.DERUTCTime.superclass.constructor.call(this,t),this.hT="17",this.setByDate=function(t){this.hTLV=null,this.isModified=!0,this.date=t,this.s=this.formatDate(this.date,"utc"),this.hV=stohex(this.s)},void 0!==t&&(void 0!==t.str?this.setString(t.str):void 0!==t.hex?this.setStringHex(t.hex):void 0!==t.date&&this.setByDate(t.date))},j.extend(KJUR.asn1.DERUTCTime,KJUR.asn1.DERAbstractTime),KJUR.asn1.DERGeneralizedTime=function(t){KJUR.asn1.DERGeneralizedTime.superclass.constructor.call(this,t),this.hT="18",this.setByDate=function(t){this.hTLV=null,this.isModified=!0,this.date=t,this.s=this.formatDate(this.date,"gen"),this.hV=stohex(this.s)},void 0!==t&&(void 0!==t.str?this.setString(t.str):void 0!==t.hex?this.setStringHex(t.hex):void 0!==t.date&&this.setByDate(t.date))},j.extend(KJUR.asn1.DERGeneralizedTime,KJUR.asn1.DERAbstractTime),KJUR.asn1.DERSequence=function(t){KJUR.asn1.DERSequence.superclass.constructor.call(this,t),this.hT="30",this.getFreshValueHex=function(){for(var t="",e=0;e<this.asn1Array.length;e++)t+=this.asn1Array[e].getEncodedHex();return this.hV=t,this.hV}},j.extend(KJUR.asn1.DERSequence,KJUR.asn1.DERAbstractStructured),KJUR.asn1.DERSet=function(t){KJUR.asn1.DERSet.superclass.constructor.call(this,t),this.hT="31",this.getFreshValueHex=function(){for(var t=new Array,e=0;e<this.asn1Array.length;e++){var i=this.asn1Array[e];t.push(i.getEncodedHex())}return t.sort(),this.hV=t.join(""),this.hV}},j.extend(KJUR.asn1.DERSet,KJUR.asn1.DERAbstractStructured),KJUR.asn1.DERTaggedObject=function(t){KJUR.asn1.DERTaggedObject.superclass.constructor.call(this),this.hT="a0",this.hV="",this.isExplicit=!0,this.asn1Object=null,this.setASN1Object=function(t,e,i){this.hT=e,this.isExplicit=t,this.asn1Object=i,this.isExplicit?(this.hV=this.asn1Object.getEncodedHex(),this.hTLV=null,this.isModified=!0):(this.hV=null,this.hTLV=i.getEncodedHex(),this.hTLV=this.hTLV.replace(/^../,e),this.isModified=!1)},this.getFreshValueHex=function(){return this.hV},void 0!==t&&(void 0!==t.tag&&(this.hT=t.tag),void 0!==t.explicit&&(this.isExplicit=t.explicit),void 0!==t.obj&&(this.asn1Object=t.obj,this.setASN1Object(this.isExplicit,this.hT,this.asn1Object)))},j.extend(KJUR.asn1.DERTaggedObject,KJUR.asn1.ASN1Object),function(t){var e,i={decode:function(i){var s;if(e===t){var r="0123456789ABCDEF",n=" \f\n\r\t \u2028\u2029";for(e=[],s=0;16>s;++s)e[r.charAt(s)]=s;for(r=r.toLowerCase(),s=10;16>s;++s)e[r.charAt(s)]=s;for(s=0;s<n.length;++s)e[n.charAt(s)]=-1}var o=[],h=0,a=0;for(s=0;s<i.length;++s){var u=i.charAt(s);if("="==u)break;if(-1!=(u=e[u])){if(u===t)throw"Illegal character at offset "+s;h|=u,++a>=2?(o[o.length]=h,h=0,a=0):h<<=4}}if(a)throw"Hex encoding incomplete: 4 bits missing";return o}};window.Hex=i}(),function(t){var e,i={decode:function(i){var s;if(e===t){var r="= \f\n\r\t \u2028\u2029";for(e=[],s=0;64>s;++s)e["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(s)]=s;for(s=0;s<r.length;++s)e[r.charAt(s)]=-1}var n=[],o=0,h=0;for(s=0;s<i.length;++s){var a=i.charAt(s);if("="==a)break;if(-1!=(a=e[a])){if(a===t)throw"Illegal character at offset "+s;o|=a,++h>=4?(n[n.length]=o>>16,n[n.length]=o>>8&255,n[n.length]=255&o,o=0,h=0):o<<=6}}switch(h){case 1:throw"Base64 encoding incomplete: at least 2 bits missing";case 2:n[n.length]=o>>10;break;case 3:n[n.length]=o>>16,n[n.length]=o>>8&255}return n},re:/-----BEGIN [^-]+-----([A-Za-z0-9+\/=\s]+)-----END [^-]+-----|begin-base64[^\n]+\n([A-Za-z0-9+\/=\s]+)====/,unarmor:function(t){var e=i.re.exec(t);if(e)if(e[1])t=e[1];else{if(!e[2])throw"RegExp out of sync";t=e[2]}return i.decode(t)}};window.Base64=i}(),function(t){function e(t,i){t instanceof e?(this.enc=t.enc,this.pos=t.pos):(this.enc=t,this.pos=i)}function i(t,e,i,s,r){this.stream=t,this.header=e,this.length=i,this.tag=s,this.sub=r}var s=100,r=function(t,e){var i=document.createElement(t);return i.className=e,i},n=function(t){return document.createTextNode(t)};e.prototype.get=function(e){if(e===t&&(e=this.pos++),e>=this.enc.length)throw"Requesting byte offset "+e+" on a stream of length "+this.enc.length;return this.enc[e]},e.prototype.hexDigits="0123456789ABCDEF",e.prototype.hexByte=function(t){return this.hexDigits.charAt(t>>4&15)+this.hexDigits.charAt(15&t)},e.prototype.hexDump=function(t,e,i){for(var s="",r=t;e>r;++r)if(s+=this.hexByte(this.get(r)),!0!==i)switch(15&r){case 7:s+="  ";break;case 15:s+="\n";break;default:s+=" "}return s},e.prototype.parseStringISO=function(t,e){for(var i="",s=t;e>s;++s)i+=String.fromCharCode(this.get(s));return i},e.prototype.parseStringUTF=function(t,e){for(var i="",s=t;e>s;){var r=this.get(s++);i+=128>r?String.fromCharCode(r):r>191&&224>r?String.fromCharCode((31&r)<<6|63&this.get(s++)):String.fromCharCode((15&r)<<12|(63&this.get(s++))<<6|63&this.get(s++))}return i},e.prototype.parseStringBMP=function(t,e){for(var i="",s=t;e>s;s+=2){var r=this.get(s),n=this.get(s+1);i+=String.fromCharCode((r<<8)+n)}return i},e.prototype.reTime=/^((?:1[89]|2\d)?\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])(?:([0-5]\d)(?:([0-5]\d)(?:[.,](\d{1,3}))?)?)?(Z|[-+](?:[0]\d|1[0-2])([0-5]\d)?)?$/,e.prototype.parseTime=function(t,e){var i=this.parseStringISO(t,e),s=this.reTime.exec(i);return s?(i=s[1]+"-"+s[2]+"-"+s[3]+" "+s[4],s[5]&&(i+=":"+s[5],s[6]&&(i+=":"+s[6],s[7]&&(i+="."+s[7]))),s[8]&&(i+=" UTC","Z"!=s[8]&&(i+=s[8],s[9]&&(i+=":"+s[9]))),i):"Unrecognized time: "+i},e.prototype.parseInteger=function(t,e){var i=e-t;if(i>4){i<<=3;var s=this.get(t);if(0===s)i-=8;else for(;128>s;)s<<=1,--i;return"("+i+" bit)"}for(var r=0,n=t;e>n;++n)r=r<<8|this.get(n);return r},e.prototype.parseBitString=function(t,e){var i=this.get(t),s=(e-t-1<<3)-i,r="("+s+" bit)";if(20>=s){var n=i;r+=" ";for(var o=e-1;o>t;--o){for(var h=this.get(o),a=n;8>a;++a)r+=h>>a&1?"1":"0";n=0}}return r},e.prototype.parseOctetString=function(t,e){var i=e-t,r="("+i+" byte) ";i>s&&(e=t+s);for(var n=t;e>n;++n)r+=this.hexByte(this.get(n));return i>s&&(r+="…"),r},e.prototype.parseOID=function(t,e){for(var i="",s=0,r=0,n=t;e>n;++n){var o=this.get(n);if(s=s<<7|127&o,r+=7,!(128&o)){if(""===i){var h=80>s?40>s?0:1:2;i=h+"."+(s-40*h)}else i+="."+(r>=31?"bigint":s);s=r=0}}return i},i.prototype.typeName=function(){if(this.tag===t)return"unknown";var e=this.tag>>6,i=(this.tag,31&this.tag);switch(e){case 0:switch(i){case 0:return"EOC";case 1:return"BOOLEAN";case 2:return"INTEGER";case 3:return"BIT_STRING";case 4:return"OCTET_STRING";case 5:return"NULL";case 6:return"OBJECT_IDENTIFIER";case 7:return"ObjectDescriptor";case 8:return"EXTERNAL";case 9:return"REAL";case 10:return"ENUMERATED";case 11:return"EMBEDDED_PDV";case 12:return"UTF8String";case 16:return"SEQUENCE";case 17:return"SET";case 18:return"NumericString";case 19:return"PrintableString";case 20:return"TeletexString";case 21:return"VideotexString";case 22:return"IA5String";case 23:return"UTCTime";case 24:return"GeneralizedTime";case 25:return"GraphicString";case 26:return"VisibleString";case 27:return"GeneralString";case 28:return"UniversalString";case 30:return"BMPString";default:return"Universal_"+i.toString(16)}case 1:return"Application_"+i.toString(16);case 2:return"["+i+"]";case 3:return"Private_"+i.toString(16)}},i.prototype.reSeemsASCII=/^[ -~]+$/,i.prototype.content=function(){if(this.tag===t)return null;var e=this.tag>>6,i=31&this.tag,r=this.posContent(),n=Math.abs(this.length);if(0!==e){if(null!==this.sub)return"("+this.sub.length+" elem)";var o=this.stream.parseStringISO(r,r+Math.min(n,s));return this.reSeemsASCII.test(o)?o.substring(0,200)+(o.length>200?"…":""):this.stream.parseOctetString(r,r+n)}switch(i){case 1:return 0===this.stream.get(r)?"false":"true";case 2:return this.stream.parseInteger(r,r+n);case 3:return this.sub?"("+this.sub.length+" elem)":this.stream.parseBitString(r,r+n);case 4:return this.sub?"("+this.sub.length+" elem)":this.stream.parseOctetString(r,r+n);case 6:return this.stream.parseOID(r,r+n);case 16:case 17:return"("+this.sub.length+" elem)";case 12:return this.stream.parseStringUTF(r,r+n);case 18:case 19:case 20:case 21:case 22:case 26:return this.stream.parseStringISO(r,r+n);case 30:return this.stream.parseStringBMP(r,r+n);case 23:case 24:return this.stream.parseTime(r,r+n)}return null},i.prototype.toString=function(){return this.typeName()+"@"+this.stream.pos+"[header:"+this.header+",length:"+this.length+",sub:"+(null===this.sub?"null":this.sub.length)+"]"},i.prototype.print=function(e){if(e===t&&(e=""),document.writeln(e+this),null!==this.sub){e+="  ";for(var i=0,s=this.sub.length;s>i;++i)this.sub[i].print(e)}},i.prototype.toPrettyString=function(e){e===t&&(e="");var i=e+this.typeName()+" @"+this.stream.pos;if(this.length>=0&&(i+="+"),i+=this.length,32&this.tag?i+=" (constructed)":3!=this.tag&&4!=this.tag||null===this.sub||(i+=" (encapsulates)"),i+="\n",null!==this.sub){e+="  ";for(var s=0,r=this.sub.length;r>s;++s)i+=this.sub[s].toPrettyString(e)}return i},i.prototype.toDOM=function(){var t=r("div","node");t.asn1=this;var e=r("div","head"),i=this.typeName().replace(/_/g," ");e.innerHTML=i;var s=this.content();if(null!==s){s=String(s).replace(/</g,"&lt;");var o=r("span","preview");o.appendChild(n(s)),e.appendChild(o)}t.appendChild(e),this.node=t,this.head=e;var h=r("div","value");if(i="Offset: "+this.stream.pos+"<br/>",i+="Length: "+this.header+"+",i+=this.length>=0?this.length:-this.length+" (undefined)",32&this.tag?i+="<br/>(constructed)":3!=this.tag&&4!=this.tag||null===this.sub||(i+="<br/>(encapsulates)"),null!==s&&(i+="<br/>Value:<br/><b>"+s+"</b>","object"==typeof oids&&6==this.tag)){var a=oids[s];a&&(a.d&&(i+="<br/>"+a.d),a.c&&(i+="<br/>"+a.c),a.w&&(i+="<br/>(warning!)"))}h.innerHTML=i,t.appendChild(h);var u=r("div","sub");if(null!==this.sub)for(var c=0,f=this.sub.length;f>c;++c)u.appendChild(this.sub[c].toDOM());return t.appendChild(u),e.onclick=function(){t.className="node collapsed"==t.className?"node":"node collapsed"},t},i.prototype.posStart=function(){return this.stream.pos},i.prototype.posContent=function(){return this.stream.pos+this.header},i.prototype.posEnd=function(){return this.stream.pos+this.header+Math.abs(this.length)},i.prototype.fakeHover=function(t){this.node.className+=" hover",t&&(this.head.className+=" hover")},i.prototype.fakeOut=function(t){var e=/ ?hover/;this.node.className=this.node.className.replace(e,""),t&&(this.head.className=this.head.className.replace(e,""))},i.prototype.toHexDOM_sub=function(t,e,i,s,o){if(!(s>=o)){var h=r("span",e);h.appendChild(n(i.hexDump(s,o))),t.appendChild(h)}},i.prototype.toHexDOM=function(e){var i=r("span","hex");if(e===t&&(e=i),this.head.hexNode=i,this.head.onmouseover=function(){this.hexNode.className="hexCurrent"},this.head.onmouseout=function(){this.hexNode.className="hex"},i.asn1=this,i.onmouseover=function(){var t=!e.selected;t&&(e.selected=this.asn1,this.className="hexCurrent"),this.asn1.fakeHover(t)},i.onmouseout=function(){var t=e.selected==this.asn1;this.asn1.fakeOut(t),t&&(e.selected=null,this.className="hex")},this.toHexDOM_sub(i,"tag",this.stream,this.posStart(),this.posStart()+1),this.toHexDOM_sub(i,this.length>=0?"dlen":"ulen",this.stream,this.posStart()+1,this.posContent()),null===this.sub)i.appendChild(n(this.stream.hexDump(this.posContent(),this.posEnd())));else if(this.sub.length>0){var s=this.sub[0],o=this.sub[this.sub.length-1];this.toHexDOM_sub(i,"intro",this.stream,this.posContent(),s.posStart());for(var h=0,a=this.sub.length;a>h;++h)i.appendChild(this.sub[h].toHexDOM(e));this.toHexDOM_sub(i,"outro",this.stream,o.posEnd(),this.posEnd())}return i},i.prototype.toHexString=function(t){return this.stream.hexDump(this.posStart(),this.posEnd(),!0)},i.decodeLength=function(t){var e=t.get(),i=127&e;if(i==e)return i;if(i>3)throw"Length over 24 bits not supported at position "+(t.pos-1);if(0===i)return-1;e=0;for(var s=0;i>s;++s)e=e<<8|t.get();return e},i.hasContent=function(t,s,r){if(32&t)return!0;if(3>t||t>4)return!1;var n=new e(r);if(3==t&&n.get(),n.get()>>6&1)return!1;try{var o=i.decodeLength(n);return n.pos-r.pos+o==s}catch(h){return!1}},i.decode=function(t){t instanceof e||(t=new e(t,0));var s=new e(t),r=t.get(),n=i.decodeLength(t),o=t.pos-s.pos,h=null;if(i.hasContent(r,n,t)){var a=t.pos;if(3==r&&t.get(),h=[],n>=0){for(var u=a+n;t.pos<u;)h[h.length]=i.decode(t);if(t.pos!=u)throw"Content size is not correct for container starting at offset "+a}else try{for(;;){var c=i.decode(t);if(0===c.tag)break;h[h.length]=c}n=a-t.pos}catch(f){throw"Exception while decoding undefined length content: "+f}}else t.pos+=n;return new i(s,o,n,r,h)},i.test=function(){for(var t=[{value:[39],expected:39},{value:[129,201],expected:201},{value:[131,254,220,186],expected:16702650}],s=0,r=t.length;r>s;++s){var n=new e(t[s].value,0),o=i.decodeLength(n);o!=t[s].expected&&document.write("In test["+s+"] expected "+t[s].expected+" got "+o+"\n")}},window.ASN1=i}(),ASN1.prototype.getHexStringValue=function(){var t=this.toHexString(),e=2*this.header,i=2*this.length;return t.substr(e,i)},D.prototype.parseKey=function(t){try{var e=0,i=0,s=/^\s*(?:[0-9A-Fa-f][0-9A-Fa-f]\s*)+$/.test(t)?Hex.decode(t):Base64.unarmor(t),r=ASN1.decode(s);if(3===r.sub.length&&(r=r.sub[2].sub[0]),9===r.sub.length){e=r.sub[1].getHexStringValue(),this.n=R(e,16),i=r.sub[2].getHexStringValue(),this.e=parseInt(i,16);var n=r.sub[3].getHexStringValue();this.d=R(n,16);var o=r.sub[4].getHexStringValue();this.p=R(o,16);var h=r.sub[5].getHexStringValue();this.q=R(h,16);var a=r.sub[6].getHexStringValue();this.dmp1=R(a,16);var u=r.sub[7].getHexStringValue();this.dmq1=R(u,16);var c=r.sub[8].getHexStringValue();this.coeff=R(c,16)}else{if(2!==r.sub.length)return!1;var f=r.sub[1].sub[0];e=f.sub[0].getHexStringValue(),this.n=R(e,16),i=f.sub[1].getHexStringValue(),this.e=parseInt(i,16)}return!0}catch(p){return!1}},D.prototype.getPrivateBaseKey=function(){var t={array:[new KJUR.asn1.DERInteger({int:0}),new KJUR.asn1.DERInteger({bigint:this.n}),new KJUR.asn1.DERInteger({int:this.e}),new KJUR.asn1.DERInteger({bigint:this.d}),new KJUR.asn1.DERInteger({bigint:this.p}),new KJUR.asn1.DERInteger({bigint:this.q}),new KJUR.asn1.DERInteger({bigint:this.dmp1}),new KJUR.asn1.DERInteger({bigint:this.dmq1}),new KJUR.asn1.DERInteger({bigint:this.coeff})]};return new KJUR.asn1.DERSequence(t).getEncodedHex()},D.prototype.getPrivateBaseKeyB64=function(){return w(this.getPrivateBaseKey())},D.prototype.getPublicBaseKey=function(){var t={array:[new KJUR.asn1.DERObjectIdentifier({oid:"1.2.840.113549.1.1.1"}),new KJUR.asn1.DERNull]},e=new KJUR.asn1.DERSequence(t);return t={array:[new KJUR.asn1.DERInteger({bigint:this.n}),new KJUR.asn1.DERInteger({int:this.e})]},t={hex:"00"+new KJUR.asn1.DERSequence(t).getEncodedHex()},t={array:[e,new KJUR.asn1.DERBitString(t)]},new KJUR.asn1.DERSequence(t).getEncodedHex()},D.prototype.getPublicBaseKeyB64=function(){return w(this.getPublicBaseKey())},D.prototype.wordwrap=function(t,e){if(!t)return t;var i="(.{1,"+(e=e||64)+"})( +|$\n?)|(.{1,"+e+"})";return t.match(RegExp(i,"g")).join("\n")},D.prototype.getPrivateKey=function(){var t="-----BEGIN RSA PRIVATE KEY-----\n";return(t+=this.wordwrap(this.getPrivateBaseKeyB64())+"\n")+"-----END RSA PRIVATE KEY-----"},D.prototype.getPublicKey=function(){var t="-----BEGIN PUBLIC KEY-----\n";return(t+=this.wordwrap(this.getPublicBaseKeyB64())+"\n")+"-----END PUBLIC KEY-----"},D.prototype.hasPublicKeyProperty=function(t){return(t=t||{}).hasOwnProperty("n")&&t.hasOwnProperty("e")},D.prototype.hasPrivateKeyProperty=function(t){return(t=t||{}).hasOwnProperty("n")&&t.hasOwnProperty("e")&&t.hasOwnProperty("d")&&t.hasOwnProperty("p")&&t.hasOwnProperty("q")&&t.hasOwnProperty("dmp1")&&t.hasOwnProperty("dmq1")&&t.hasOwnProperty("coeff")},D.prototype.parsePropertiesFrom=function(t){this.n=t.n,this.e=t.e,t.hasOwnProperty("d")&&(this.d=t.d,this.p=t.p,this.q=t.q,this.dmp1=t.dmp1,this.dmq1=t.dmq1,this.coeff=t.coeff)};var z=function(t){D.call(this),t&&("string"==typeof t?this.parseKey(t):(this.hasPrivateKeyProperty(t)||this.hasPublicKeyProperty(t))&&this.parsePropertiesFrom(t))};(z.prototype=new D).constructor=z;var Z=function(t){t=t||{},this.default_key_size=parseInt(t.default_key_size)||1024,this.default_public_exponent=t.default_public_exponent||"010001",this.log=t.log||!1,this.key=null};Z.prototype.setKey=function(t){this.log&&this.key,this.key=new z(t)},Z.prototype.setPrivateKey=function(t){this.setKey(t)},Z.prototype.setPublicKey=function(t){this.setKey(t)},Z.prototype.decrypt=function(t){try{return this.getKey().decrypt(function(t){var e,i,r="",n=0;for(e=0;e<t.length&&t.charAt(e)!=H;++e)v=C.indexOf(t.charAt(e)),v<0||(0==n?(r+=s(v>>2),i=3&v,n=1):1==n?(r+=s(i<<2|v>>4),i=15&v,n=2):2==n?(r+=s(i),r+=s(v>>2),i=3&v,n=3):(r+=s(i<<2|v>>4),r+=s(15&v),n=0));return 1==n&&(r+=s(i<<2)),r}(t))}catch(e){return!1}},Z.prototype.encrypt=function(t){try{return w(this.getKey().encrypt(t))}catch(e){return!1}},Z.prototype.getKey=function(t){if(!this.key){if(this.key=new z,t&&"[object Function]"==={}.toString.call(t))return void this.key.generateAsync(this.default_key_size,this.default_public_exponent,t);this.key.generate(this.default_key_size,this.default_public_exponent)}return this.key},Z.prototype.getPrivateKey=function(){return this.getKey().getPrivateKey()},Z.prototype.getPrivateKeyB64=function(){return this.getKey().getPrivateBaseKeyB64()},Z.prototype.getPublicKey=function(){return this.getKey().getPublicKey()},Z.prototype.getPublicKeyB64=function(){return this.getKey().getPublicBaseKeyB64()},Z.version="2.3.1",t.JSEncrypt=Z},"function"==typeof define&&define.amd?define(["exports"],e):e("object"==typeof exports&&"string"!=typeof exports.nodeName?module.exports:t);
});
__maRoute='app';require("app.js");
__maRoute='pages/index/index';require("pages/index/index.js");
__maRoute='pages/product-detail/product-detail';require("pages/product-detail/product-detail.js");
