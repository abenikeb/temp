var __maAppData=__maAppData||{};
var __maRoute=__maRoute||"";
var __layer__='service';
var __maAppCode__=__maAppCode__||{};
var global=global||{};
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false}; 
var Component=Component||function(){};
var __maI18nResource__=__maI18nResource__||{};
(function (i18nRes) {
  // Merge i18n resource in subpackage scenario
  var newI18nRes={"en-US":{"test":"test messages","test2":"test message 2, {label}, {label2}","nested":"nested message: {test}","nested2":"nested message2: {obj.nested.value}","toggle":"Toggle locale","navigate":"Navigate to Log","window.title":"I18n","log":"log","cancelEvent":"cancel localChange event","selectTest":"{gender, select, male {male} female {female} other {other}}","selectTestNest":"{mood, select, good {{how} day!} sad {{how} day.} other {Whatever!}}","component":"Component","ui":"UI","api":"API","framework":"Framework"},"zh-CN":{"test":"Test Messages","test2":"Test message 2, {label}, {label2}","nested":"Nested Messages: {test}","nested2":"Nested message 2: {obj.nested.value}","toggle":"Switch Language","navigate":"redirect ","window.title":"Internationalization","log":"log","cancelEvent":"Listening event for canceling language change","selectTest":"{gender, select, male  female  other }","selectTestNest":"{mood, select, good {{how}Weather!} sad {{how}Weather.} other {other!}}","component":"component","ui":"extension component","api":"interface","framework":"framework"}};
  for(var locale in newI18nRes){
    if(i18nRes[locale]){
      for(var key in newI18nRes[locale]){
        i18nRes[locale][key] = newI18nRes[locale][key];
      }
    }else{
      i18nRes[locale]=newI18nRes[locale];
    }
  }
})(__maI18nResource__)

/* maml-transpiler v22.12.0 2022-12-29 11:21:52 */
window.__maml_transpiler_version__='v22.12.0'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'onChildMethod']);
      Z([3,'A subcomponent invokes its subcomponent method']);
      Z([3,'trigger']);
      Z([11,[[7],[3,"text"]],[3,'\r\n        Subcomponent page component. Click to invoke the parent component method to display the subcomponents of the subcomponent']]);
      Z([[7],[3,"isDispalyItem"]]);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'onMyEvent']);
      Z([3,'test_color']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'trigger']);
      Z([3,'Subassembly of Subassembly'])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  function gz$gma_3(){
    if(__MAML_GLOBAL__.ops_cached.$gma_3)return __MAML_GLOBAL__.ops_cached.$gma_3
    __MAML_GLOBAL__.ops_cached.$gma_3=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a custom componentA，My presentation is light orange"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 2 each time']);
      Z([11,[[7],[3,"count"]]]);
      Z([[6],[[7],[3,"detail"]],[3,"list"]]);
      Z([3,'item']);
      Z([3,'name']);
      Z([3,'background: #7fffd4']);
      Z([[7],[3,"item"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_3);
    return __MAML_GLOBAL__.ops_cached.$gma_3
  }
  function gz$gma_4(){
    if(__MAML_GLOBAL__.ops_cached.$gma_4)return __MAML_GLOBAL__.ops_cached.$gma_4
    __MAML_GLOBAL__.ops_cached.$gma_4=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'child-box']);
      Z([3,'head']);
      Z([[8],"title",[1,"I am a subcomponent of custom component A，My color is light green"]]);
      Z([3,'addCount']);
      Z([3,'Click me to add 3 each time']);
      Z([11,[[7],[3,"count"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_4);
    return __MAML_GLOBAL__.ops_cached.$gma_4
  }
  function gz$gma_5(){
    if(__MAML_GLOBAL__.ops_cached.$gma_5)return __MAML_GLOBAL__.ops_cached.$gma_5
    __MAML_GLOBAL__.ops_cached.$gma_5=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-foot']);
      Z([3,'none']);
      Z([3,'switchTab']);
      Z([3,'/page/tabbar/component/index']);
      Z([3,'icon-foot']);
      Z([3,'../../../../image/icon_foot.png'])
    })(__MAML_GLOBAL__.ops_cached.$gma_5);
    return __MAML_GLOBAL__.ops_cached.$gma_5
  }
  function gz$gma_6(){
    if(__MAML_GLOBAL__.ops_cached.$gma_6)return __MAML_GLOBAL__.ops_cached.$gma_6
    __MAML_GLOBAL__.ops_cached.$gma_6=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'page-head']);
      Z([3,'page-head-title']);
      Z([11,[[7],[3,"title"]]]);
      Z([3,'page-head-line']);
      Z([[7],[3,"desc"]]);
      Z([3,'page-head-desc']);
      Z([11,[[7],[3,"desc"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_6);
    return __MAML_GLOBAL__.ops_cached.$gma_6
  }
  function gz$gma_7(){
    if(__MAML_GLOBAL__.ops_cached.$gma_7)return __MAML_GLOBAL__.ops_cached.$gma_7
    __MAML_GLOBAL__.ops_cached.$gma_7=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"tabBar"]]);
      Z([3,'page-body']);
      Z([3,'btn-area']);
      Z([3,'showTabBarRedDot']);
      Z([3,'tabBarRedDot']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasShownTabBarRedDot"]]],[1,"Show red dots"],[1,"Remove Red Dots"]]]);
      Z([3,'customStyle']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedStyle"]]],[1,"Custom Tab Styles"],[1,"Remove Custom Styles"]]]);
      Z([3,'customItem']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasCustomedItem"]]],[1,"Customizing Tab Information"],[1,"Remove Custom Information"]]]);
      Z([3,'hideTabBar']);
      Z([3,'showOrHideTabBar']);
      Z([11,[[2,'?:'],[[2,"!"],[[7],[3,"hasHiddenTabBar"]]],[1,"Hide TabBar"],[1,"Show TabBar"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_7);
    return __MAML_GLOBAL__.ops_cached.$gma_7
  }
  function gz$gma_8(){
    if(__MAML_GLOBAL__.ops_cached.$gma_8)return __MAML_GLOBAL__.ops_cached.$gma_8
    __MAML_GLOBAL__.ops_cached.$gma_8=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[7],[3,"isSetTabBarPage"]]);
      Z([3,'leaveSetTabBarPage']);
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the API capability of the applet. For details about the attribute parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/api/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([[2,"!=="], [[6],[[7],[3,"page"]],[3,"url"]], [1,"set-tab-bar/set-tab-bar"]]);
      Z([3,'navigator']);
      Z([11,[3,'/page/API/pages/'],[[6],[[7],[3,"page"]],[3,"url"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"zh"]]]);
      Z([3,'navigator-arrow']);
      Z([3,'enterSetTabBarPage'])
    })(__MAML_GLOBAL__.ops_cached.$gma_8);
    return __MAML_GLOBAL__.ops_cached.$gma_8
  }
  function gz$gma_9(){
    if(__MAML_GLOBAL__.ops_cached.$gma_9)return __MAML_GLOBAL__.ops_cached.$gma_9
    __MAML_GLOBAL__.ops_cached.$gma_9=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the capabilities of the applet component. For details about the attributes and parameters, see the applet development document.']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([[2,"!=="], [[6],[[7],[3,"item"]],[3,"id"]], [1,"page-meta"]]);
      Z([11,[3,'kind-list-img kind-list-img-'],[[6],[[7],[3,"item"]],[3,"id"]]]);
      Z([11,[3,'/page/tabbar/resources/component/kind/'],[[6],[[7],[3,"item"]],[3,"id"]],[3,'.png']]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([11,[3,'navigator-'],[[6],[[7],[3,"page"]],[3,"id"]]]);
      Z([11,[3,'/page/component/pages/'],[[6],[[7],[3,"page"]],[3,"name"]],[3,'/'],[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-content']);
      Z([[6],[[7],[3,"page"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"page"]],[3,"name"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_9);
    return __MAML_GLOBAL__.ops_cached.$gma_9
  }
  function gz$gma_10(){
    if(__MAML_GLOBAL__.ops_cached.$gma_10)return __MAML_GLOBAL__.ops_cached.$gma_10
    __MAML_GLOBAL__.ops_cached.$gma_10=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'index']);
      Z([3,'index-hd']);
      Z([3,'index-desc']);
      Z([3,'The following describes the applet framework capability. For details about the attributes and parameters, see the applet development document。']);
      Z([3,'index-bd']);
      Z([3,'kind-list']);
      Z([[7],[3,"list"]]);
      Z([3,'item']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'kind-list-item']);
      Z([3,'kindToggle']);
      Z([11,[3,'kind-list-'],[[6],[[7],[3,"item"]],[3,"id"]],[3,' kind-list-item-hd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-hd-show"],[1,""]]]);
      Z([3,'kind-list-text']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[3,'kind-list-item-bd '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"kind-list-item-bd-show"],[1,""]]]);
      Z([11,[3,'navigator-box '],[[2,'?:'],[[6],[[7],[3,"item"]],[3,"open"]],[1,"navigator-box-show"],[1,""]]]);
      Z([[6],[[7],[3,"item"]],[3,"pages"]]);
      Z([3,'page']);
      Z([3,'*item']);
      Z([11,[3,'navigator navigator-'],[[7],[3,"page"]]]);
      Z([11,[3,'/page/framework/pages/'],[[7],[3,"page"]],[3,'/'],[[7],[3,"page"]]]);
      Z([3,'navigator-content']);
      Z([11,[[7],[3,"page"]]]);
      Z([3,'navigator-arrow'])
    })(__MAML_GLOBAL__.ops_cached.$gma_10);
    return __MAML_GLOBAL__.ops_cached.$gma_10
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={"p_./page/util/common.sjs":sm_0}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()
  f_['./page/util/common.sjs']=sjs_require("p_./page/util/common.sjs");
  function sm_0(){var sjs_module={sjs_exports:{}};var sjs_starLeft=0;var sjs_starTop=0;var sjs_starX=0;var sjs_starY=0;function sjs_liveTouchmove(sjs_event,sjs_ownerInstance){var sjs_left=0,sjs_top=0;var sjs_diffX=0,sjs_diffY=0;if(sjs_event.sjs_type==="touchstart"){sjs_starLeft=sjs_event.sjs_currentTarget.sjs_offsetLeft;sjs_starTop=sjs_event.sjs_currentTarget.sjs_offsetTop;sjs_starX=sjs_event.sjs_changedTouches[0].sjs_clientX;sjs_starY=sjs_event.sjs_changedTouches[0].sjs_clientY;sjs_left=sjs_starLeft;sjs_top=sjs_starTop}else{sjs_diffX=sjs_event.sjs_changedTouches[0].sjs_clientX-sjs_starX;sjs_diffY=sjs_event.sjs_changedTouches[0].sjs_clientY-sjs_starY;sjs_left=sjs_starLeft+sjs_diffX;sjs_top=sjs_starTop+sjs_diffY}sjs_left=sjs_left+"px";var sjs_instance=sjs_ownerInstance.sjs_selectComponent(".liveMove");sjs_instance.sjs_setStyle({sjs_left:sjs_left,sjs_top:sjs_top+"px"})}function sjs_clickLive(sjs_event,sjs_ownerInstance){sjs_ownerInstance.sjs_callMethod("bindEnter")}sjs_module.sjs_exports={sjs_liveTouchmove:sjs_liveTouchmove,sjs_clickLive:sjs_clickLive};return sjs_module.sjs_exports;}

  
  d_["./component/communication-detail/index.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var o_DC=e_["./component/communication-detail/index.maml"].i;_ai(o_DC,'../../page/common/head.maml',e_,'./component/communication-detail/index.maml',0,0);var oBEC=_ctn("view");var oCEC=_ctn("button");_setAttr(z,oCEC,'bindtap',0,e,s,gg);var oDEC=_o(z,1,e,s,gg);_ac(oCEC,oDEC);_ac(oBEC,oCEC);var oEEC=_ctn("button");_setAttr(z,oEEC,'bindtap',2,e,s,gg);var oFEC=_o(z,3,e,s,gg);_ac(oEEC,oFEC);_ac(oBEC,oEEC);var oGEC=_cvn();if(_o(z,4,e,s,gg)){oGEC.maVkey=1;var oHEC=_ctn("view");var oJEC=_cvn();var oKEC=function(oOEC,oNEC,oMEC,gg){var oLEC=_setAttrs(z,"detailItem",["bind:myevent",8,"class",1,"item",2],oOEC,oNEC,gg);_ac(oMEC,oLEC);return oMEC;};_2(z,5,oKEC,e,s,gg,oJEC,"item","index",'name');_ac(oHEC,oJEC);var oQEC=_ctn("slot");_ac(oHEC,oQEC);_ac(oGEC,oHEC);} _ac(oBEC,oGEC);_ac(r,oBEC);o_DC.pop();
    return r;
  };
  e_["./component/communication-detail/index.maml"]={f:m0,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/communication-detailItem/index.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var oREC=e_["./component/communication-detailItem/index.maml"].i;_ai(oREC,'../../page/common/head.maml',e_,'./component/communication-detailItem/index.maml',0,0);var oTEC=_ctn("view");var oUEC=_ctn("button");_setAttr(z,oUEC,'bindtap',0,e,s,gg);var oVEC=_o(z,1,e,s,gg);_ac(oUEC,oVEC);_ac(oTEC,oUEC);_ac(r,oTEC);oREC.pop();
    return r;
  };
  e_["./component/communication-detailItem/index.maml"]={f:m1,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/detail/index.maml"]={};
  var m2=function(e,s,r,gg){
    var z=gz$gma_3()
    var oWEC=e_["./component/detail/index.maml"].i;_ai(oWEC,'../../page/common/head.maml',e_,'./component/detail/index.maml',0,0);var oYEC=_ctn("view");_setAttr(z,oYEC,'class',0,e,s,gg);var oZEC=_cvn();
    var oaEC=_o(z,1,e,s,gg);
    var obEC=_gd('./component/detail/index.maml',oaEC,e_,d_);
    if(obEC){
      var ocEC=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      obEC(ocEC,ocEC,oZEC,gg);
      gg.f=tgf;
    }else{
      _w(oaEC,'./component/detail/index.maml',0,0);
    }
    _ac(oYEC,oZEC);var odEC=_ctn("button");_setAttr(z,odEC,'bindtap',3,e,s,gg);var oeEC=_o(z,4,e,s,gg);_ac(odEC,oeEC);_ac(oYEC,odEC);var ofEC=_ctn("button");var ogEC=_o(z,5,e,s,gg);_ac(ofEC,ogEC);_ac(oYEC,ofEC);var ohEC=_cvn();var oiEC=function(omEC,olEC,okEC,gg){var ojEC=_ctn("view");_setAttr(z,ojEC,'style',9,omEC,olEC,gg);var ooEC=_ctn("detailItem");_setAttr(z,ooEC,'item',10,omEC,olEC,gg);_ac(ojEC,ooEC);_ac(okEC,ojEC);return okEC;};_2(z,6,oiEC,e,s,gg,ohEC,"item","index",'name');_ac(oYEC,ohEC);_ac(r,oYEC);oWEC.pop();
    return r;
  };
  e_["./component/detail/index.maml"]={f:m2,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./component/detailItem/index.maml"]={};
  var m3=function(e,s,r,gg){
    var z=gz$gma_4()
    var opEC=e_["./component/detailItem/index.maml"].i;_ai(opEC,'../../page/common/head.maml',e_,'./component/detailItem/index.maml',0,0);var orEC=_ctn("view");_setAttr(z,orEC,'class',0,e,s,gg);var osEC=_cvn();
    var otEC=_o(z,1,e,s,gg);
    var ouEC=_gd('./component/detailItem/index.maml',otEC,e_,d_);
    if(ouEC){
      var ovEC=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ouEC(ovEC,ovEC,osEC,gg);
      gg.f=tgf;
    }else{
      _w(otEC,'./component/detailItem/index.maml',0,0);
    }
    _ac(orEC,osEC);var owEC=_ctn("button");_setAttr(z,owEC,'bindtap',3,e,s,gg);var oxEC=_o(z,4,e,s,gg);_ac(owEC,oxEC);_ac(orEC,owEC);var oyEC=_ctn("button");var ozEC=_o(z,5,e,s,gg);_ac(oyEC,ozEC);_ac(orEC,oyEC);_ac(r,orEC);opEC.pop();
    return r;
  };
  e_["./component/detailItem/index.maml"]={f:m3,j:[],i:[],ti:["../../page/common/head.maml"],ic:[]};

  d_["./page/common/foot.maml"]={};
  d_["./page/common/foot.maml"]["foot"]=function(e,s,r,gg){
    var z=gz$gma_5(),b='./page/common/foot.maml:foot'
    r.maVkey=b
    gg.f=$gdc(f_["./page/common/foot.maml"],"",1)
    if(p_[b]){_wl(b,'./page/common/foot.maml');return}
    p_[b]=true
    try{
      var oAFC=_setAttrs(z,"navigator",["class",0,"hoverClass",1,"openType",1,"url",2],e,s,gg);var oBFC=_setAttrs(z,"image",["class",4,"src",1],e,s,gg);_ac(oAFC,oBFC);_ac(r,oAFC);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m4=function(e,s,r,gg){
    var z=gz$gma_5()
    
    return r;
  };
  e_["./page/common/foot.maml"]={f:m4,j:[],i:[],ti:[],ic:[]};

  d_["./page/common/head.maml"]={};
  d_["./page/common/head.maml"]["head"]=function(e,s,r,gg){
    var z=gz$gma_6(),b='./page/common/head.maml:head'
    r.maVkey=b
    gg.f=$gdc(f_["./page/common/head.maml"],"",1)
    if(p_[b]){_wl(b,'./page/common/head.maml');return}
    p_[b]=true
    try{
      var oFFC=_ctn("view");_setAttr(z,oFFC,'class',0,e,s,gg);var oGFC=_ctn("view");_setAttr(z,oGFC,'class',1,e,s,gg);var oHFC=_o(z,2,e,s,gg);_ac(oGFC,oHFC);_ac(oFFC,oGFC);var oIFC=_ctn("view");_setAttr(z,oIFC,'class',3,e,s,gg);_ac(oFFC,oIFC);var oJFC=_cvn();if(_o(z,4,e,s,gg)){oJFC.maVkey=1;var oKFC=_ctn("view");_setAttr(z,oKFC,'class',5,e,s,gg);var oMFC=_o(z,6,e,s,gg);_ac(oKFC,oMFC);_ac(oJFC,oKFC);} _ac(oFFC,oJFC);_ac(r,oFFC);
    }catch(e){
      p_[b]=false
      throw e
    }
    p_[b]=false
    return r
  };
  var m5=function(e,s,r,gg){
    var z=gz$gma_6()
    
    return r;
  };
  e_["./page/common/head.maml"]={f:m5,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={};
  var m6=function(e,s,r,gg){
    var z=gz$gma_7()
    var oPFC=e_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"].i;_ai(oPFC,'../../../../common/head.maml',e_,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);_ai(oPFC,'../../../../common/foot.maml',e_,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);var oSFC=_ctn("view");_setAttr(z,oSFC,'class',0,e,s,gg);var oTFC=_cvn();
    var oUFC=_o(z,1,e,s,gg);
    var oVFC=_gd('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',oUFC,e_,d_);
    if(oVFC){
      var oWFC=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oVFC(oWFC,oWFC,oTFC,gg);
      gg.f=tgf;
    }else{
      _w(oUFC,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(oSFC,oTFC);var oXFC=_ctn("view");_setAttr(z,oXFC,'class',3,e,s,gg);var oYFC=_ctn("view");_setAttr(z,oYFC,'class',4,e,s,gg);var oZFC=_setAttrs(z,"button",["bindtap",5,"class",1],e,s,gg);var oaFC=_o(z,7,e,s,gg);_ac(oZFC,oaFC);_ac(oYFC,oZFC);var obFC=_setAttrs(z,"button",["bindtap",8,"class",0],e,s,gg);var ocFC=_o(z,9,e,s,gg);_ac(obFC,ocFC);_ac(oYFC,obFC);var odFC=_setAttrs(z,"button",["bindtap",10,"class",0],e,s,gg);var oeFC=_o(z,11,e,s,gg);_ac(odFC,oeFC);_ac(oYFC,odFC);var ofFC=_setAttrs(z,"button",["bindtap",12,"class",1],e,s,gg);var ogFC=_o(z,14,e,s,gg);_ac(ofFC,ogFC);_ac(oYFC,ofFC);_ac(oXFC,oYFC);_ac(oSFC,oXFC);var ohFC=_cvn();
    var oiFC=_o(z,15,e,s,gg);
    var ojFC=_gd('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',oiFC,e_,d_);
    if(ojFC){
      var okFC={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ojFC(okFC,okFC,ohFC,gg);
      gg.f=tgf;
    }else{
      _w(oiFC,'./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml',0,0);
    }
    _ac(oSFC,ohFC);_ac(r,oSFC);oPFC.pop();oPFC.pop();
    return r;
  };
  e_["./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml"]={f:m6,j:[],i:[],ti:["../../../../common/head.maml","../../../../common/foot.maml"],ic:[]};

  d_["./page/tabbar/api/index.maml"]={};
  var m7=function(e,s,r,gg){
    var z=gz$gma_8()
    var omFC=_cvn();if(_o(z,0,e,s,gg)){omFC.maVkey=1;var onFC=_ctn("set-tab-bar");_setAttr(z,onFC,'bindunmount',1,e,s,gg);_ac(omFC,onFC);}else{omFC.maVkey=2;var opFC=_ctn("view");_setAttr(z,opFC,'class',2,e,s,gg);var orFC=_ctn("view");_setAttr(z,orFC,'class',3,e,s,gg);var osFC=_ctn("view");_setAttr(z,osFC,'class',4,e,s,gg);var otFC=_o(z,5,e,s,gg);_ac(osFC,otFC);_ac(orFC,osFC);_ac(opFC,orFC);var ouFC=_ctn("view");_setAttr(z,ouFC,'class',6,e,s,gg);var ovFC=_ctn("view");_setAttr(z,ovFC,'class',7,e,s,gg);var owFC=_cvn();var oxFC=function(oAGC,o_FC,ozFC,gg){var oCGC=_ctn("view");_setAttr(z,oCGC,'class',10,oAGC,o_FC,gg);var oDGC=_setAttrs(z,"view",["id",9,"bindtap",2,"class",3],oAGC,o_FC,gg);var oEGC=_ctn("view");_setAttr(z,oEGC,'class',13,oAGC,o_FC,gg);var oFGC=_o(z,14,oAGC,o_FC,gg);_ac(oEGC,oFGC);_ac(oDGC,oEGC);var oGGC=_setAttrs(z,"image",["class",15,"src",1],oAGC,o_FC,gg);_ac(oDGC,oGGC);_ac(oCGC,oDGC);var oHGC=_ctn("view");_setAttr(z,oHGC,'class',17,oAGC,o_FC,gg);var oIGC=_ctn("view");_setAttr(z,oIGC,'class',18,oAGC,o_FC,gg);var oJGC=_cvn();var oKGC=function(oOGC,oNGC,oMGC,gg){var oQGC=_cvn();if(_o(z,22,oOGC,oNGC,gg)){oQGC.maVkey=1;var oRGC=_setAttrs(z,"navigator",["class",23,"url",1],oOGC,oNGC,gg);var oTGC=_setAttrs(z,"view",["class",25,"id",1],oOGC,oNGC,gg);var oUGC=_o(z,27,oOGC,oNGC,gg);_ac(oTGC,oUGC);_ac(oRGC,oTGC);var oVGC=_ctn("view");_setAttr(z,oVGC,'class',28,oOGC,oNGC,gg);_ac(oRGC,oVGC);_ac(oQGC,oRGC);}else{oQGC.maVkey=2;var oWGC=_setAttrs(z,"view",["class",23,"bindtap",6],e,s,gg);var oYGC=_setAttrs(z,"view",["class",25,"id",1],e,s,gg);var oZGC=_o(z,27,e,s,gg);_ac(oYGC,oZGC);_ac(oWGC,oYGC);var oaGC=_ctn("view");_setAttr(z,oaGC,'class',28,e,s,gg);_ac(oWGC,oaGC);_ac(oQGC,oWGC);}_ac(oMGC,oQGC);return oMGC;};_2(z,19,oKGC,oAGC,o_FC,gg,oJGC,"page","index",'*item');_ac(oIGC,oJGC);_ac(oHGC,oIGC);_ac(oCGC,oHGC);_ac(ozFC,oCGC);return ozFC;};_2(z,8,oxFC,e,s,gg,owFC,"item","index",'{{item.id}}');_ac(ovFC,owFC);_ac(ouFC,ovFC);_ac(opFC,ouFC);_ac(omFC,opFC);}_ac(r,omFC);
    return r;
  };
  e_["./page/tabbar/api/index.maml"]={f:m7,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/component/index.maml"]={};
  var m8=function(e,s,r,gg){
    var z=gz$gma_9()
    var ocGC=_ctn("view");_setAttr(z,ocGC,'class',0,e,s,gg);var odGC=_ctn("view");_setAttr(z,odGC,'class',1,e,s,gg);var oeGC=_ctn("view");_setAttr(z,oeGC,'class',2,e,s,gg);var ofGC=_o(z,3,e,s,gg);_ac(oeGC,ofGC);_ac(odGC,oeGC);_ac(ocGC,odGC);var ogGC=_ctn("view");_setAttr(z,ogGC,'class',4,e,s,gg);var ohGC=_ctn("view");_setAttr(z,ohGC,'class',5,e,s,gg);var oiGC=_cvn();var ojGC=function(onGC,omGC,olGC,gg){var opGC=_ctn("view");_setAttr(z,opGC,'class',9,onGC,omGC,gg);var oqGC=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],onGC,omGC,gg);var orGC=_ctn("view");_setAttr(z,orGC,'class',12,onGC,omGC,gg);var osGC=_o(z,13,onGC,omGC,gg);_ac(orGC,osGC);_ac(oqGC,orGC);var otGC=_cvn();if(_o(z,14,onGC,omGC,gg)){otGC.maVkey=1;var ouGC=_setAttrs(z,"image",["class",15,"src",1],onGC,omGC,gg);_ac(otGC,ouGC);} _ac(oqGC,otGC);_ac(opGC,oqGC);var owGC=_ctn("view");_setAttr(z,owGC,'class',17,onGC,omGC,gg);var oxGC=_ctn("view");_setAttr(z,oxGC,'class',18,onGC,omGC,gg);var oyGC=_cvn();var ozGC=function(oCHC,oBHC,oAHC,gg){var oEHC=_setAttrs(z,"navigator",["class",22,"id",1,"url",2],oCHC,oBHC,gg);var oFHC=_setAttrs(z,"view",["class",25,"id",1],oCHC,oBHC,gg);var oGHC=_o(z,27,oCHC,oBHC,gg);_ac(oFHC,oGHC);_ac(oEHC,oFHC);var oHHC=_ctn("view");_setAttr(z,oHHC,'class',28,oCHC,oBHC,gg);_ac(oEHC,oHHC);_ac(oAHC,oEHC);return oAHC;};_2(z,19,ozGC,onGC,omGC,gg,oyGC,"page","index",'*item');_ac(oxGC,oyGC);_ac(owGC,oxGC);_ac(opGC,owGC);_ac(olGC,opGC);return olGC;};_2(z,6,ojGC,e,s,gg,oiGC,"item","index",'{{item.id}}');_ac(ohGC,oiGC);_ac(ogGC,ohGC);_ac(ocGC,ogGC);_ac(r,ocGC);
    return r;
  };
  e_["./page/tabbar/component/index.maml"]={f:m8,j:[],i:[],ti:[],ic:[]};

  d_["./page/tabbar/framework/index.maml"]={};
  var m9=function(e,s,r,gg){
    var z=gz$gma_10()
    var oJHC=_ctn("view");_setAttr(z,oJHC,'class',0,e,s,gg);var oKHC=_ctn("view");_setAttr(z,oKHC,'class',1,e,s,gg);var oLHC=_ctn("view");_setAttr(z,oLHC,'class',2,e,s,gg);var oMHC=_o(z,3,e,s,gg);_ac(oLHC,oMHC);_ac(oKHC,oLHC);_ac(oJHC,oKHC);var oNHC=_ctn("view");_setAttr(z,oNHC,'class',4,e,s,gg);var oOHC=_ctn("view");_setAttr(z,oOHC,'class',5,e,s,gg);var oPHC=_cvn();var oQHC=function(oUHC,oTHC,oSHC,gg){var oWHC=_ctn("view");_setAttr(z,oWHC,'class',9,oUHC,oTHC,gg);var oXHC=_setAttrs(z,"view",["id",8,"bindtap",2,"class",3],oUHC,oTHC,gg);var oYHC=_ctn("view");_setAttr(z,oYHC,'class',12,oUHC,oTHC,gg);var oZHC=_o(z,13,oUHC,oTHC,gg);_ac(oYHC,oZHC);_ac(oXHC,oYHC);_ac(oWHC,oXHC);var oaHC=_ctn("view");_setAttr(z,oaHC,'class',14,oUHC,oTHC,gg);var obHC=_ctn("view");_setAttr(z,obHC,'class',15,oUHC,oTHC,gg);var ocHC=_cvn();var odHC=function(ohHC,ogHC,ofHC,gg){var ojHC=_setAttrs(z,"navigator",["class",19,"url",1],ohHC,ogHC,gg);var okHC=_ctn("view");_setAttr(z,okHC,'class',21,ohHC,ogHC,gg);var olHC=_o(z,22,ohHC,ogHC,gg);_ac(okHC,olHC);_ac(ojHC,okHC);var omHC=_ctn("view");_setAttr(z,omHC,'class',23,ohHC,ogHC,gg);_ac(ojHC,omHC);_ac(ofHC,ojHC);return ofHC;};_2(z,16,odHC,oUHC,oTHC,gg,ocHC,"page","index",'*item');_ac(obHC,ocHC);_ac(oaHC,obHC);_ac(oWHC,oaHC);_ac(oSHC,oWHC);return oSHC;};_2(z,6,oQHC,e,s,gg,oPHC,"item","index",'{{item.id}}');_ac(oOHC,oPHC);_ac(oNHC,oOHC);_ac(oJHC,oNHC);_ac(r,oJHC);
    return r;
  };
  e_["./page/tabbar/framework/index.maml"]={f:m9,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

__maAppCode__['app.json']={"pages":["page/tabbar/component/index","page/tabbar/api/index","page/tabbar/framework/index"],"subPackages":[{"root":"page/component/","pages":["page/component/pages/icon/icon","page/component/pages/image/image","page/component/pages/view/view","page/component/pages/cover-view/cover-view","page/component/pages/cover-image/cover-image","page/component/pages/text/text","page/component/pages/button/button","page/component/pages/swiper/swiper","page/component/pages/scroll-view/scroll-view","page/component/pages/input/input","page/component/pages/picker-view/picker-view","page/component/pages/radio/radio","page/component/pages/checkbox/checkbox","page/component/pages/label/label","page/component/pages/switch/switch","page/component/pages/slider/slider","page/component/pages/form/form","page/component/pages/picker/picker","page/component/pages/progress/progress","page/component/pages/navigator/navigator","page/component/pages/navigator/navigate","page/component/pages/navigator/reLaunch","page/component/pages/navigator/redirect","page/component/pages/web-view/web-view","page/component/pages/video/video","page/component/pages/camera/camera","page/component/pages/audio/audio","page/component/pages/rich-text/rich-text","page/component/pages/textarea/textarea"]},{"root":"page/API/","pages":["page/API/pages/application-event/application-event","page/API/pages/navigator/navigator","page/API/pages/get-system-info/get-system-info","page/API/pages/get-system-info-sync/get-system-info-sync","page/API/pages/get-location/get-location","page/API/pages/navigator/navigate","page/API/pages/navigator/redirect","page/API/pages/toast/toast","page/API/pages/modal/modal","page/API/pages/loading/loading","page/API/pages/request/request","page/API/pages/websocket/websocket","page/API/pages/network/network","page/API/pages/gyroscope/gyroscope","page/API/pages/memory-warning/memory-warning","page/API/pages/make-phone-call/make-phone-call","page/API/pages/get-battery-info/get-battery-info","page/API/pages/screen-brightness/screen-brightness","page/API/pages/hideKeyboard/hideKeyboard","page/API/pages/pull-down-refresh/pull-down-refresh","page/API/pages/canIUse/canIUse","page/API/pages/set-navigation-bar-title/set-navigation-bar-title","page/API/pages/set-navigation-bar-color/set-navigation-bar-color","page/API/pages/storage/storage","page/API/pages/storage-sync/storage-sync","page/API/pages/set-background/set-background","page/API/pages/downloadFile/downloadFile","page/API/pages/uploadFile/uploadFile","page/API/pages/mediaImage/mediaImage","page/API/pages/show-action-sheet/show-action-sheet","page/API/pages/file/file","page/API/pages/open-document/open-document","page/API/pages/scanCode/scanCode","page/API/pages/vibrate/vibrate","page/API/pages/chooseContact/chooseContact","page/API/pages/get-network-type/get-network-type","page/API/pages/getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect","page/API/pages/get-image-info/get-image-info","page/API/pages/compressImage/compressImage"]},{"root":"page/framework/","pages":["page/framework/pages/communication/communication","page/framework/pages/sjs-filter/sjs-filter","page/framework/pages/sjs-drag/sjs-drag","page/framework/pages/macle-i18n/macle-i18n","page/framework/pages/macle-sub-i18n/macle-sub-i18n"]}],"window":{"navigationBarTextStyle":"black","navigationBarTitleText":"Example display","navigationBarBackgroundColor":"#F8F8F8","backgroundColor":"#F8F8F8"},"sitemapLocation":"sitemap.json","tabBar":{"color":"#7A7E83","selectedColor":"#3cc51f","borderStyle":"black","backgroundColor":"#ffffff","list":[{"pagePath":"page/tabbar/component/index","iconPath":"image/icon_component.png","selectedIconPath":"image/icon_component_HL.png","text":"componen"},{"pagePath":"page/tabbar/api/index","iconPath":"image/icon_API.png","selectedIconPath":"image/icon_API_HL.png","text":"interface"},{"pagePath":"page/tabbar/framework/index","iconPath":"image/icon_framework.png","selectedIconPath":"image/icon_framework_HL.png","text":"framework"}]},"entryPagePath":"page/tabbar/component/index"};
__maAppCode__['component/communication-detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/communication-detailItem/index"}};
__maAppCode__['component/communication-detail/index.maml']=$gma('./component/communication-detail/index.maml');
__maAppCode__['component/communication-detailItem/index.json']={"component":true};
__maAppCode__['component/communication-detailItem/index.maml']=$gma('./component/communication-detailItem/index.maml');
__maAppCode__['component/detail/index.json']={"component":true,"usingComponents":{"detailItem":"component/detailItem/index"}};
__maAppCode__['component/detail/index.maml']=$gma('./component/detail/index.maml');
__maAppCode__['component/detailItem/index.json']={"component":true};
__maAppCode__['component/detailItem/index.maml']=$gma('./component/detailItem/index.maml');
__maAppCode__['page/tabbar/api/components/set-tab-bar/set-tab-bar.json']={"component":true,"usingComponents":{}};
__maAppCode__['page/tabbar/api/components/set-tab-bar/set-tab-bar.maml']=$gma('./page/tabbar/api/components/set-tab-bar/set-tab-bar.maml');
__maAppCode__['page/tabbar/api/index.json']={"navigationBarTitleText":"Applet interface capability display","usingComponents":{"set-tab-bar":"page/tabbar/api/components/set-tab-bar/set-tab-bar"}};
__maAppCode__['page/tabbar/api/index.maml']=$gma('./page/tabbar/api/index.maml');
__maAppCode__['page/tabbar/component/index.json']={"navigationBarTitleText":"Applet official component display"};
__maAppCode__['page/tabbar/component/index.maml']=$gma('./page/tabbar/component/index.maml');
__maAppCode__['page/tabbar/framework/index.json']={"navigationBarTitleText":"Applet framework capability display"};
__maAppCode__['page/tabbar/framework/index.maml']=$gma('./page/tabbar/framework/index.maml');

define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
initI18n({defaultLocale:"zh-CN"});const t=getI18nInstance();App({onLaunch:function(){t.onLocaleChange((t=>{})),ma.getSystemInfo({success:e=>{t.setLocale(e.language),ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})}});const e=ma.getUpdateManager();e.onCheckForUpdate((function(t){})),e.onUpdateReady((function(){ma.showModal({title:"Update Tips",cancelText:"Cancel",confirmText:"Confirm",content:"The version is ready. Do you want to restart the application？",success:function(t){t.confirm&&e.applyUpdate()}})})),e.onUpdateFailed((function(){}))},globalData:{},onHide:function(){}});
});
define("component/communication-detail/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{detail:{type:Object,value:{},public:!0,observer:"_test"},propTest:{type:String,value:"123456"}},data:{isDispalyItem:!1,count:0,list:[{name:"1"},{name:"2"},{name:"3"}],text:"Click Me to trigger a custom event"},created:function(){},attached:function(){},ready:function(){},moved:function(){},detached:function(){},methods:{trigger:function(){this.setData({list:this.data.list,isDispalyItem:!0});this.triggerEvent("myevent",{},{})},onMyEvent:function(t){t.detail},onChildMethod:function(){if(!this.data.isDispalyItem)return;this.selectComponent(".test_color")[0].testData("Successfully invoked")},testSelectComponent:function(t){}}});
});
define("component/communication-detailItem/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{item:{type:Object,value:{}}},data:{count:0},methods:{trigger:function(){var t=this.properties.item;this.triggerEvent("myevent",t,{bubbles:!1})},testData:function(t){}}});
});
define("component/detail/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
getI18nInstance();Component({properties:{detail:{type:Object,value:{}}},data:{count:0},methods:{addCount:function(){this.setData({count:this.data.count+2})}}});
});
define("component/detailItem/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({properties:{item:{type:Object,value:{}}},data:{count:0},methods:{addCount:function(){this.setData({count:this.data.count+3})}}});
});
define("page/tabbar/api/components/set-tab-bar/set-tab-bar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const e={color:"#7A7E83",selectedColor:"#3cc51f",backgroundColor:"#ffffff",borderStyle:"white"};Component({data:{hasSetTabBarBadge:!1,hasShownTabBarRedDot:!1,hasCustomedStyle:!1,hasCustomedItem:!1,hasHiddenTabBar:!1},detached(){this.hideTabBarRedDot(),this.showTabBar(),this.removeCustomStyle(),this.removeCustomItem()},methods:{showTabBarRedDot(){this.data.hasShownTabBarRedDot?this.hideTabBarRedDot():(this.setData({hasShownTabBarRedDot:!0}),ma.showTabBarRedDot({index:2,success(e){},fail(e){},complete(){}}))},hideTabBarRedDot(){this.setData({hasShownTabBarRedDot:!1}),ma.hideTabBarRedDot({index:2,success(e){},fail(e){},complete(){}})},showTabBar(){this.setData({hasHiddenTabBar:!1}),ma.showTabBar({animation:!0,success(e){},fail(e){},complete(){}})},hideTabBar(){this.data.hasHiddenTabBar?this.showTabBar():(this.setData({hasHiddenTabBar:!0}),ma.hideTabBar({animation:!0,success(e){},fail(e){},complete(){}}))},customStyle(){this.data.hasCustomedStyle?this.removeCustomStyle():(this.setData({hasCustomedStyle:!0}),ma.setTabBarStyle({color:"#FFF",selectedColor:"#f00",backgroundColor:"#000000",borderStyle:"black",success(e){},fail(e){},complete(){}}))},removeCustomStyle(){this.setData({hasCustomedStyle:!1}),ma.setTabBarStyle(e)},customItem(){this.data.hasCustomedItem?this.removeCustomItem():(this.setData({hasCustomedItem:!0}),ma.setTabBarItem({index:2,text:"Testing",iconPath:"/image/icon_component.png",selectedIconPath:"/image/icon_component_HL.png",success(e){},fail(e){},conplete(){}}))},removeCustomItem(){this.setData({hasCustomedItem:!1}),ma.setTabBarItem({index:2,text:"interface",iconPath:"/image/icon_API.png",selectedIconPath:"/image/icon_API_HL.png"})}}});
});
define("page/tabbar/api/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"base",name:"Foundation ",open:!1,pages:[{zh:"Application-level events",url:"application-event/application-event",id:"applicationEvent"},{zh:"Obtaining System Information",url:"get-system-info/get-system-info",id:"getSystemInfo"},{zh:"Obtaining System Information Synchronously",url:"get-system-info-sync/get-system-info-sync",id:"getSystemInfoSync"},{zh:"canIUse",url:"canIUse/canIUse",id:"canIUse"}]},{id:"route",name:"Route",open:!1,pages:[{zh:"Interface Switch",url:"navigator/navigator",id:"navigator"}]},{id:"page",name:"UI",open:!1,pages:[{zh:"pull to refresh",url:"pull-down-refresh/pull-down-refresh",id:"pullDownRefresh"},{zh:"Display modal pop-up window",url:"modal/modal",id:"modal"},{zh:"Display message prompt box",url:"toast/toast",id:"toast"},{zh:"The Loading dialog box is displayed",url:"loading/loading",id:"loading"},{zh:"Setting the interface title",url:"set-navigation-bar-title/set-navigation-bar-title",id:"setNavigationBarTitle"},{zh:"Set the color of the navigation bar",url:"set-navigation-bar-color/set-navigation-bar-color",id:"setNavigationBarColor"},{zh:"Background settings",url:"set-background/set-background",id:"setBackground"},{zh:"Set tabBar",url:"set-tab-bar/set-tab-bar",id:"setTabBar"},{zh:"Show Action Menu",url:"show-action-sheet/show-action-sheet",id:"showActionSheet"},{zh:"Obtains the layout position information of a menu button",url:"getMenuButtonBoundingClientRect/getMenuButtonBoundingClientRect",id:"getMenuButtonBoundingClientRect"}]},{id:"device",name:"device",open:!1,pages:[{zh:"network",url:"network/network",id:"network"},{zh:"gyroscope",url:"gyroscope/gyroscope",id:"gyroscope"},{zh:"scanCode",url:"scanCode/scanCode",id:"scanCode"},{zh:"vibrate",url:"vibrate/vibrate",id:"vibrate"},{zh:"chooseContact",url:"chooseContact/chooseContact",id:"chooseContact"},{zh:"Obtain the network type",url:"get-network-type/get-network-type",id:"getNetworkType"},{zh:"performance",url:"memory-warning/memory-warning",id:"memoryWarning"},{zh:"Calling",url:"make-phone-call/make-phone-call",id:"makePhoneCall"},{zh:"Obtaining the Battery Level of a Mobile Phone",url:"get-battery-info/get-battery-info",id:"getBatteryInfo"},{zh:"screen brightness",url:"screen-brightness/screen-brightness",id:"screenBrightness"},{zh:"Hide Keyboard",url:"hideKeyboard/hideKeyboard",id:"hideKeyboard"}]},{id:"network",name:"network",open:!1,pages:[{zh:"network request",url:"request/request",id:"request"},{zh:"WebSocket",url:"websocket/websocket",id:"websocket"},{zh:"Downloadfiles",url:"downloadFile/downloadFile",id:"downloadFile"},{zh:"uploadFile",url:"uploadFile/uploadFile",id:"uploadFile"}]},{id:"media",name:"media",open:!1,pages:[{zh:"mediaImage",url:"mediaImage/mediaImage",id:"mediaImage"},{zh:"Obtain Image Information",url:"get-image-info/get-image-info",id:"getImageInfo"},{zh:"Compressed Picture",url:"compressImage/compressImage",id:"compressImage"},{zh:"file",url:"file/file",id:"file"},{zh:"Document Open",url:"open-document/open-document",id:"openDocument"}]},{id:"location",name:"location",open:!1,pages:[{zh:"Get Geographic Location",url:"get-location/get-location",id:"getLocation"}]},{id:"cache",name:"cache",pages:[{zh:"local storage",url:"storage/storage",id:"storage"},{zh:"Synchroniz Local Storage",url:"storage-sync/storage-sync",id:"storagesync"}]}],isSetTabBarPage:!1},onShow:function(){this.leaveSetTabBarPage(),ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},onHide(){this.leaveSetTabBarPage()},kindToggle:function(e){for(var t=e.currentTarget.id,a=this.data.list,o=0,n=a.length;o<n;++o)if(a[o].id==t){if(a[o].url)return void ma.navigateTo({url:"pages/"+a[o].url});a[o].open=!a[o].open}else a[o].open=!1;this.setData({list:a})},enterSetTabBarPage(){this.setData({isSetTabBarPage:!0})},leaveSetTabBarPage(){this.setData({isSetTabBarPage:!1})}});
});
define("page/tabbar/component/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"view",name:"Figure Container",open:!1,pages:[{name:"view",id:"viewPage"},{name:"scroll-view",id:"scrollViewPage"},{name:"cover-view",id:"coverViewPage"},{name:"cover-image",id:"coverImagePage"},{name:"swiper",id:"swiperPage"}]},{id:"content",name:"Basic Content",open:!1,pages:[{name:"text",id:"textPage"},{name:"icon",id:"iconPage"},{name:"rich-text",id:"richTextPage"},{name:"progress",id:"progressPage"}]},{id:"form",name:"Form Component",open:!1,pages:[{name:"button",id:"buttonPage"},{name:"checkbox",id:"Page"},{name:"form",id:"formPage"},{name:"input",id:"inputPage"},{name:"label",id:"labelPage"},{name:"picker",id:"pickerPage"},{name:"picker-view",id:"pickerViewPage"},{name:"radio",id:"radioPage"},{name:"slider",id:"sliderPage"},{name:"switch",id:"switchPage"},{name:"textarea",id:"textareaPage"}]},{id:"nav",name:"navigation",open:!1,pages:[{name:"navigator",id:"navigatorPage"}]},{id:"media",name:"Media Components",open:!1,pages:[{name:"image",id:"imagePage"},{name:"audio",id:"audioPage"},{name:"video",id:"videoPage"},{name:"camera",id:"cameraPage"}]},{id:"open-capability",name:"open capability",open:!1,pages:[{name:"web-view",id:"webViewPage"}]}]},onShow:function(){ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},kindToggle:function(e){for(var a=e.currentTarget.id,i=this.data.list,n=0,t=i.length;n<t;++n)i[n].id==a?i[n].open=!i[n].open:i[n].open=!1;this.setData({list:i})}});
});
define("page/tabbar/framework/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{list:[{id:"sjs",name:"sjs",open:!1,pages:["sjs-filter","sjs-drag"]},{id:"custom",name:"Defining Components",open:!1,pages:["communication"]},{id:"language",name:"internationalized language",open:!1,pages:["macle-i18n"]}]},onShow:function(){ma.setTabBarItem({index:0,text:t.t("component")}),ma.setTabBarItem({index:1,text:t.t("api")}),ma.setTabBarItem({index:2,text:t.t("framework")})},kindToggle:function(e){for(var t=e.currentTarget.id,n=this.data.list,a=0,i=n.length;a<i;++a)n[a].id==t?n[a].open=!n[a].open:n[a].open=!1;this.setData({list:n})}});
});
define("page/util/util.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
module.exports={formatTime:function(t){if("number"!=typeof t||t<0)return t;var r=parseInt(t/3600);return t%=3600,[r,parseInt(t/60),t%=60].map((function(t){return(t=t.toString())[1]?t:"0"+t})).join(":")},formatLocation:function(t,r){return"string"==typeof t&&"string"==typeof r&&(t=parseFloat(t),r=parseFloat(r)),t=t.toFixed(2),r=r.toFixed(2),{longitude:t.toString().split("."),latitude:r.toString().split(".")}}};
});
__maRoute='app';require("app.js");
__maRoute='component/communication-detail/index';require("component/communication-detail/index.js");
__maRoute='component/communication-detailItem/index';require("component/communication-detailItem/index.js");
__maRoute='component/detail/index';require("component/detail/index.js");
__maRoute='component/detailItem/index';require("component/detailItem/index.js");
__maRoute='page/tabbar/api/components/set-tab-bar/set-tab-bar';require("page/tabbar/api/components/set-tab-bar/set-tab-bar.js");
__maRoute='page/tabbar/api/index';require("page/tabbar/api/index.js");
__maRoute='page/tabbar/component/index';require("page/tabbar/component/index.js");
__maRoute='page/tabbar/framework/index';require("page/tabbar/framework/index.js");
