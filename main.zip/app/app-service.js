var __maAppData=__maAppData||{};
var __maRoute=__maRoute||"";
var __layer__='service';
var __maAppCode__=__maAppCode__||{};
var global=global||{};
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false}; 
var Component=Component||function(){};


/* maml-transpiler v22.12.0 2022-12-29 11:21:52 */
window.__maml_transpiler_version__='v22.12.0'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[2,"=="], [[7],[3,"item"]], [[7],[3,"Null"]]]);
      Z([3,'loading']);
      Z([3,'Loading checkout...']);
      Z([3,'container']);
      Z([3,'content']);
      Z([3,'product']);
      Z([3,'image']);
      Z([[6],[[7],[3,"item"]],[3,"image"]]);
      Z([3,'info']);
      Z([3,'name']);
      Z([11,[[6],[[7],[3,"item"]],[3,"title"]]]);
      Z([3,'price']);
      Z([11,[[6],[[7],[3,"item"]],[3,"price"]],[3,' ETB']]);
      Z([3,'detail']);
      Z([3,'detail-item']);
      Z([3,'left-text']);
      Z([3,'Quantity']);
      Z([3,'right']);
      Z([3,'onMinus']);
      Z([3,'action']);
      Z([3,'-']);
      Z([3,'qunatity']);
      Z([11,[[6],[[7],[3,"item"]],[3,"quantity"]]]);
      Z([3,'onAdd']);
      Z([3,'+']);
      Z([3,'Unit Price']);
      Z([3,'right-text']);
      Z([3,'Delivery Fee']);
      Z([11,[[6],[[7],[3,"item"]],[3,"deliveryFee"]],[3,' ETB']]);
      Z([3,'Sub Total']);
      Z([11,[[6],[[7],[3,"item"]],[3,"subTotal"]],[3,' ETB']]);
      Z([3,'divider']);
      Z([3,'Grand Total']);
      Z([11,[[6],[[7],[3,"item"]],[3,"grandTotal"]],[3,' ETB']]);
      Z([[2,"=="], [[7],[3,"loading"]], [1,true]]);
      Z([3,'onCheckout']);
      Z([3,'pay']);
      Z([3,'button']);
      Z([3,'Processing...']);
      Z([3,'Pay with telebirr']);
      Z([[2,"!="], [[7],[3,"rawRequest"]], [[7],[3,"Null"]]]);
      Z([3,'raw-request']);
      Z([11,[[7],[3,"rawRequest"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'Map Tester Channel']);
      Z([3,'markerTap']);
      Z([3,'mapTap']);
      Z([[7],[3,"circles"]]);
      Z([3,'myMap']);
      Z([[7],[3,"includePoints"]]);
      Z([[7],[3,"latitude"]]);
      Z([[7],[3,"longitude"]]);
      Z([[7],[3,"markers"]]);
      Z([[7],[3,"polyline"]]);
      Z([[7],[3,"scale"]]);
      Z([[7],[3,"showLocation"]])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  function gz$gma_3(){
    if(__MAML_GLOBAL__.ops_cached.$gma_3)return __MAML_GLOBAL__.ops_cached.$gma_3
    __MAML_GLOBAL__.ops_cached.$gma_3=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[2,"=="], [[7],[3,"product"]], [[7],[3,"Null"]]]);
      Z([3,'loading']);
      Z([3,'Loading product...']);
      Z([3,'container']);
      Z([3,'image']);
      Z([[6],[[7],[3,"product"]],[3,"image"]]);
      Z([3,'content']);
      Z([3,'name']);
      Z([11,[[6],[[7],[3,"product"]],[3,"title"]]]);
      Z([3,'price']);
      Z([11,[[6],[[7],[3,"product"]],[3,"price"]],[3,' ETB']]);
      Z([3,'info']);
      Z([3,'category']);
      Z([11,[[6],[[7],[3,"product"]],[3,"category"]]]);
      Z([3,'rating']);
      Z([11,[[6],[[6],[[7],[3,"product"]],[3,"rating"]],[3,"rate"]],[3,' rating ('],[[6],[[6],[[7],[3,"product"]],[3,"rating"]],[3,"count"]],[3,')']]);
      Z([3,'description']);
      Z([11,[[6],[[7],[3,"product"]],[3,"description"]]]);
      Z([3,'onCheckout']);
      Z([3,'buy']);
      Z([3,'button']);
      Z([3,'Checkout']);
      Z([3,'head']);
      Z([[8],"title",[1,"video"]]);
      Z([3,'page-body']);
      Z([3,'page-section tc']);
      Z([[7],[3,"autoplay"]]);
      Z([3,'bindended']);
      Z([3,'binderror']);
      Z([3,'bindpause']);
      Z([3,'bindplay']);
      Z([3,'bindtimeupdate']);
      Z([[7],[3,"controls"]]);
      Z([[7],[3,"hidden"]]);
      Z([3,'myVideo']);
      Z([[7],[3,"loop"]]);
      Z([[7],[3,"muted"]]);
      Z([[7],[3,"objectFit"]]);
      Z([[7],[3,"poster"]]);
      Z([[7],[3,"src"]]);
      Z([3,'weui-cells']);
      Z([3,'weui-cell weui-cell_input']);
      Z([3,'weui-cell__hd']);
      Z([3,'weui-label']);
      Z([3,'JumpLocation']);
      Z([3,'weui-cell__bd']);
      Z([3,'false']);
      Z([3,'bindInput']);
      Z([3,'weui-input']);
      Z([3,'Enter the specified location here']);
      Z([3,'text']);
      Z([[7],[3,"position"]]);
      Z([3,'btn-area']);
      Z([3,'play']);
      Z([3,'page-body-button play']);
      Z([3,'primary']);
      Z([3,'playout']);
      Z([3,'pause']);
      Z([3,'page-body-button pause']);
      Z([3,'seek']);
      Z([3,'page-body-button seek']);
      Z([3,'Jump to a specified position (unit:second)']);
      Z([3,'foot']);
      Z([3,'--\x3e']);
      Z([11,[3,'https://afroreadapp.com/audio/sample/'],[[7],[3,"bookId"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_3);
    return __MAML_GLOBAL__.ops_cached.$gma_3
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()

  
  d_["./pages/checkout/checkout.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var oaLB=_ctn("scroll-view");var obLB=_cvn();if(_o(z,0,e,s,gg)){obLB.maVkey=1;var ocLB=_ctn("view");_setAttr(z,ocLB,'class',1,e,s,gg);var oeLB=_o(z,2,e,s,gg);_ac(ocLB,oeLB);_ac(obLB,ocLB);}else{obLB.maVkey=2;var ofLB=_ctn("view");_setAttr(z,ofLB,'class',3,e,s,gg);var ohLB=_ctn("view");_setAttr(z,ohLB,'class',4,e,s,gg);var oiLB=_ctn("view");_setAttr(z,oiLB,'class',5,e,s,gg);var ojLB=_setAttrs(z,"image",["class",6,"src",1],e,s,gg);_ac(oiLB,ojLB);var okLB=_ctn("view");_setAttr(z,okLB,'class',8,e,s,gg);var olLB=_ctn("text");_setAttr(z,olLB,'class',9,e,s,gg);var omLB=_o(z,10,e,s,gg);_ac(olLB,omLB);_ac(okLB,olLB);var onLB=_ctn("text");_setAttr(z,onLB,'class',11,e,s,gg);var ooLB=_o(z,12,e,s,gg);_ac(onLB,ooLB);_ac(okLB,onLB);_ac(oiLB,okLB);_ac(ohLB,oiLB);var opLB=_ctn("view");_setAttr(z,opLB,'class',13,e,s,gg);var oqLB=_ctn("view");_setAttr(z,oqLB,'class',14,e,s,gg);var orLB=_ctn("text");_setAttr(z,orLB,'class',15,e,s,gg);var osLB=_o(z,16,e,s,gg);_ac(orLB,osLB);_ac(oqLB,orLB);var otLB=_ctn("view");_setAttr(z,otLB,'class',17,e,s,gg);var ouLB=_setAttrs(z,"view",["bind:tap",18,"class",1],e,s,gg);var ovLB=_o(z,20,e,s,gg);_ac(ouLB,ovLB);_ac(otLB,ouLB);var owLB=_ctn("text");_setAttr(z,owLB,'class',21,e,s,gg);var oxLB=_o(z,22,e,s,gg);_ac(owLB,oxLB);_ac(otLB,owLB);var oyLB=_setAttrs(z,"view",["class",19,"bind:tap",4],e,s,gg);var ozLB=_o(z,24,e,s,gg);_ac(oyLB,ozLB);_ac(otLB,oyLB);_ac(oqLB,otLB);_ac(opLB,oqLB);var o_LB=_ctn("view");_setAttr(z,o_LB,'class',14,e,s,gg);var oAMB=_ctn("text");_setAttr(z,oAMB,'class',15,e,s,gg);var oBMB=_o(z,25,e,s,gg);_ac(oAMB,oBMB);_ac(o_LB,oAMB);var oCMB=_ctn("text");_setAttr(z,oCMB,'class',26,e,s,gg);var oDMB=_o(z,12,e,s,gg);_ac(oCMB,oDMB);_ac(o_LB,oCMB);_ac(opLB,o_LB);var oEMB=_ctn("view");_setAttr(z,oEMB,'class',14,e,s,gg);var oFMB=_ctn("text");_setAttr(z,oFMB,'class',15,e,s,gg);var oGMB=_o(z,27,e,s,gg);_ac(oFMB,oGMB);_ac(oEMB,oFMB);var oHMB=_ctn("text");_setAttr(z,oHMB,'class',26,e,s,gg);var oIMB=_o(z,28,e,s,gg);_ac(oHMB,oIMB);_ac(oEMB,oHMB);_ac(opLB,oEMB);var oJMB=_ctn("view");_setAttr(z,oJMB,'class',14,e,s,gg);var oKMB=_ctn("text");_setAttr(z,oKMB,'class',15,e,s,gg);var oLMB=_o(z,29,e,s,gg);_ac(oKMB,oLMB);_ac(oJMB,oKMB);var oMMB=_ctn("text");_setAttr(z,oMMB,'class',26,e,s,gg);var oNMB=_o(z,30,e,s,gg);_ac(oMMB,oNMB);_ac(oJMB,oMMB);_ac(opLB,oJMB);var oOMB=_ctn("view");_setAttr(z,oOMB,'class',31,e,s,gg);_ac(opLB,oOMB);var oPMB=_ctn("view");_setAttr(z,oPMB,'class',14,e,s,gg);var oQMB=_ctn("text");_setAttr(z,oQMB,'class',15,e,s,gg);var oRMB=_o(z,32,e,s,gg);_ac(oQMB,oRMB);_ac(oPMB,oQMB);var oSMB=_ctn("text");_setAttr(z,oSMB,'class',26,e,s,gg);var oTMB=_o(z,33,e,s,gg);_ac(oSMB,oTMB);_ac(oPMB,oSMB);_ac(opLB,oPMB);_ac(ohLB,opLB);_ac(ofLB,ohLB);var oUMB=_cvn();if(_o(z,34,e,s,gg)){oUMB.maVkey=1;var oVMB=_setAttrs(z,"button",["bind:tap",35,"class",1,"type",2],e,s,gg);var oXMB=_o(z,38,e,s,gg);_ac(oVMB,oXMB);_ac(oUMB,oVMB);}else{oUMB.maVkey=2;var oYMB=_setAttrs(z,"button",["bind:tap",35,"class",1,"type",2],e,s,gg);var oaMB=_o(z,39,e,s,gg);_ac(oYMB,oaMB);_ac(oUMB,oYMB);}_ac(ofLB,oUMB);var obMB=_cvn();if(_o(z,40,e,s,gg)){obMB.maVkey=1;var ocMB=_ctn("view");_setAttr(z,ocMB,'class',41,e,s,gg);var oeMB=_o(z,42,e,s,gg);_ac(ocMB,oeMB);_ac(obMB,ocMB);} _ac(ofLB,obMB);_ac(obLB,ofLB);}_ac(oaLB,obLB);_ac(r,oaLB);
    return r;
  };
  e_["./pages/checkout/checkout.maml"]={f:m0,j:[],i:[],ti:[],ic:[]};

  d_["./pages/index/index.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var ogMB=_ctn("scroll-view");var ohMB=_ctn("view");var oiMB=_o(z,0,e,s,gg);_ac(ohMB,oiMB);_ac(ogMB,ohMB);var ojMB=_setAttrs(z,"map",["bindmarkertap",1,"bindtap",1,"circles",2,"id",3,"includePoints",4,"latitude",5,"longitude",6,"markers",7,"polyline",8,"scale",9,"showLocation",10],e,s,gg);_ac(ogMB,ojMB);_ac(r,ogMB);
    return r;
  };
  e_["./pages/index/index.maml"]={f:m1,j:[],i:[],ti:[],ic:[]};

  d_["./pages/product-detail/product-detail.maml"]={};
  var m2=function(e,s,r,gg){
    var z=gz$gma_3()
    var okMB=e_["./pages/product-detail/product-detail.maml"].i;var olMB=_ctn("scroll-view");var omMB=_cvn();if(_o(z,0,e,s,gg)){omMB.maVkey=1;var onMB=_ctn("view");_setAttr(z,onMB,'class',1,e,s,gg);var opMB=_o(z,2,e,s,gg);_ac(onMB,opMB);_ac(omMB,onMB);}else{omMB.maVkey=2;var oqMB=_ctn("view");_setAttr(z,oqMB,'class',3,e,s,gg);var osMB=_setAttrs(z,"image",["class",4,"src",1],e,s,gg);_ac(oqMB,osMB);var otMB=_ctn("view");_setAttr(z,otMB,'class',6,e,s,gg);var ouMB=_ctn("text");_setAttr(z,ouMB,'class',7,e,s,gg);var ovMB=_o(z,8,e,s,gg);_ac(ouMB,ovMB);_ac(otMB,ouMB);var owMB=_ctn("text");_setAttr(z,owMB,'class',9,e,s,gg);var oxMB=_o(z,10,e,s,gg);_ac(owMB,oxMB);_ac(otMB,owMB);var oyMB=_ctn("view");_setAttr(z,oyMB,'class',11,e,s,gg);var ozMB=_ctn("view");_setAttr(z,ozMB,'class',12,e,s,gg);var o_MB=_o(z,13,e,s,gg);_ac(ozMB,o_MB);_ac(oyMB,ozMB);var oANB=_ctn("view");_setAttr(z,oANB,'class',14,e,s,gg);var oBNB=_o(z,15,e,s,gg);_ac(oANB,oBNB);_ac(oyMB,oANB);_ac(otMB,oyMB);var oCNB=_ctn("text");_setAttr(z,oCNB,'class',16,e,s,gg);var oDNB=_o(z,17,e,s,gg);_ac(oCNB,oDNB);_ac(otMB,oCNB);var oENB=_setAttrs(z,"button",["bind:tap",18,"class",1,"type",2],e,s,gg);var oFNB=_o(z,21,e,s,gg);_ac(oENB,oFNB);_ac(otMB,oENB);_ac(oqMB,otMB);_ac(omMB,oqMB);}_ac(olMB,omMB);_ac(r,olMB);_ai(okMB,'../../../common/head.maml',e_,'./pages/product-detail/product-detail.maml',0,0);_ai(okMB,'../../../common/foot.maml',e_,'./pages/product-detail/product-detail.maml',0,0);var oINB=_ctn("view");_setAttr(z,oINB,'class',3,e,s,gg);var oJNB=_cvn();
    var oKNB=_o(z,22,e,s,gg);
    var oLNB=_gd('./pages/product-detail/product-detail.maml',oKNB,e_,d_);
    if(oLNB){
      var oMNB=_1(z,23,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oLNB(oMNB,oMNB,oJNB,gg);
      gg.f=tgf;
    }else{
      _w(oKNB,'./pages/product-detail/product-detail.maml',0,0);
    }
    _ac(oINB,oJNB);var oNNB=_ctn("view");_setAttr(z,oNNB,'class',24,e,s,gg);var oONB=_ctn("view");_setAttr(z,oONB,'class',25,e,s,gg);var oPNB=_setAttrs(z,"video",["autoplay",26,"bindended",1,"binderror",2,"bindpause",3,"bindplay",4,"bindtimeupdate",5,"controls",6,"hidden",7,"id",8,"loop",9,"muted",10,"objectFit",11,"poster",12,"src",13],e,s,gg);_ac(oONB,oPNB);var oQNB=_ctn("view");_setAttr(z,oQNB,'class',40,e,s,gg);var oRNB=_ctn("view");_setAttr(z,oRNB,'class',41,e,s,gg);var oSNB=_ctn("view");_setAttr(z,oSNB,'class',42,e,s,gg);var oTNB=_ctn("view");_setAttr(z,oTNB,'class',43,e,s,gg);var oUNB=_o(z,44,e,s,gg);_ac(oTNB,oUNB);_ac(oSNB,oTNB);_ac(oRNB,oSNB);var oVNB=_ctn("view");_setAttr(z,oVNB,'class',45,e,s,gg);var oWNB=_setAttrs(z,"input",["adjustPosition",46,"bindinput",1,"class",2,"placeholder",3,"type",4,"value",5],e,s,gg);_ac(oVNB,oWNB);_ac(oRNB,oVNB);_ac(oQNB,oRNB);_ac(oONB,oQNB);var oXNB=_ctn("view");_setAttr(z,oXNB,'class',52,e,s,gg);var oYNB=_setAttrs(z,"button",["bindtap",53,"class",1,"type",2],e,s,gg);var oZNB=_o(z,56,e,s,gg);_ac(oYNB,oZNB);_ac(oXNB,oYNB);var oaNB=_setAttrs(z,"button",["type",55,"bindtap",2,"class",3],e,s,gg);var obNB=_o(z,57,e,s,gg);_ac(oaNB,obNB);_ac(oXNB,oaNB);var ocNB=_setAttrs(z,"button",["type",55,"bindtap",4,"class",5],e,s,gg);var odNB=_o(z,61,e,s,gg);_ac(ocNB,odNB);_ac(oXNB,ocNB);_ac(oONB,oXNB);_ac(oNNB,oONB);_ac(oINB,oNNB);var oeNB=_cvn();
    var ofNB=_o(z,62,e,s,gg);
    var ogNB=_gd('./pages/product-detail/product-detail.maml',ofNB,e_,d_);
    if(ogNB){
      var ohNB={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      ogNB(ohNB,ohNB,oeNB,gg);
      gg.f=tgf;
    }else{
      _w(ofNB,'./pages/product-detail/product-detail.maml',0,0);
    }
    _ac(oINB,oeNB);_ac(r,oINB);var oiNB=_o(z,63,e,s,gg);_ac(r,oiNB);var ojNB=_ctn("web-view");_setAttr(z,ojNB,'src',64,e,s,gg);_ac(r,ojNB);okMB.pop();okMB.pop();
    return r;
  };
  e_["./pages/product-detail/product-detail.maml"]={f:m2,j:[],i:[],ti:["../../../common/head.maml","../../../common/foot.maml"],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

__maAppCode__['app.json']={"pages":["pages/index/index","pages/product-detail/product-detail","pages/checkout/checkout"],"window":{"backgroundTextStyle":"light","navigationBarBackgroundColor":"#fff","navigationBarTitleText":"Macle","navigationBarTextStyle":"black","capsuleTheme":"light"},"style":"v2","sitemapLocation":"sitemap.json","entryPagePath":"pages/index/index"};
__maAppCode__['pages/checkout/checkout.json']={"navigationBarTitleText":"","usingComponents":{}};
__maAppCode__['pages/checkout/checkout.maml']=$gma('./pages/checkout/checkout.maml');
__maAppCode__['pages/index/index.json']={"usingComponents":{}};
__maAppCode__['pages/index/index.maml']=$gma('./pages/index/index.maml');
__maAppCode__['pages/product-detail/product-detail.json']={"navigationBarTitleText":"","usingComponents":{}};
__maAppCode__['pages/product-detail/product-detail.maml']=$gma('./pages/product-detail/product-detail.maml');

define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
App({onLaunch(){},onShow(){}});
});
define("pages/checkout/checkout.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{baseUrl:"https://aba-bluprint.onrender.com/api",item:null,loading:!1,rawRequest:null},onLoad(t){this.fetchData(t.id)},onReady(){},onShow(){},onHide(){},onUnload(){},onShareAppMessage:()=>({title:""}),fetchData(t){ma.request({url:`${this.data.baseUrl}/products/${t}`,method:"GET",timeout:6e4,success:({data:t})=>{const a=t.data.product;this.setData({...this.data,item:{...a,price:parseFloat(a.price),quantity:1,deliveryFee:20,subTotal:parseFloat(a.price),grandTotal:parseFloat(a.price)+20}})}})},onCheckout(){this.setData({...this.data,loading:!0}),ma.request({urll:`${this.data.baseUrl}/orders`,method:"POST",timeout:1e5,data:{product:this.data.item.id,quantity:this.data.item.quantity,amount:this.data.item.grandTotal},success:({data:t})=>{},fail:t=>{ma.showModal({content:`${JSON.stringify(t)}`})}})},startPay(t){const a=t.trim();ma.showToast({title:t}),this.setData({...this.data,rawRequest:a}),ma.startPay({rawRequest:a,success:t=>{ma.showToast({title:"Res = "+t.resultCode})},fail:t=>{}})},onAdd(){const t=this.data.item.quantity+1,a=t*this.data.item.price,e=a+this.data.item.deliveryFee;this.setData({...this.data,item:{...this.data.item,quantity:t,subTotal:a,grandTotal:e}})},onMinus(){if(this.data.item.quantity>1){const t=this.data.item.quantity-1,a=t*this.data.item.price,e=a+this.data.item.deliveryFee;this.setData({...this.data,item:{...this.data.item,quantity:t,subTotal:a,grandTotal:e}})}}});
});
define("pages/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{markers:[],latitude:31.97934,longitude:118.7673113,circles:[{latitude:31.9782417,longitude:118.7661415,radius:20,color:"#87CEEB"}],includePoints:[{latitude:31.9751427,longitude:118.7672672},{latitude:31.9782417,longitude:118.7661415},{latitude:31.97934,longitude:118.7673113}],polyline:[],showLocation:!1,scale:18},markerTap(a){ma.showModal({content:`markerTap${a}`})},mapTap(a){ma.showModal({content:`mapTap${a}`})}});
});
define("pages/product-detail/product-detail.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{baseUrl:"https://telebirr-api.technolabet.com/api",product:null},onLoad(a){this.fetchData(a.id)},onReady(){ma.gotoFunction({path:"https://afroreadapp.com/sample/a39df819-b59a-46e0-afd6-bef217840c63"})},onShow(){ma.gotoFunction({path:"https://afroreadapp.com/sample/a39df819-b59a-46e0-afd6-bef217840c63"})},onHide(){},onUnload(){},onShareAppMessage:()=>({title:""}),fetchData(a){ma.request({url:`${this.data.baseUrl}/products/${a}`,method:"GET",timeout:6e4,success:({data:a})=>{this.setData({...this.data,product:a.data.product})}})},openeWebView(){ma.gotoFunction({path:"https://www.google.com"})},onCheckout(a){ma.navigateTo({url:`../checkout/checkout?id=${this.data.product.id}`})}});
});
__maRoute='app';require("app.js");
__maRoute='pages/checkout/checkout';require("pages/checkout/checkout.js");
__maRoute='pages/index/index';require("pages/index/index.js");
__maRoute='pages/product-detail/product-detail';require("pages/product-detail/product-detail.js");
