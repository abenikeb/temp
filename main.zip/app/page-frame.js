var __mainPageFrameReady__=window.__mainPageFrameReady__||function(){};
var __pageFrameStartTime__=__pageFrameStartTime__||Date.now(); 
var __webviewId__=__webviewId__;
var __layer__='view';
var __maAppCode__=__maAppCode__||{}; 
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false};



/* maml-transpiler v23.3.0 2023-03-29 16:31:41 */
window.__maml_transpiler_version__='v23.3.0'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'background-color: #F1EBEB;padding-top: 10px;padding-bottom: 100px;font-family: \x27Lucida Sans\x27, \x27Lucida Sans Regular\x27, \x27Lucida Grande\x27, \x27Lucida Sans Unicode\x27, Geneva, Verdana, sans-serif;']);
      Z([3,'card']);
      Z([3,'\r\n      display: flex;\r\n      margin: 20px;\r\n      padding: 15px;\r\n      background-color: rgb(237, 237, 237);\r\n      border: 1px gray solid;\r\n      border-radius: 5px;\r\n    ']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        justify-content: start;\r\n        align-items: start;\r\n        margin: 0px 20px;\r\n        line-height: 30px;\r\n      ']);
      Z([3,'color: black; font-size: 16px; font-weight: 600']);
      Z([3,'Discount']);
      Z([3,'Total']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        justify-content: start;\r\n        align-items: start;\r\n        line-height: 30px;\r\n      ']);
      Z([3,'- 150']);
      Z([3,'color: gray; padding-left: 5px']);
      Z([3,'ETB']);
      Z([3,'color: black; font-size: medium; font-weight: 600']);
      Z([3,'10000']);
      Z([3,'\r\n      display: flex;\r\n      justify-content: start;\r\n      align-items: start;\r\n      margin: 20px;\r\n      border: 1px solid gray;\r\n      padding: 10px;\r\n      background-color: white;\r\n      border-radius: 5px;\r\n    ']);
      Z([3,'../images/honey-in-jar.svg']);
      Z([3,'width: 80px; height: 80px; margin: 0px 10px']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        align-items: start;\r\n        justify-content: start;\r\n        font-weight: 600;\r\n        margin: 5px 10px;\r\n      ']);
      Z([3,'color: #e67e22']);
      Z([3,'Honey']);
      Z([3,'5000']);
      Z([3,'ETB/Kg']);
      Z([3,'\r\n          font-weight: 600;\r\n          font-size: large;\r\n          color: #e67e22;\r\n          border: 1px solid #e7971c;\r\n          padding: 2px 7px;\r\n          width: 100px;\r\n          border-radius: 10px;\r\n          display: flex;\r\n          justify-content: space-between;\r\n          margin-top: 5px;\r\n        ']);
      Z([3,'onAdd']);
      Z([3,'+']);
      Z([11,[[7],[3,"quantity"]]]);
      Z([3,'onMinus']);
      Z([3,'-']);
      Z([3,'../images/delete.svg']);
      Z([3,'width: 30px; height: 30px; padding: 1px 5px; margin-left: 5.5rem']);
      Z([3,'\r\n      margin: 20px;\r\n      padding: 15px;\r\n      background-color: white;\r\n      border: 1px gray solid;\r\n      border-radius: 5px;\r\n    ']);
      Z([3,'display: flex; justify-content: space-around']);
      Z([3,'\r\n          display: flex;\r\n          flex-direction: column;\r\n          justify-content: start;\r\n          align-items: start;\r\n          margin: 0px 20px;\r\n          line-height: 30px;\r\n        ']);
      Z([3,'color: black; font-size: 14px; font-weight: 600']);
      Z([3,'Item']);
      Z([3,'Tax']);
      Z([3,'Shipping']);
      Z([3,'----------']);
      Z([3,'\r\n          display: flex;\r\n          flex-direction: column;\r\n          justify-content: start;\r\n          align-items: start;\r\n          line-height: 30px;\r\n        ']);
      Z([3,'Birr 36000']);
      Z([3,'Birr 200(15%)']);
      Z([3,'- Birr 100']);
      Z([3,'Free']);
      Z([3,'display: flex;justify-content: center;margin: 10px;']);
      Z([3,'checkout']);
      Z([3,'background-color: #e67e22;padding: 5px 20px;color: white;font-size: 16px;border-radius: 20px;']);
      Z([3,'Checkout'])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'background-color: #F1EBEB;padding-top: 10px;padding-bottom: 100px;font-family: \x27Lucida Sans\x27, \x27Lucida Sans Regular\x27, \x27Lucida Grande\x27, \x27Lucida Sans Unicode\x27, Geneva, Verdana, sans-serif;']);
      Z([3,'width: 80%; padding:10px 20px;margin: 20px;margin-bottom: 15px; background-color: white']);
      Z([3,'display: flex;justify-content: center;align-items: center;margin: 10px;']);
      Z([3,'color: #e7971c; font-size: large; text-align: center; font-weight: 600;']);
      Z([3,'Summary']);
      Z([3,'display: flex;justify-content: space-between;font-weight: 600;font-size: small;']);
      Z([3,'\r\n          display: flex;\r\n          justify-content: start;\r\n          align-items: start;\r\n          flex-direction: column;\r\n        ']);
      Z([3,'padding: 10px;']);
      Z([3,'Discount']);
      Z([3,'Total']);
      Z([3,'-10 ETB']);
      Z([3,'1000 ETB']);
      Z([3,'#']);
      Z([3,'post']);
      Z([3,'padding: 10px;margin: 10px;']);
      Z([3,'font-weight: 600;']);
      Z([3,'First Name']);
      Z([3,'background-color: white;padding: 5px; margin-top: 10px;']);
      Z([3,'text']);
      Z([3,'Last Name']);
      Z([3,'Phone Number']);
      Z([3,'Region']);
      Z([3,'City']);
      Z([3,'Address']);
      Z([3,'checkout']);
      Z([3,'background-color: #e7971c;color: white;margin: 20px;']);
      Z([3,'submit']);
      Z([3,'Continue'])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  function gz$gma_3(){
    if(__MAML_GLOBAL__.ops_cached.$gma_3)return __MAML_GLOBAL__.ops_cached.$gma_3
    __MAML_GLOBAL__.ops_cached.$gma_3=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'background-color: #F1EBEB;padding-bottom: 100px;font-family: \x27Lucida Sans\x27, \x27Lucida Sans Regular\x27, \x27Lucida Grande\x27, \x27Lucida Sans Unicode\x27, Geneva, Verdana, sans-serif;']);
      Z([3,'height: 150px; background-color: #e7971c;display: flex;justify-content: center;align-items: center;']);
      Z([3,'../images/honey-in-jar.svg']);
      Z([3,'width: 180px;height: 180px;']);
      Z([3,'\r\n      background-color: #f1ebeb;\r\n      padding: 25px;\r\n      display: flex;\r\n      flex-direction: column;\r\n      justify-content: space-evenly;\r\n      align-items: start;\r\n      border-top-right-radius: 25px;\r\n      border-top-left-radius: 25px;\r\n    ']);
      Z([3,'color: #e7971c; font-size: x-large']);
      Z([3,'Honey A']);
      Z([3,'font-weight: 600; margin-top: 40px']);
      Z([3,'2000 ETB /']);
      Z([3,'color: gray']);
      Z([3,'KG']);
      Z([3,'display: flex; justify-content: space-between; padding: 40px 0px; padding-bottom: 10px;']);
      Z([3,'display: flex; flex-direction: column']);
      Z([3,'font-weight: 600; font-size: medium; margin-bottom: 10px']);
      Z([3,'Production Date']);
      Z([3,'2022-08-07']);
      Z([3,'display: flex; flex-direction: column; margin-left: 40px']);
      Z([3,'Exp Date']);
      Z([3,'display: flex; justify-content: space-between; padding: 10px 0px']);
      Z([3,'Origin']);
      Z([3,'JInka']);
      Z([3,'Category']);
      Z([3,'natural']);
      Z([3,'display: flex;flex-direction: column;']);
      Z([3,'font-weight: 600;font-size: medium;']);
      Z([3,'Description']);
      Z([3,'font-weight: 400;font-size: small;color: gray;line-height: 20px;margin-top: 5px;']);
      Z([3,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis ipsum rem labore quia in distinctio dolorum dignissimos corrupti dolor inventore laboriosam ex placeat, soluta, tempore enim repellat asperiores odit laborum.']);
      Z([3,'display: flex;justify-content: space-between;align-items: center;margin-top: 10px;']);
      Z([3,'font-weight: 600;font-size: small;margin-right: 140px;']);
      Z([3,'Qty(']);
      Z([3,'color: gray;']);
      Z([3,')']);
      Z([3,'font-weight: 600;font-size: large;color: white;background-color: #e7971c;padding: 5px 10px;width: 70px; border-radius: 5px;display: flex;justify-content: space-between;']);
      Z([3,'onAdd']);
      Z([3,'+']);
      Z([11,[[7],[3,"quantity"]]]);
      Z([3,'onMinus']);
      Z([3,'-']);
      Z([3,'orders']);
      Z([3,'width:100px; margin:10px; color:white; background-color: #e7971c;']);
      Z([3,'Buy']);
      Z([3,'width: 100%;height: 70px;display: flex;justify-content: space-around;align-items: center; background-color: #E7971C;color: white;position: fixed;bottom: 0;']);
      Z([3,'Home']);
      Z([3,'padding: 10px;display: flex;flex-direction: column;justify-content: center;align-items: center;']);
      Z([3,'../images/home.svg']);
      Z([3,'height: 30px; width: 30px']);
      Z([3,'Cart']);
      Z([3,'../images/cart.svg']);
      Z([3,'Order']);
      Z([3,'../images/order.svg']);
      Z([3,'Account']);
      Z([3,'../images/account.svg'])
    })(__MAML_GLOBAL__.ops_cached.$gma_3);
    return __MAML_GLOBAL__.ops_cached.$gma_3
  }
  function gz$gma_4(){
    if(__MAML_GLOBAL__.ops_cached.$gma_4)return __MAML_GLOBAL__.ops_cached.$gma_4
    __MAML_GLOBAL__.ops_cached.$gma_4=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'background-color: #F1EBEB;padding-top: 10px;padding-bottom: 100px;font-family: \x27Lucida Sans\x27, \x27Lucida Sans Regular\x27, \x27Lucida Grande\x27, \x27Lucida Sans Unicode\x27, Geneva, Verdana, sans-serif;']);
      Z([3,'display: flex;justify-content: center;background-color: white;margin: 20px;border-radius: 5px;border: 1px rgb(240, 240, 240) solid;']);
      Z([3,'display: flex;flex-direction: column;padding: 20px;']);
      Z([3,'color: #e7971c;font-size: large;margin-bottom: 10px;font-weight:900']);
      Z([3,'Explore Our\r\n                Honey Treasures']);
      Z([3,'explore']);
      Z([3,'color: white;background-color: #e7971c;padding:5px 10px;text-align: center;border-radius: 5px;font-weight:900']);
      Z([3,'Explore']);
      Z([3,'../images/account.svg']);
      Z([3,'\r\n        height: 100px;\r\n        width: 200px;\r\n        padding: 5px;\r\n        border-radius: 5px;\r\n      ']);
      Z([3,'display: flex;justify-content: space-between;margin: 15px 30px;']);
      Z([3,'display: flex;align-items: center;']);
      Z([3,'Search']);
      Z([3,'\r\n        border: #ffeaca 2px solid; background-color: white;padding: 5px 15px;height: 30px;width: 100%;']);
      Z([3,'text']);
      Z([3,'../images/search.svg']);
      Z([3,'\r\n        height: 30px;\r\n        width: 55px;\r\n        border: #ffeaca 2px solid;\r\n        padding: 5px;\r\n        border-radius: 5px;\r\n        background-color: #E7971C;\r\n      ']);
      Z([3,'margin: 20px;']);
      Z([3,'font-weight: 600;font-size: large;']);
      Z([3,'Category']);
      Z([3,'display: flex;justify-content: start;']);
      Z([3,'margin: 10px;display: flex;flex-direction: column;justify-content: center;align-items: center;']);
      Z([3,'width: 70px;height: 70px;background-color: white;border-radius: 50px;']);
      Z([3,'../images/honey-product.svg']);
      Z([3,'height: 60px; width: 80px']);
      Z([3,'font-size: small;text-align: center;']);
      Z([3,'category a']);
      Z([3,'display: flex;justify-content: space-between;align-items: center;']);
      Z([3,'Most Popular']);
      Z([3,'font-weight: 600;font-size: medium;color: #E7971C;']);
      Z([3,'See all']);
      Z([3,'detail']);
      Z([3,'background-color: white;display: flex;flex-direction: column;width: 40%;padding:10px;padding-top: 2px; border-radius: 10px;margin-top: 15px;  border: #ffebcd 1px solid;margin-right: 15px;']);
      Z([3,'\r\n            height: 90px;\r\n            width: 200px;\r\n            border-radius: 5px;\r\n          ']);
      Z([3,'color: #E7971C;margin: 2px 0px;']);
      Z([3,'Honey A']);
      Z([3,'font-weight: 600;margin: 2px 0px;']);
      Z([3,'2000 ETB /']);
      Z([3,'color: gray;']);
      Z([3,'KG']);
      Z([3,'display: flex;align-items: center;justify-content: start;']);
      Z([3,'font-weight: 600;font-size: large;margin-right: 2px;']);
      Z([3,'4.8']);
      Z([3,'../images/star.svg']);
      Z([3,'\r\n            height: 25px;\r\n            width: 25px;\r\n            padding: 5px;\r\n            border-radius: 5px;\r\n            margin-right: 1px;\r\n          ']);
      Z([3,'../images/cart.svg']);
      Z([3,'\r\n            height: 30px;\r\n            width: 30px;\r\n            border: 1px rgb(214, 214, 214) solid;\r\n            padding: 5px 20px;\r\n            border-radius: 5px;\r\n            background-color: #E7971C;\r\n          ']);
      Z([3,'width: 100%;height: 70px;display: flex;justify-content: space-around;align-items: center; background-color: #E7971C;color: white;position: fixed;bottom: 0;']);
      Z([3,'Home']);
      Z([3,'padding: 10px;display: flex;flex-direction: column;justify-content: center;align-items: center;']);
      Z([3,'../images/home.svg']);
      Z([3,'height: 30px; width: 30px']);
      Z([3,'Cart']);
      Z([3,'Order']);
      Z([3,'../images/order.svg']);
      Z([3,'Account'])
    })(__MAML_GLOBAL__.ops_cached.$gma_4);
    return __MAML_GLOBAL__.ops_cached.$gma_4
  }
  function gz$gma_5(){
    if(__MAML_GLOBAL__.ops_cached.$gma_5)return __MAML_GLOBAL__.ops_cached.$gma_5
    __MAML_GLOBAL__.ops_cached.$gma_5=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'background-color: #F1EBEB;padding-top: 10px;padding-bottom: 100px;font-family: \x27Lucida Sans\x27, \x27Lucida Sans Regular\x27, \x27Lucida Grande\x27, \x27Lucida Sans Unicode\x27, Geneva, Verdana, sans-serif;']);
      Z([3,'card']);
      Z([3,'\r\n      display: flex;\r\n      margin: 20px;\r\n      padding: 15px;\r\n      background-color: white;\r\n      border: 1px gray solid;\r\n      border-radius: 5px;\r\n    ']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        justify-content: start;\r\n        align-items: start;\r\n        margin: 0px 20px;\r\n        line-height: 30px;\r\n      ']);
      Z([3,'color: #e67e22; font-size: 16px; font-weight: 600']);
      Z([3,'Order ID:']);
      Z([3,'Total:']);
      Z([3,'Ordered Date:']);
      Z([3,'Delivery date:']);
      Z([3,'Location:']);
      Z([3,'Remark:']);
      Z([3,'Status:']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        justify-content: start;\r\n        align-items: start;\r\n        line-height: 30px;\r\n      ']);
      Z([3,'12345678']);
      Z([3,'color: black; font-size: medium; font-weight: 600']);
      Z([3,'10000']);
      Z([3,'color: gray; padding-left: 5px']);
      Z([3,'ETB']);
      Z([3,'color: gray; font-size: small; font-weight: 400']);
      Z([3,'Jun 16,2023 2:00 Am']);
      Z([3,'Adiss Ababa,mexico']);
      Z([3,'New Remark']);
      Z([3,'color: red; font-size: small; font-weight: 400']);
      Z([3,'Pending']);
      Z([3,'font-weight: 600; font-size: 24px; margin: 20px']);
      Z([3,'Products']);
      Z([3,'\r\n        display: flex;\r\n        background-color: white;\r\n        padding: 10px;\r\n        border: 1px rgb(218, 218, 218) solid;\r\n        border-radius: 10px;\r\n        justify-content: start;\r\n        margin-top: 10px;\r\n      ']);
      Z([3,'../images/honey-in-jar.svg']);
      Z([3,'height: 80px; width: 90px; margin: 10px; margin-right: 20px']);
      Z([3,'\r\n          display: flex;\r\n          flex-direction: column;\r\n          font-size: medium;\r\n          justify-content: space-evenly;\r\n          align-items: start;\r\n        ']);
      Z([3,'color: #e67e22']);
      Z([3,'Honey A']);
      Z([3,'Qty: 3']);
      Z([3,'color: gray; margin-left: 5px']);
      Z([3,'Kg']);
      Z([3,'margin-left: 80px']);
      Z([3,'5000 ETB /']);
      Z([3,'display: flex;flex-direction: column;justify-content: center;align-items: center;margin: 20px;']);
      Z([3,'display: flex;font-weight: 600;margin:10px 20px;justify-content: center;align-items: center;']);
      Z([3,'../images/info.svg']);
      Z([3,'width: 30px; height: 30px; padding-right: 5px;']);
      Z([3,'padding: 5px 0;']);
      Z([3,'Click Accept to confirm delivery']);
      Z([3,'Accept']);
      Z([3,'background-color: #0E8521;color: white;padding: 5px 10px;border-radius: 10px;width: 100px;text-align: center;']);
      Z([3,'width: 100%;height: 70px;display: flex;justify-content: space-around;align-items: center; background-color: #E7971C;color: white;position: fixed;bottom: 0;']);
      Z([3,'Home']);
      Z([3,'padding: 10px;display: flex;flex-direction: column;justify-content: center;align-items: center;']);
      Z([3,'../images/home.svg']);
      Z([3,'height: 30px; width: 30px']);
      Z([3,'Cart']);
      Z([3,'../images/cart.svg']);
      Z([3,'Order']);
      Z([3,'../images/order.svg']);
      Z([3,'Account']);
      Z([3,'../images/account.svg'])
    })(__MAML_GLOBAL__.ops_cached.$gma_5);
    return __MAML_GLOBAL__.ops_cached.$gma_5
  }
  function gz$gma_6(){
    if(__MAML_GLOBAL__.ops_cached.$gma_6)return __MAML_GLOBAL__.ops_cached.$gma_6
    __MAML_GLOBAL__.ops_cached.$gma_6=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'padding-top: 10px;padding-bottom: 100px;font-family: \x27Lucida Sans\x27, \x27Lucida Sans Regular\x27, \x27Lucida Grande\x27, \x27Lucida Sans Unicode\x27, Geneva, Verdana, sans-serif;']);
      Z([3,'orderDetail']);
      Z([3,'card']);
      Z([3,'\r\n      display: flex;\r\n      margin: 20px;\r\n      padding: 15px;\r\n      background-color: white;\r\n      border: 1px gray solid;\r\n      border-radius: 5px;\r\n    ']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        justify-content: start;\r\n        align-items: start;\r\n        margin: 0px 20px;\r\n        line-height: 30px;\r\n      ']);
      Z([3,'color: #e67e22; font-size: 16px; font-weight: 600']);
      Z([3,'Order ID:']);
      Z([3,'Ordered Date:']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        justify-content: start;\r\n        align-items: start;\r\n        line-height: 30px;\r\n      ']);
      Z([3,'12345678']);
      Z([3,'color: gray; font-size: small; font-weight: 400']);
      Z([3,'Jun 16,2023 2:00 AM']);
      Z([3,'width: 100%;height: 70px;display: flex;justify-content: space-around;align-items: center; background-color: #E7971C;color: white;position: fixed;bottom: 0;']);
      Z([3,'Home']);
      Z([3,'padding: 10px;display: flex;flex-direction: column;justify-content: center;align-items: center;']);
      Z([3,'../images/home.svg']);
      Z([3,'height: 30px; width: 30px']);
      Z([3,'Cart']);
      Z([3,'../images/cart.svg']);
      Z([3,'Order']);
      Z([3,'../images/order.svg']);
      Z([3,'Account']);
      Z([3,'../images/account.svg'])
    })(__MAML_GLOBAL__.ops_cached.$gma_6);
    return __MAML_GLOBAL__.ops_cached.$gma_6
  }
  function gz$gma_7(){
    if(__MAML_GLOBAL__.ops_cached.$gma_7)return __MAML_GLOBAL__.ops_cached.$gma_7
    __MAML_GLOBAL__.ops_cached.$gma_7=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'display: flex;justify-content: space-between;margin: 20px 30px;']);
      Z([3,'../images/filter.svg']);
      Z([3,'\r\n        height: 30px;\r\n        width: 60px;\r\n        padding: 5px;\r\n        border-radius: 5px;\r\n        border: #ffeaca 2px solid;\r\n        background-color: white;\r\n        margin-right: 5px;\r\n      ']);
      Z([3,'display: flex;align-items: center;']);
      Z([3,'Search']);
      Z([3,'\r\n        border: #ffeaca 2px solid; background-color: white;padding: 5px 15px;height: 30px;width: 100%;']);
      Z([3,'text']);
      Z([3,'../images/search.svg']);
      Z([3,'\r\n        height: 30px;\r\n        width: 55px;\r\n        border: #ffeaca 2px solid;\r\n        padding: 5px;\r\n        border-radius: 5px;\r\n        background-color: #E7971C;\r\n      ']);
      Z([3,'font-weight: 600;font-size: large;margin: 20px 10px;']);
      Z([3,'All Products']);
      Z([3,'display: flex;']);
      Z([3,'background-color: white;display: flex;flex-direction: column;width: 40%;padding:10px;border-radius: 10px;margin: 5px;border: #ffebcd 1px solid;']);
      Z([3,'details']);
      Z([3,'../images/honey-in-jar.svg']);
      Z([3,'\r\n            height: 100px;\r\n            width: 200px;\r\n            border-radius: 5px;\r\n          ']);
      Z([3,'color: #E7971C;margin: 2px 0px;']);
      Z([3,'Honey A']);
      Z([3,'font-weight: 600;margin: 2px 0px;']);
      Z([3,'2000 ETB /']);
      Z([3,'color: gray;']);
      Z([3,'KG']);
      Z([3,'display: flex;align-items: center;justify-content: start;']);
      Z([3,'font-weight: 600;font-size: large;margin-right: 2px;']);
      Z([3,'4.8']);
      Z([3,'../images/star.svg']);
      Z([3,'\r\n            height: 25px;\r\n            width: 25px;\r\n            padding: 5px;\r\n            border-radius: 5px;\r\n            margin-right: 1px;\r\n          ']);
      Z([3,'../images/cart.svg']);
      Z([3,'\r\n            height: 30px;\r\n            width: 30px;\r\n            border: 1px rgb(214, 214, 214) solid;\r\n            padding: 5px 20px;\r\n            border-radius: 5px;\r\n            background-color: #E7971C;\r\n          ']);
      Z([3,'width: 100%;height: 70px;display: flex;justify-content: space-around;align-items: center; background-color: #E7971C;color: white;position: fixed;bottom: 0;']);
      Z([3,'Home']);
      Z([3,'padding: 10px;display: flex;flex-direction: column;justify-content: center;align-items: center;']);
      Z([3,'../images/home.svg']);
      Z([3,'height: 30px; width: 30px']);
      Z([3,'Cart']);
      Z([3,'Order']);
      Z([3,'../images/order.svg']);
      Z([3,'Account']);
      Z([3,'../images/account.svg'])
    })(__MAML_GLOBAL__.ops_cached.$gma_7);
    return __MAML_GLOBAL__.ops_cached.$gma_7
  }
  function gz$gma_8(){
    if(__MAML_GLOBAL__.ops_cached.$gma_8)return __MAML_GLOBAL__.ops_cached.$gma_8
    __MAML_GLOBAL__.ops_cached.$gma_8=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'\r\n      display: flex;\r\n      flex-direction: column;\r\n      justify-content: center;\r\n      align-items: center;\r\n    ']);
      Z([3,'../images/big-checker.svg']);
      Z([3,'width: 150px;height: 150px;margin: 25px;']);
      Z([3,'color: #e67e22;font-size: large;font-weight: 600;width: 300px;text-align: center;']);
      Z([3,'Thank you for confirming the receipt of your order']);
      Z([3,'card']);
      Z([3,'\r\n      display: flex;\r\n      margin: 20px;\r\n      padding: 15px;\r\n      background-color: white;\r\n      border: 1px gray solid;\r\n    ']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        justify-content: start;\r\n        align-items: start;\r\n        margin: 0px 20px;\r\n        line-height: 30px;\r\n      ']);
      Z([3,'color: #e67e22; font-size: 16px; font-weight: 600']);
      Z([3,'Order ID:']);
      Z([3,'Total:']);
      Z([3,'Ordered Date:']);
      Z([3,'Delivery date:']);
      Z([3,'Location:']);
      Z([3,'Remark:']);
      Z([3,'\r\n        display: flex;\r\n        flex-direction: column;\r\n        justify-content: start;\r\n        align-items: start;\r\n        line-height: 30px;\r\n      ']);
      Z([3,'12345678']);
      Z([3,'color: black; font-size: medium; font-weight: 600']);
      Z([3,'10000']);
      Z([3,'color: gray; padding-left: 5px']);
      Z([3,'ETB']);
      Z([3,'color: gray; font-size: small; font-weight: 400']);
      Z([3,'Jun 16,2023 2:00 Am']);
      Z([3,'Adiss Ababa,mexico']);
      Z([3,'New Remark'])
    })(__MAML_GLOBAL__.ops_cached.$gma_8);
    return __MAML_GLOBAL__.ops_cached.$gma_8
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()

  
  d_["./pages/cart/cart.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var oC=_ctn("view");_setAttr(z,oC,'style',0,e,s,gg);var oD=_setAttrs(z,"view",["id",1,"style",1],e,s,gg);var oE=_ctn("view");_setAttr(z,oE,'style',3,e,s,gg);var oF=_ctn("p");_setAttr(z,oF,'style',4,e,s,gg);var oG=_o(z,5,e,s,gg);_ac(oF,oG);_ac(oE,oF);var oH=_ctn("p");_setAttr(z,oH,'style',4,e,s,gg);var oI=_o(z,6,e,s,gg);_ac(oH,oI);_ac(oE,oH);_ac(oD,oE);var oJ=_ctn("view");_setAttr(z,oJ,'style',7,e,s,gg);var oK=_ctn("p");_setAttr(z,oK,'style',4,e,s,gg);var oL=_o(z,8,e,s,gg);_ac(oK,oL);var oM=_ctn("span");_setAttr(z,oM,'style',9,e,s,gg);var oN=_o(z,10,e,s,gg);_ac(oM,oN);_ac(oK,oM);_ac(oJ,oK);var oO=_ctn("p");_setAttr(z,oO,'style',11,e,s,gg);var oP=_o(z,12,e,s,gg);_ac(oO,oP);var oQ=_ctn("span");_setAttr(z,oQ,'style',9,e,s,gg);var oR=_o(z,10,e,s,gg);_ac(oQ,oR);_ac(oO,oQ);_ac(oJ,oO);_ac(oD,oJ);_ac(oC,oD);var oS=_ctn("view");_setAttr(z,oS,'style',13,e,s,gg);var oT=_setAttrs(z,"image",["src",14,"style",1],e,s,gg);_ac(oS,oT);var oU=_ctn("div");_setAttr(z,oU,'style',16,e,s,gg);var oV=_ctn("p");_setAttr(z,oV,'style',17,e,s,gg);var oW=_o(z,18,e,s,gg);_ac(oV,oW);_ac(oU,oV);var oX=_ctn("p");var oY=_o(z,19,e,s,gg);_ac(oX,oY);var oZ=_ctn("span");_setAttr(z,oZ,'style',9,e,s,gg);var oa=_o(z,20,e,s,gg);_ac(oZ,oa);_ac(oX,oZ);_ac(oU,oX);var ob=_ctn("p");_ac(oU,ob);var oc=_ctn("view");_setAttr(z,oc,'style',21,e,s,gg);var od=_ctn("p");_setAttr(z,od,'bind:tap',22,e,s,gg);var oe=_o(z,23,e,s,gg);_ac(od,oe);_ac(oc,od);var of=_ctn("p");var og=_o(z,24,e,s,gg);_ac(of,og);_ac(oc,of);var oh=_ctn("p");_setAttr(z,oh,'bind:tap',25,e,s,gg);var oi=_o(z,26,e,s,gg);_ac(oh,oi);_ac(oc,oh);_ac(oU,oc);_ac(oS,oU);var oj=_setAttrs(z,"image",["src",27,"style",1],e,s,gg);_ac(oS,oj);_ac(oC,oS);var ok=_ctn("view");_setAttr(z,ok,'style',13,e,s,gg);var ol=_setAttrs(z,"image",["src",14,"style",1],e,s,gg);_ac(ok,ol);var om=_ctn("div");_setAttr(z,om,'style',16,e,s,gg);var on=_ctn("p");_setAttr(z,on,'style',17,e,s,gg);var oo=_o(z,18,e,s,gg);_ac(on,oo);_ac(om,on);var op=_ctn("p");var oq=_o(z,19,e,s,gg);_ac(op,oq);var or=_ctn("span");_setAttr(z,or,'style',9,e,s,gg);var os=_o(z,20,e,s,gg);_ac(or,os);_ac(op,or);_ac(om,op);var ot=_ctn("p");_ac(om,ot);var ou=_ctn("view");_setAttr(z,ou,'style',21,e,s,gg);var ov=_ctn("p");_setAttr(z,ov,'bind:tap',22,e,s,gg);var ow=_o(z,23,e,s,gg);_ac(ov,ow);_ac(ou,ov);var ox=_ctn("p");var oy=_o(z,24,e,s,gg);_ac(ox,oy);_ac(ou,ox);var oz=_ctn("p");_setAttr(z,oz,'bind:tap',25,e,s,gg);var o_=_o(z,26,e,s,gg);_ac(oz,o_);_ac(ou,oz);_ac(om,ou);_ac(ok,om);var oAB=_setAttrs(z,"image",["src",27,"style",1],e,s,gg);_ac(ok,oAB);_ac(oC,ok);var oBB=_ctn("view");_setAttr(z,oBB,'style',29,e,s,gg);var oCB=_setAttrs(z,"view",["id",1,"style",29],e,s,gg);var oDB=_ctn("view");_setAttr(z,oDB,'style',31,e,s,gg);var oEB=_ctn("p");_setAttr(z,oEB,'style',32,e,s,gg);var oFB=_o(z,33,e,s,gg);_ac(oEB,oFB);_ac(oDB,oEB);var oGB=_ctn("p");_setAttr(z,oGB,'style',32,e,s,gg);var oHB=_o(z,34,e,s,gg);_ac(oGB,oHB);_ac(oDB,oGB);var oIB=_ctn("p");_setAttr(z,oIB,'style',32,e,s,gg);var oJB=_o(z,5,e,s,gg);_ac(oIB,oJB);_ac(oDB,oIB);var oKB=_ctn("p");_setAttr(z,oKB,'style',32,e,s,gg);var oLB=_o(z,35,e,s,gg);_ac(oKB,oLB);_ac(oDB,oKB);var oMB=_ctn("p");_setAttr(z,oMB,'style',32,e,s,gg);var oNB=_o(z,36,e,s,gg);_ac(oMB,oNB);_ac(oDB,oMB);var oOB=_ctn("p");_setAttr(z,oOB,'style',32,e,s,gg);var oPB=_o(z,6,e,s,gg);_ac(oOB,oPB);_ac(oDB,oOB);_ac(oCB,oDB);var oQB=_ctn("view");_setAttr(z,oQB,'style',37,e,s,gg);var oRB=_ctn("p");_setAttr(z,oRB,'style',32,e,s,gg);var oSB=_o(z,38,e,s,gg);_ac(oRB,oSB);_ac(oQB,oRB);var oTB=_ctn("p");_setAttr(z,oTB,'style',32,e,s,gg);var oUB=_o(z,39,e,s,gg);_ac(oTB,oUB);_ac(oQB,oTB);var oVB=_ctn("p");_setAttr(z,oVB,'style',32,e,s,gg);var oWB=_o(z,40,e,s,gg);_ac(oVB,oWB);_ac(oQB,oVB);var oXB=_ctn("p");_setAttr(z,oXB,'style',32,e,s,gg);var oYB=_o(z,41,e,s,gg);_ac(oXB,oYB);_ac(oQB,oXB);var oZB=_ctn("p");_setAttr(z,oZB,'style',32,e,s,gg);var oaB=_o(z,36,e,s,gg);_ac(oZB,oaB);_ac(oQB,oZB);var obB=_ctn("p");_setAttr(z,obB,'style',32,e,s,gg);var ocB=_o(z,38,e,s,gg);_ac(obB,ocB);_ac(oQB,obB);_ac(oCB,oQB);_ac(oBB,oCB);var odB=_ctn("view");_setAttr(z,odB,'style',42,e,s,gg);var oeB=_setAttrs(z,"p",["bind:tap",43,"style",1],e,s,gg);var ofB=_o(z,45,e,s,gg);_ac(oeB,ofB);_ac(odB,oeB);_ac(oBB,odB);_ac(oC,oBB);_ac(r,oC);
    return r;
  };
  e_["./pages/cart/cart.maml"]={f:m0,j:[],i:[],ti:[],ic:[]};

  d_["./pages/checkout/checkout.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var ohB=_ctn("view");_setAttr(z,ohB,'style',0,e,s,gg);var oiB=_ctn("view");_setAttr(z,oiB,'style',1,e,s,gg);var ojB=_ctn("view");_setAttr(z,ojB,'style',2,e,s,gg);var okB=_ctn("p");_setAttr(z,okB,'style',3,e,s,gg);var olB=_o(z,4,e,s,gg);_ac(okB,olB);_ac(ojB,okB);_ac(oiB,ojB);var omB=_ctn("view");_setAttr(z,omB,'style',5,e,s,gg);var onB=_ctn("view");_setAttr(z,onB,'style',6,e,s,gg);var ooB=_ctn("p");_setAttr(z,ooB,'style',7,e,s,gg);var opB=_o(z,8,e,s,gg);_ac(ooB,opB);_ac(onB,ooB);var oqB=_ctn("p");_setAttr(z,oqB,'style',7,e,s,gg);var orB=_o(z,9,e,s,gg);_ac(oqB,orB);_ac(onB,oqB);_ac(omB,onB);var osB=_ctn("view");_setAttr(z,osB,'style',6,e,s,gg);var otB=_ctn("p");_setAttr(z,otB,'style',7,e,s,gg);var ouB=_o(z,10,e,s,gg);_ac(otB,ouB);_ac(osB,otB);var ovB=_ctn("p");_setAttr(z,ovB,'style',7,e,s,gg);var owB=_o(z,11,e,s,gg);_ac(ovB,owB);_ac(osB,ovB);_ac(omB,osB);_ac(oiB,omB);_ac(ohB,oiB);var oxB=_setAttrs(z,"form",["action",12,"method",1],e,s,gg);var oyB=_ctn("view");_setAttr(z,oyB,'style',14,e,s,gg);var ozB=_ctn("p");_setAttr(z,ozB,'style',15,e,s,gg);var o_B=_o(z,16,e,s,gg);_ac(ozB,o_B);_ac(oyB,ozB);var oAC=_setAttrs(z,"input",["placeholder",16,"style",1,"type",2],e,s,gg);_ac(oyB,oAC);_ac(oxB,oyB);var oBC=_ctn("view");_setAttr(z,oBC,'style',14,e,s,gg);var oCC=_ctn("p");_setAttr(z,oCC,'style',15,e,s,gg);var oDC=_o(z,19,e,s,gg);_ac(oCC,oDC);_ac(oBC,oCC);var oEC=_setAttrs(z,"input",["style",17,"type",1,"placeholder",2],e,s,gg);_ac(oBC,oEC);_ac(oxB,oBC);var oFC=_ctn("view");_setAttr(z,oFC,'style',14,e,s,gg);var oGC=_ctn("p");_setAttr(z,oGC,'style',15,e,s,gg);var oHC=_o(z,20,e,s,gg);_ac(oGC,oHC);_ac(oFC,oGC);var oIC=_setAttrs(z,"input",["style",17,"type",1,"placeholder",3],e,s,gg);_ac(oFC,oIC);_ac(oxB,oFC);var oJC=_ctn("view");_setAttr(z,oJC,'style',14,e,s,gg);var oKC=_ctn("p");_setAttr(z,oKC,'style',15,e,s,gg);var oLC=_o(z,21,e,s,gg);_ac(oKC,oLC);_ac(oJC,oKC);var oMC=_setAttrs(z,"input",["style",17,"type",1,"placeholder",4],e,s,gg);_ac(oJC,oMC);_ac(oxB,oJC);var oNC=_ctn("view");_setAttr(z,oNC,'style',14,e,s,gg);var oOC=_ctn("p");_setAttr(z,oOC,'style',15,e,s,gg);var oPC=_o(z,22,e,s,gg);_ac(oOC,oPC);_ac(oNC,oOC);var oQC=_setAttrs(z,"input",["style",17,"type",1,"placeholder",5],e,s,gg);_ac(oNC,oQC);_ac(oxB,oNC);var oRC=_ctn("view");_setAttr(z,oRC,'style',14,e,s,gg);var oSC=_ctn("p");_setAttr(z,oSC,'style',15,e,s,gg);var oTC=_o(z,23,e,s,gg);_ac(oSC,oTC);_ac(oRC,oSC);var oUC=_setAttrs(z,"input",["style",17,"type",1,"placeholder",6],e,s,gg);_ac(oRC,oUC);_ac(oxB,oRC);var oVC=_setAttrs(z,"button",["bind:tap",24,"style",1,"type",2],e,s,gg);var oWC=_o(z,27,e,s,gg);_ac(oVC,oWC);_ac(oxB,oVC);_ac(ohB,oxB);_ac(r,ohB);
    return r;
  };
  e_["./pages/checkout/checkout.maml"]={f:m1,j:[],i:[],ti:[],ic:[]};

  d_["./pages/detail/detail.maml"]={};
  var m2=function(e,s,r,gg){
    var z=gz$gma_3()
    var oYC=_ctn("view");_setAttr(z,oYC,'style',0,e,s,gg);var oZC=_ctn("view");_setAttr(z,oZC,'style',1,e,s,gg);var oaC=_setAttrs(z,"image",["src",2,"style",1],e,s,gg);_ac(oZC,oaC);_ac(oYC,oZC);var obC=_ctn("view");_setAttr(z,obC,'style',4,e,s,gg);var ocC=_ctn("p");_setAttr(z,ocC,'style',5,e,s,gg);var odC=_o(z,6,e,s,gg);_ac(ocC,odC);_ac(obC,ocC);var oeC=_ctn("p");_setAttr(z,oeC,'style',7,e,s,gg);var ofC=_o(z,8,e,s,gg);_ac(oeC,ofC);var ogC=_ctn("span");_setAttr(z,ogC,'style',9,e,s,gg);var ohC=_o(z,10,e,s,gg);_ac(ogC,ohC);_ac(oeC,ogC);_ac(obC,oeC);var oiC=_ctn("view");_setAttr(z,oiC,'style',11,e,s,gg);var ojC=_ctn("view");_setAttr(z,ojC,'style',12,e,s,gg);var okC=_ctn("p");_setAttr(z,okC,'style',13,e,s,gg);var olC=_o(z,14,e,s,gg);_ac(okC,olC);_ac(ojC,okC);var omC=_ctn("p");_setAttr(z,omC,'style',9,e,s,gg);var onC=_o(z,15,e,s,gg);_ac(omC,onC);_ac(ojC,omC);_ac(oiC,ojC);var ooC=_ctn("view");_setAttr(z,ooC,'style',16,e,s,gg);var opC=_ctn("p");_setAttr(z,opC,'style',13,e,s,gg);var oqC=_o(z,17,e,s,gg);_ac(opC,oqC);_ac(ooC,opC);var orC=_ctn("p");_setAttr(z,orC,'style',9,e,s,gg);var osC=_o(z,15,e,s,gg);_ac(orC,osC);_ac(ooC,orC);_ac(oiC,ooC);_ac(obC,oiC);var otC=_ctn("view");_setAttr(z,otC,'style',18,e,s,gg);var ouC=_ctn("view");_setAttr(z,ouC,'style',12,e,s,gg);var ovC=_ctn("p");_setAttr(z,ovC,'style',13,e,s,gg);var owC=_o(z,19,e,s,gg);_ac(ovC,owC);_ac(ouC,ovC);var oxC=_ctn("p");_setAttr(z,oxC,'style',9,e,s,gg);var oyC=_o(z,20,e,s,gg);_ac(oxC,oyC);_ac(ouC,oxC);_ac(otC,ouC);var ozC=_ctn("view");_setAttr(z,ozC,'style',16,e,s,gg);var o_C=_ctn("p");_setAttr(z,o_C,'style',13,e,s,gg);var oAD=_o(z,21,e,s,gg);_ac(o_C,oAD);_ac(ozC,o_C);var oBD=_ctn("p");_setAttr(z,oBD,'style',9,e,s,gg);var oCD=_o(z,22,e,s,gg);_ac(oBD,oCD);_ac(ozC,oBD);_ac(otC,ozC);_ac(obC,otC);var oDD=_ctn("view");_setAttr(z,oDD,'style',23,e,s,gg);var oED=_ctn("p");_setAttr(z,oED,'style',24,e,s,gg);var oFD=_o(z,25,e,s,gg);_ac(oED,oFD);_ac(oDD,oED);var oGD=_ctn("p");_setAttr(z,oGD,'style',26,e,s,gg);var oHD=_o(z,27,e,s,gg);_ac(oGD,oHD);_ac(oDD,oGD);_ac(obC,oDD);var oID=_ctn("view");_setAttr(z,oID,'style',28,e,s,gg);var oJD=_ctn("p");_setAttr(z,oJD,'style',29,e,s,gg);var oKD=_o(z,30,e,s,gg);_ac(oJD,oKD);var oLD=_ctn("span");_setAttr(z,oLD,'style',31,e,s,gg);var oMD=_o(z,10,e,s,gg);_ac(oLD,oMD);_ac(oJD,oLD);var oND=_o(z,32,e,s,gg);_ac(oJD,oND);_ac(oID,oJD);var oOD=_ctn("view");_setAttr(z,oOD,'style',33,e,s,gg);var oPD=_ctn("p");_setAttr(z,oPD,'bind:tap',34,e,s,gg);var oQD=_o(z,35,e,s,gg);_ac(oPD,oQD);_ac(oOD,oPD);var oRD=_ctn("p");var oSD=_o(z,36,e,s,gg);_ac(oRD,oSD);_ac(oOD,oRD);var oTD=_ctn("p");_setAttr(z,oTD,'bind:tap',37,e,s,gg);var oUD=_o(z,38,e,s,gg);_ac(oTD,oUD);_ac(oOD,oTD);_ac(oID,oOD);_ac(obC,oID);var oVD=_setAttrs(z,"button",["bind:tap",39,"style",1],e,s,gg);var oWD=_o(z,41,e,s,gg);_ac(oVD,oWD);_ac(obC,oVD);_ac(oYC,obC);var oXD=_ctn("view");_setAttr(z,oXD,'style',42,e,s,gg);var oYD=_setAttrs(z,"div",["bind:tap",43,"style",1],e,s,gg);var oZD=_setAttrs(z,"image",["src",45,"style",1],e,s,gg);_ac(oYD,oZD);var oaD=_o(z,43,e,s,gg);_ac(oYD,oaD);_ac(oXD,oYD);var obD=_setAttrs(z,"div",["style",44,"bind:tap",3],e,s,gg);var ocD=_setAttrs(z,"image",["style",46,"src",2],e,s,gg);_ac(obD,ocD);var odD=_o(z,47,e,s,gg);_ac(obD,odD);_ac(oXD,obD);var oeD=_setAttrs(z,"div",["style",44,"bind:tap",5],e,s,gg);var ofD=_setAttrs(z,"image",["style",46,"src",4],e,s,gg);_ac(oeD,ofD);var ogD=_o(z,49,e,s,gg);_ac(oeD,ogD);_ac(oXD,oeD);var ohD=_setAttrs(z,"div",["style",44,"bind:tap",7],e,s,gg);var oiD=_setAttrs(z,"image",["style",46,"src",6],e,s,gg);_ac(ohD,oiD);var ojD=_o(z,51,e,s,gg);_ac(ohD,ojD);_ac(oXD,ohD);_ac(oYC,oXD);_ac(r,oYC);
    return r;
  };
  e_["./pages/detail/detail.maml"]={f:m2,j:[],i:[],ti:[],ic:[]};

  d_["./pages/Home/Home.maml"]={};
  var m3=function(e,s,r,gg){
    var z=gz$gma_4()
    var olD=_ctn("view");_setAttr(z,olD,'style',0,e,s,gg);var omD=_ctn("view");_setAttr(z,omD,'style',1,e,s,gg);var onD=_ctn("view");_setAttr(z,onD,'style',2,e,s,gg);var ooD=_ctn("p");_setAttr(z,ooD,'style',3,e,s,gg);var opD=_o(z,4,e,s,gg);_ac(ooD,opD);_ac(onD,ooD);var oqD=_setAttrs(z,"p",["bind:tap",5,"style",1],e,s,gg);var orD=_o(z,7,e,s,gg);_ac(oqD,orD);_ac(onD,oqD);_ac(omD,onD);var osD=_setAttrs(z,"image",["src",8,"style",1],e,s,gg);_ac(omD,osD);_ac(olD,omD);var otD=_ctn("view");_setAttr(z,otD,'style',10,e,s,gg);var ouD=_ctn("view");_setAttr(z,ouD,'style',11,e,s,gg);var ovD=_setAttrs(z,"input",["placeholder",12,"style",1,"type",2],e,s,gg);_ac(ouD,ovD);var owD=_setAttrs(z,"image",["bind:tap",5,"src",10,"style",11],e,s,gg);_ac(ouD,owD);_ac(otD,ouD);_ac(olD,otD);var oxD=_ctn("view");_setAttr(z,oxD,'style',17,e,s,gg);var oyD=_ctn("p");_setAttr(z,oyD,'style',18,e,s,gg);var ozD=_o(z,19,e,s,gg);_ac(oyD,ozD);_ac(oxD,oyD);var o_D=_ctn("view");_setAttr(z,o_D,'style',20,e,s,gg);var oAE=_ctn("view");_setAttr(z,oAE,'style',21,e,s,gg);var oBE=_ctn("view");_setAttr(z,oBE,'style',22,e,s,gg);var oCE=_setAttrs(z,"image",["src",23,"style",1],e,s,gg);_ac(oBE,oCE);_ac(oAE,oBE);var oDE=_ctn("p");_setAttr(z,oDE,'style',25,e,s,gg);var oEE=_o(z,26,e,s,gg);_ac(oDE,oEE);_ac(oAE,oDE);_ac(o_D,oAE);var oFE=_ctn("view");_setAttr(z,oFE,'style',21,e,s,gg);var oGE=_ctn("view");_setAttr(z,oGE,'style',22,e,s,gg);var oHE=_setAttrs(z,"image",["src",23,"style",1],e,s,gg);_ac(oGE,oHE);_ac(oFE,oGE);var oIE=_ctn("p");_setAttr(z,oIE,'style',25,e,s,gg);var oJE=_o(z,26,e,s,gg);_ac(oIE,oJE);_ac(oFE,oIE);_ac(o_D,oFE);_ac(oxD,o_D);_ac(olD,oxD);var oKE=_ctn("view");_setAttr(z,oKE,'style',17,e,s,gg);var oLE=_ctn("view");_setAttr(z,oLE,'style',27,e,s,gg);var oME=_ctn("p");_setAttr(z,oME,'style',18,e,s,gg);var oNE=_o(z,28,e,s,gg);_ac(oME,oNE);_ac(oLE,oME);var oOE=_setAttrs(z,"p",["bind:tap",5,"style",24],e,s,gg);var oPE=_o(z,30,e,s,gg);_ac(oOE,oPE);_ac(oLE,oOE);_ac(oKE,oLE);var oQE=_ctn("view");_setAttr(z,oQE,'style',20,e,s,gg);var oRE=_setAttrs(z,"view",["bind:tap",31,"style",1],e,s,gg);var oSE=_setAttrs(z,"image",["src",23,"style",10],e,s,gg);_ac(oRE,oSE);var oTE=_ctn("p");_setAttr(z,oTE,'style',34,e,s,gg);var oUE=_o(z,35,e,s,gg);_ac(oTE,oUE);_ac(oRE,oTE);var oVE=_ctn("p");_setAttr(z,oVE,'style',36,e,s,gg);var oWE=_o(z,37,e,s,gg);_ac(oVE,oWE);var oXE=_ctn("span");_setAttr(z,oXE,'style',38,e,s,gg);var oYE=_o(z,39,e,s,gg);_ac(oXE,oYE);_ac(oVE,oXE);_ac(oRE,oVE);var oZE=_ctn("view");_setAttr(z,oZE,'style',40,e,s,gg);var oaE=_ctn("p");_setAttr(z,oaE,'style',41,e,s,gg);var obE=_o(z,42,e,s,gg);_ac(oaE,obE);_ac(oZE,oaE);var ocE=_setAttrs(z,"image",["src",43,"style",1],e,s,gg);_ac(oZE,ocE);var odE=_setAttrs(z,"image",["src",45,"style",1],e,s,gg);_ac(oZE,odE);_ac(oRE,oZE);_ac(oQE,oRE);var oeE=_setAttrs(z,"view",["bind:tap",31,"style",1],e,s,gg);var ofE=_setAttrs(z,"image",["src",23,"style",10],e,s,gg);_ac(oeE,ofE);var ogE=_ctn("p");_setAttr(z,ogE,'style',34,e,s,gg);var ohE=_o(z,35,e,s,gg);_ac(ogE,ohE);_ac(oeE,ogE);var oiE=_ctn("p");_setAttr(z,oiE,'style',36,e,s,gg);var ojE=_o(z,37,e,s,gg);_ac(oiE,ojE);var okE=_ctn("span");_setAttr(z,okE,'style',38,e,s,gg);var olE=_o(z,39,e,s,gg);_ac(okE,olE);_ac(oiE,okE);_ac(oeE,oiE);var omE=_ctn("view");_setAttr(z,omE,'style',40,e,s,gg);var onE=_ctn("p");_setAttr(z,onE,'style',41,e,s,gg);var ooE=_o(z,42,e,s,gg);_ac(onE,ooE);_ac(omE,onE);var opE=_setAttrs(z,"image",["src",43,"style",1],e,s,gg);_ac(omE,opE);var oqE=_setAttrs(z,"image",["src",45,"style",1],e,s,gg);_ac(omE,oqE);_ac(oeE,omE);_ac(oQE,oeE);_ac(oKE,oQE);_ac(olD,oKE);var orE=_ctn("view");_setAttr(z,orE,'style',47,e,s,gg);var osE=_setAttrs(z,"div",["bind:tap",48,"style",1],e,s,gg);var otE=_setAttrs(z,"image",["src",50,"style",1],e,s,gg);_ac(osE,otE);var ouE=_o(z,48,e,s,gg);_ac(osE,ouE);_ac(orE,osE);var ovE=_setAttrs(z,"div",["style",49,"bind:tap",3],e,s,gg);var owE=_setAttrs(z,"image",["src",45,"style",6],e,s,gg);_ac(ovE,owE);var oxE=_o(z,52,e,s,gg);_ac(ovE,oxE);_ac(orE,ovE);var oyE=_setAttrs(z,"div",["style",49,"bind:tap",4],e,s,gg);var ozE=_setAttrs(z,"image",["style",51,"src",3],e,s,gg);_ac(oyE,ozE);var o_E=_o(z,53,e,s,gg);_ac(oyE,o_E);_ac(orE,oyE);var oAF=_setAttrs(z,"div",["style",49,"bind:tap",6],e,s,gg);var oBF=_setAttrs(z,"image",["src",8,"style",43],e,s,gg);_ac(oAF,oBF);var oCF=_o(z,55,e,s,gg);_ac(oAF,oCF);_ac(orE,oAF);_ac(olD,orE);_ac(r,olD);
    return r;
  };
  e_["./pages/Home/Home.maml"]={f:m3,j:[],i:[],ti:[],ic:[]};

  d_["./pages/orderDetail/orderDetail.maml"]={};
  var m4=function(e,s,r,gg){
    var z=gz$gma_5()
    var oEF=_ctn("view");_setAttr(z,oEF,'style',0,e,s,gg);var oFF=_setAttrs(z,"view",["id",1,"style",1],e,s,gg);var oGF=_ctn("view");_setAttr(z,oGF,'style',3,e,s,gg);var oHF=_ctn("p");_setAttr(z,oHF,'style',4,e,s,gg);var oIF=_o(z,5,e,s,gg);_ac(oHF,oIF);_ac(oGF,oHF);var oJF=_ctn("p");_setAttr(z,oJF,'style',4,e,s,gg);var oKF=_o(z,6,e,s,gg);_ac(oJF,oKF);_ac(oGF,oJF);var oLF=_ctn("p");_setAttr(z,oLF,'style',4,e,s,gg);var oMF=_o(z,7,e,s,gg);_ac(oLF,oMF);_ac(oGF,oLF);var oNF=_ctn("p");_setAttr(z,oNF,'style',4,e,s,gg);var oOF=_o(z,8,e,s,gg);_ac(oNF,oOF);_ac(oGF,oNF);var oPF=_ctn("p");_setAttr(z,oPF,'style',4,e,s,gg);var oQF=_o(z,9,e,s,gg);_ac(oPF,oQF);_ac(oGF,oPF);var oRF=_ctn("p");_setAttr(z,oRF,'style',4,e,s,gg);var oSF=_o(z,10,e,s,gg);_ac(oRF,oSF);_ac(oGF,oRF);var oTF=_ctn("p");_setAttr(z,oTF,'style',4,e,s,gg);var oUF=_o(z,11,e,s,gg);_ac(oTF,oUF);_ac(oGF,oTF);_ac(oFF,oGF);var oVF=_ctn("view");_setAttr(z,oVF,'style',12,e,s,gg);var oWF=_ctn("p");_setAttr(z,oWF,'style',4,e,s,gg);var oXF=_o(z,13,e,s,gg);_ac(oWF,oXF);_ac(oVF,oWF);var oYF=_ctn("p");_setAttr(z,oYF,'style',14,e,s,gg);var oZF=_o(z,15,e,s,gg);_ac(oYF,oZF);var oaF=_ctn("span");_setAttr(z,oaF,'style',16,e,s,gg);var obF=_o(z,17,e,s,gg);_ac(oaF,obF);_ac(oYF,oaF);_ac(oVF,oYF);var ocF=_ctn("p");_setAttr(z,ocF,'style',18,e,s,gg);var odF=_o(z,19,e,s,gg);_ac(ocF,odF);_ac(oVF,ocF);var oeF=_ctn("p");_setAttr(z,oeF,'style',18,e,s,gg);var ofF=_o(z,19,e,s,gg);_ac(oeF,ofF);_ac(oVF,oeF);var ogF=_ctn("p");_setAttr(z,ogF,'style',18,e,s,gg);var ohF=_o(z,20,e,s,gg);_ac(ogF,ohF);_ac(oVF,ogF);var oiF=_ctn("p");_setAttr(z,oiF,'style',18,e,s,gg);var ojF=_o(z,21,e,s,gg);_ac(oiF,ojF);_ac(oVF,oiF);var okF=_ctn("p");_setAttr(z,okF,'style',22,e,s,gg);var olF=_o(z,23,e,s,gg);_ac(okF,olF);_ac(oVF,okF);_ac(oFF,oVF);_ac(oEF,oFF);var omF=_ctn("view");_setAttr(z,omF,'style',24,e,s,gg);var onF=_ctn("p");var ooF=_o(z,25,e,s,gg);_ac(onF,ooF);_ac(omF,onF);var opF=_ctn("view");_setAttr(z,opF,'style',26,e,s,gg);var oqF=_setAttrs(z,"image",["src",27,"style",1],e,s,gg);_ac(opF,oqF);var orF=_ctn("view");_setAttr(z,orF,'style',29,e,s,gg);var osF=_ctn("p");_setAttr(z,osF,'style',30,e,s,gg);var otF=_o(z,31,e,s,gg);_ac(osF,otF);_ac(orF,osF);var ouF=_ctn("p");var ovF=_o(z,32,e,s,gg);_ac(ouF,ovF);var owF=_ctn("span");_setAttr(z,owF,'style',33,e,s,gg);var oxF=_o(z,34,e,s,gg);_ac(owF,oxF);_ac(ouF,owF);_ac(orF,ouF);var oyF=_ctn("p");_setAttr(z,oyF,'style',35,e,s,gg);var ozF=_o(z,36,e,s,gg);_ac(oyF,ozF);var o_F=_ctn("span");_setAttr(z,o_F,'style',33,e,s,gg);var oAG=_o(z,34,e,s,gg);_ac(o_F,oAG);_ac(oyF,o_F);_ac(orF,oyF);_ac(opF,orF);_ac(omF,opF);var oBG=_ctn("view");_setAttr(z,oBG,'style',26,e,s,gg);var oCG=_setAttrs(z,"image",["src",27,"style",1],e,s,gg);_ac(oBG,oCG);var oDG=_ctn("view");_setAttr(z,oDG,'style',29,e,s,gg);var oEG=_ctn("p");_setAttr(z,oEG,'style',30,e,s,gg);var oFG=_o(z,31,e,s,gg);_ac(oEG,oFG);_ac(oDG,oEG);var oGG=_ctn("p");var oHG=_o(z,32,e,s,gg);_ac(oGG,oHG);var oIG=_ctn("span");_setAttr(z,oIG,'style',33,e,s,gg);var oJG=_o(z,34,e,s,gg);_ac(oIG,oJG);_ac(oGG,oIG);_ac(oDG,oGG);var oKG=_ctn("p");_setAttr(z,oKG,'style',35,e,s,gg);var oLG=_o(z,36,e,s,gg);_ac(oKG,oLG);var oMG=_ctn("span");_setAttr(z,oMG,'style',33,e,s,gg);var oNG=_o(z,34,e,s,gg);_ac(oMG,oNG);_ac(oKG,oMG);_ac(oDG,oKG);_ac(oBG,oDG);_ac(omF,oBG);var oOG=_ctn("view");_setAttr(z,oOG,'style',26,e,s,gg);var oPG=_setAttrs(z,"image",["src",27,"style",1],e,s,gg);_ac(oOG,oPG);var oQG=_ctn("view");_setAttr(z,oQG,'style',29,e,s,gg);var oRG=_ctn("p");_setAttr(z,oRG,'style',30,e,s,gg);var oSG=_o(z,31,e,s,gg);_ac(oRG,oSG);_ac(oQG,oRG);var oTG=_ctn("p");var oUG=_o(z,32,e,s,gg);_ac(oTG,oUG);var oVG=_ctn("span");_setAttr(z,oVG,'style',33,e,s,gg);var oWG=_o(z,34,e,s,gg);_ac(oVG,oWG);_ac(oTG,oVG);_ac(oQG,oTG);var oXG=_ctn("p");_setAttr(z,oXG,'style',35,e,s,gg);var oYG=_o(z,36,e,s,gg);_ac(oXG,oYG);var oZG=_ctn("span");_setAttr(z,oZG,'style',33,e,s,gg);var oaG=_o(z,34,e,s,gg);_ac(oZG,oaG);_ac(oXG,oZG);_ac(oQG,oXG);_ac(oOG,oQG);_ac(omF,oOG);_ac(oEF,omF);var obG=_ctn("view");_setAttr(z,obG,'style',37,e,s,gg);var ocG=_ctn("div");_setAttr(z,ocG,'style',38,e,s,gg);var odG=_setAttrs(z,"image",["src",39,"style",1],e,s,gg);_ac(ocG,odG);var oeG=_ctn("p");_setAttr(z,oeG,'style',41,e,s,gg);var ofG=_o(z,42,e,s,gg);_ac(oeG,ofG);_ac(ocG,oeG);_ac(obG,ocG);var ogG=_setAttrs(z,"p",["bind:tap",43,"style",1],e,s,gg);var ohG=_o(z,43,e,s,gg);_ac(ogG,ohG);_ac(obG,ogG);_ac(oEF,obG);var oiG=_ctn("view");_setAttr(z,oiG,'style',45,e,s,gg);var ojG=_setAttrs(z,"div",["bind:tap",46,"style",1],e,s,gg);var okG=_setAttrs(z,"image",["src",48,"style",1],e,s,gg);_ac(ojG,okG);var olG=_o(z,46,e,s,gg);_ac(ojG,olG);_ac(oiG,ojG);var omG=_setAttrs(z,"div",["style",47,"bind:tap",3],e,s,gg);var onG=_setAttrs(z,"image",["style",49,"src",2],e,s,gg);_ac(omG,onG);var ooG=_o(z,50,e,s,gg);_ac(omG,ooG);_ac(oiG,omG);var opG=_setAttrs(z,"div",["style",47,"bind:tap",5],e,s,gg);var oqG=_setAttrs(z,"image",["style",49,"src",4],e,s,gg);_ac(opG,oqG);var orG=_o(z,52,e,s,gg);_ac(opG,orG);_ac(oiG,opG);var osG=_setAttrs(z,"div",["style",47,"bind:tap",7],e,s,gg);var otG=_setAttrs(z,"image",["style",49,"src",6],e,s,gg);_ac(osG,otG);var ouG=_o(z,54,e,s,gg);_ac(osG,ouG);_ac(oiG,osG);_ac(oEF,oiG);_ac(r,oEF);
    return r;
  };
  e_["./pages/orderDetail/orderDetail.maml"]={f:m4,j:[],i:[],ti:[],ic:[]};

  d_["./pages/orderHistory/orderHistory.maml"]={};
  var m5=function(e,s,r,gg){
    var z=gz$gma_6()
    var owG=_ctn("view");_setAttr(z,owG,'style',0,e,s,gg);var oxG=_setAttrs(z,"view",["bind:tap",1,"id",1,"style",2],e,s,gg);var oyG=_ctn("view");_setAttr(z,oyG,'style',4,e,s,gg);var ozG=_ctn("p");_setAttr(z,ozG,'style',5,e,s,gg);var o_G=_o(z,6,e,s,gg);_ac(ozG,o_G);_ac(oyG,ozG);var oAH=_ctn("p");_setAttr(z,oAH,'style',5,e,s,gg);var oBH=_o(z,7,e,s,gg);_ac(oAH,oBH);_ac(oyG,oAH);_ac(oxG,oyG);var oCH=_ctn("view");_setAttr(z,oCH,'style',8,e,s,gg);var oDH=_ctn("p");_setAttr(z,oDH,'style',5,e,s,gg);var oEH=_o(z,9,e,s,gg);_ac(oDH,oEH);_ac(oCH,oDH);var oFH=_ctn("p");_setAttr(z,oFH,'style',10,e,s,gg);var oGH=_o(z,11,e,s,gg);_ac(oFH,oGH);_ac(oCH,oFH);_ac(oxG,oCH);_ac(owG,oxG);var oHH=_ctn("view");_setAttr(z,oHH,'style',12,e,s,gg);var oIH=_setAttrs(z,"div",["bind:tap",13,"style",1],e,s,gg);var oJH=_setAttrs(z,"image",["src",15,"style",1],e,s,gg);_ac(oIH,oJH);var oKH=_o(z,13,e,s,gg);_ac(oIH,oKH);_ac(oHH,oIH);var oLH=_setAttrs(z,"div",["style",14,"bind:tap",3],e,s,gg);var oMH=_setAttrs(z,"image",["style",16,"src",2],e,s,gg);_ac(oLH,oMH);var oNH=_o(z,17,e,s,gg);_ac(oLH,oNH);_ac(oHH,oLH);var oOH=_setAttrs(z,"div",["style",14,"bind:tap",5],e,s,gg);var oPH=_setAttrs(z,"image",["style",16,"src",4],e,s,gg);_ac(oOH,oPH);var oQH=_o(z,19,e,s,gg);_ac(oOH,oQH);_ac(oHH,oOH);var oRH=_setAttrs(z,"div",["style",14,"bind:tap",7],e,s,gg);var oSH=_setAttrs(z,"image",["style",16,"src",6],e,s,gg);_ac(oRH,oSH);var oTH=_o(z,21,e,s,gg);_ac(oRH,oTH);_ac(oHH,oRH);_ac(owG,oHH);_ac(r,owG);
    return r;
  };
  e_["./pages/orderHistory/orderHistory.maml"]={f:m5,j:[],i:[],ti:[],ic:[]};

  d_["./pages/products/products.maml"]={};
  var m6=function(e,s,r,gg){
    var z=gz$gma_7()
    var oVH=_ctn("view");var oWH=_ctn("view");_setAttr(z,oWH,'style',0,e,s,gg);var oXH=_setAttrs(z,"image",["src",1,"style",1],e,s,gg);_ac(oWH,oXH);var oYH=_ctn("view");_setAttr(z,oYH,'style',3,e,s,gg);var oZH=_setAttrs(z,"input",["placeholder",4,"style",1,"type",2],e,s,gg);_ac(oYH,oZH);var oaH=_setAttrs(z,"image",["src",7,"style",1],e,s,gg);_ac(oYH,oaH);_ac(oWH,oYH);_ac(oVH,oWH);var obH=_ctn("p");_setAttr(z,obH,'style',9,e,s,gg);var ocH=_o(z,10,e,s,gg);_ac(obH,ocH);_ac(oVH,obH);var odH=_ctn("view");_setAttr(z,odH,'style',11,e,s,gg);var oeH=_ctn("view");_setAttr(z,oeH,'style',12,e,s,gg);var ofH=_setAttrs(z,"image",["bind:tap",13,"src",1,"style",2],e,s,gg);_ac(oeH,ofH);var ogH=_ctn("p");_setAttr(z,ogH,'style',16,e,s,gg);var ohH=_o(z,17,e,s,gg);_ac(ogH,ohH);_ac(oeH,ogH);var oiH=_ctn("p");_setAttr(z,oiH,'style',18,e,s,gg);var ojH=_o(z,19,e,s,gg);_ac(oiH,ojH);var okH=_ctn("span");_setAttr(z,okH,'style',20,e,s,gg);var olH=_o(z,21,e,s,gg);_ac(okH,olH);_ac(oiH,okH);_ac(oeH,oiH);var omH=_ctn("view");_setAttr(z,omH,'style',22,e,s,gg);var onH=_ctn("p");_setAttr(z,onH,'style',23,e,s,gg);var ooH=_o(z,24,e,s,gg);_ac(onH,ooH);_ac(omH,onH);var opH=_setAttrs(z,"image",["src",25,"style",1],e,s,gg);_ac(omH,opH);var oqH=_setAttrs(z,"image",["src",27,"style",1],e,s,gg);_ac(omH,oqH);_ac(oeH,omH);_ac(odH,oeH);var orH=_ctn("view");_setAttr(z,orH,'style',12,e,s,gg);var osH=_setAttrs(z,"image",["src",14,"style",1],e,s,gg);_ac(orH,osH);var otH=_ctn("p");_setAttr(z,otH,'style',16,e,s,gg);var ouH=_o(z,17,e,s,gg);_ac(otH,ouH);_ac(orH,otH);var ovH=_ctn("p");_setAttr(z,ovH,'style',18,e,s,gg);var owH=_o(z,19,e,s,gg);_ac(ovH,owH);var oxH=_ctn("span");_setAttr(z,oxH,'style',20,e,s,gg);var oyH=_o(z,21,e,s,gg);_ac(oxH,oyH);_ac(ovH,oxH);_ac(orH,ovH);var ozH=_ctn("view");_setAttr(z,ozH,'style',22,e,s,gg);var o_H=_ctn("p");_setAttr(z,o_H,'style',23,e,s,gg);var oAI=_o(z,24,e,s,gg);_ac(o_H,oAI);_ac(ozH,o_H);var oBI=_setAttrs(z,"image",["src",25,"style",1],e,s,gg);_ac(ozH,oBI);var oCI=_setAttrs(z,"image",["src",27,"style",1],e,s,gg);_ac(ozH,oCI);_ac(orH,ozH);_ac(odH,orH);_ac(oVH,odH);var oDI=_ctn("view");_setAttr(z,oDI,'style',29,e,s,gg);var oEI=_setAttrs(z,"div",["bind:tap",30,"style",1],e,s,gg);var oFI=_setAttrs(z,"image",["src",32,"style",1],e,s,gg);_ac(oEI,oFI);var oGI=_o(z,30,e,s,gg);_ac(oEI,oGI);_ac(oDI,oEI);var oHI=_setAttrs(z,"div",["style",31,"bind:tap",3],e,s,gg);var oII=_setAttrs(z,"image",["src",27,"style",6],e,s,gg);_ac(oHI,oII);var oJI=_o(z,34,e,s,gg);_ac(oHI,oJI);_ac(oDI,oHI);var oKI=_setAttrs(z,"div",["style",31,"bind:tap",4],e,s,gg);var oLI=_setAttrs(z,"image",["style",33,"src",3],e,s,gg);_ac(oKI,oLI);var oMI=_o(z,35,e,s,gg);_ac(oKI,oMI);_ac(oDI,oKI);var oNI=_setAttrs(z,"div",["style",31,"bind:tap",6],e,s,gg);var oOI=_setAttrs(z,"image",["style",33,"src",5],e,s,gg);_ac(oNI,oOI);var oPI=_o(z,37,e,s,gg);_ac(oNI,oPI);_ac(oDI,oNI);_ac(oVH,oDI);_ac(r,oVH);
    return r;
  };
  e_["./pages/products/products.maml"]={f:m6,j:[],i:[],ti:[],ic:[]};

  d_["./pages/reciept/reciept.maml"]={};
  var m7=function(e,s,r,gg){
    var z=gz$gma_8()
    var oRI=_ctn("view");var oSI=_ctn("view");_setAttr(z,oSI,'style',0,e,s,gg);var oTI=_setAttrs(z,"image",["src",1,"style",1],e,s,gg);_ac(oSI,oTI);var oUI=_ctn("p");_setAttr(z,oUI,'style',3,e,s,gg);var oVI=_o(z,4,e,s,gg);_ac(oUI,oVI);_ac(oSI,oUI);_ac(oRI,oSI);var oWI=_setAttrs(z,"view",["id",5,"style",1],e,s,gg);var oXI=_ctn("view");_setAttr(z,oXI,'style',7,e,s,gg);var oYI=_ctn("p");_setAttr(z,oYI,'style',8,e,s,gg);var oZI=_o(z,9,e,s,gg);_ac(oYI,oZI);_ac(oXI,oYI);var oaI=_ctn("p");_setAttr(z,oaI,'style',8,e,s,gg);var obI=_o(z,10,e,s,gg);_ac(oaI,obI);_ac(oXI,oaI);var ocI=_ctn("p");_setAttr(z,ocI,'style',8,e,s,gg);var odI=_o(z,11,e,s,gg);_ac(ocI,odI);_ac(oXI,ocI);var oeI=_ctn("p");_setAttr(z,oeI,'style',8,e,s,gg);var ofI=_o(z,12,e,s,gg);_ac(oeI,ofI);_ac(oXI,oeI);var ogI=_ctn("p");_setAttr(z,ogI,'style',8,e,s,gg);var ohI=_o(z,13,e,s,gg);_ac(ogI,ohI);_ac(oXI,ogI);var oiI=_ctn("p");_setAttr(z,oiI,'style',8,e,s,gg);var ojI=_o(z,14,e,s,gg);_ac(oiI,ojI);_ac(oXI,oiI);_ac(oWI,oXI);var okI=_ctn("view");_setAttr(z,okI,'style',15,e,s,gg);var olI=_ctn("p");_setAttr(z,olI,'style',8,e,s,gg);var omI=_o(z,16,e,s,gg);_ac(olI,omI);_ac(okI,olI);var onI=_ctn("p");_setAttr(z,onI,'style',17,e,s,gg);var ooI=_o(z,18,e,s,gg);_ac(onI,ooI);var opI=_ctn("span");_setAttr(z,opI,'style',19,e,s,gg);var oqI=_o(z,20,e,s,gg);_ac(opI,oqI);_ac(onI,opI);_ac(okI,onI);var orI=_ctn("p");_setAttr(z,orI,'style',21,e,s,gg);var osI=_o(z,22,e,s,gg);_ac(orI,osI);_ac(okI,orI);var otI=_ctn("p");_setAttr(z,otI,'style',21,e,s,gg);var ouI=_o(z,22,e,s,gg);_ac(otI,ouI);_ac(okI,otI);var ovI=_ctn("p");_setAttr(z,ovI,'style',21,e,s,gg);var owI=_o(z,23,e,s,gg);_ac(ovI,owI);_ac(okI,ovI);var oxI=_ctn("p");_setAttr(z,oxI,'style',21,e,s,gg);var oyI=_o(z,24,e,s,gg);_ac(oxI,oyI);_ac(okI,oxI);_ac(oWI,okI);_ac(oRI,oWI);_ac(r,oRI);
    return r;
  };
  e_["./pages/reciept/reciept.maml"]={f:m7,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

var BASE_DEVICE_WIDTH=750;
var deviceWidth=window.screen.width||375;
var isIOS=navigator.userAgent.match("iPhone");
var deviceDPR=window.devicePixelRatio||2;
var checkDeviceWidth=window.__checkDeviceWidth__||function(){
  var newDeviceDPR=window.devicePixelRatio||2
  var newDeviceWidth=window.screen.width||375
  var newDeviceHeight=window.screen.height||375
  if(window.screen.orientation&&/^landscape/.test(window.screen.orientation.type||''))newDeviceWidth=newDeviceHeight
  if(newDeviceWidth!==deviceWidth||newDeviceDPR!==deviceDPR){
    deviceDPR=newDeviceDPR
    deviceWidth=newDeviceWidth
  }
}
checkDeviceWidth()
var eps=1e-4;
var transformRPX=window.__transformRpx__||function(number,newDeviceWidth){
  if(number===0)return 0;
  number=number/BASE_DEVICE_WIDTH*(newDeviceWidth||deviceWidth);
  number=Math.floor(number+eps);
  if(number===0){
    if(deviceDPR===1||!isIOS)return 1;
    else return 0.5;
  }
  return number;
}
var __COMMON_STYLESHEETS__=__COMMON_STYLESHEETS__||{}


var setCssToHead=function(file,info){
  var importedStyles={},info=info||{};
  function makeup(file,opt){
    var isPath=typeof(file)==="string";
    if(isPath&&importedStyles.hasOwnProperty(file))return "";
    if(isPath)importedStyles[file]=1;
    var contents=isPath?__COMMON_STYLESHEETS__[file]:file,res="";
    for(var i=contents.length-1;i>=0;i--){
      var content=contents[i];
      if(typeof(content)==="object"){
        var op=content[0];
        if(op===0)res=transformRPX(content[1],opt.deviceWidth)+"px"+res; // rpx
        else if(op===1)res=opt.suffix+res; // suffix
        else if(op===2)res=makeup(content[1],opt)+res; // import at the top
        else if(op===3)res=makeup(content[1],opt)+res; // import not at the top
      }else{
        res=content+res;
      }
    }
    return res;
  }
  var rewritor=function(suffix,opt,style,tFile,tInfo){
    opt=opt||{};
    suffix=suffix||"";
    opt.suffix=suffix;
    tFile=tFile||file;
    tInfo=tInfo||info;
    css=makeup(tFile,opt);
    if(!css)return;
    
    if(!style){
      var head=document.head||document.getElementsByTagName('head')[0];
      style=document.createElement('style');
      style.type='text/css';
      style.setAttribute("mass:path",tInfo.path);
      head.appendChild(style);
    }
    if(style.childNodes.length==0)style.appendChild(document.createTextNode(css));
    else style.childNodes[0].nodeValue=css;
  }
  return rewritor;
}
__maAppCode__['app.json']={"window":{"backgroundTextStyle":"light","navigationBarBackgroundColor":"#fff","navigationBarTitleText":"Macle","navigationBarTextStyle":"black","capsuleTheme":"light"}};

__maAppCode__['pages/cart/cart.json']={"navigationBarTitleText":"","usingComponents":{}};
__maAppCode__['pages/checkout/checkout.json']={"navigationBarTitleText":"","usingComponents":{}};
__maAppCode__['pages/detail/detail.json']={"navigationBarTitleText":"","usingComponents":{}};
__maAppCode__['pages/Home/Home.json']={"usingComponents":{}};
__maAppCode__['pages/orderDetail/orderDetail.json']={"usingComponents":{}};
__maAppCode__['pages/orderHistory/orderHistory.json']={"usingComponents":{}};
__maAppCode__['pages/products/products.json']={"navigationBarTitleText":"","usingComponents":{}};
__maAppCode__['pages/reciept/reciept.json']={"navigationBarTitleText":"","usingComponents":{}};

setCssToHead([".",[1],"container{-webkit-align-items:center;align-items:center;background-color:#fff;box-sizing:border-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100%;-webkit-justify-content:space-between;justify-content:space-between;padding:",[0,100]," 0}"],{path:"./app.mass"})();
__maAppCode__['pages/cart/cart.mass']=setCssToHead([""],{path:"./pages/cart/cart.mass"});
__maAppCode__['pages/checkout/checkout.mass']=setCssToHead([""],{path:"./pages/checkout/checkout.mass"});
__maAppCode__['pages/detail/detail.mass']=setCssToHead([""],{path:"./pages/detail/detail.mass"});
__maAppCode__['pages/Home/Home.mass']=setCssToHead([""],{path:"./pages/Home/Home.mass"});
__maAppCode__['pages/orderDetail/orderDetail.mass']=setCssToHead([""],{path:"./pages/orderDetail/orderDetail.mass"});
__maAppCode__['pages/orderHistory/orderHistory.mass']=setCssToHead([""],{path:"./pages/orderHistory/orderHistory.mass"});
__maAppCode__['pages/products/products.mass']=setCssToHead([""],{path:"./pages/products/products.mass"});
__maAppCode__['pages/reciept/reciept.mass']=setCssToHead([""],{path:"./pages/reciept/reciept.mass"});
__maAppCode__['pages/cart/cart.maml']=$gma('./pages/cart/cart.maml');
__maAppCode__['pages/checkout/checkout.maml']=$gma('./pages/checkout/checkout.maml');
__maAppCode__['pages/detail/detail.maml']=$gma('./pages/detail/detail.maml');
__maAppCode__['pages/Home/Home.maml']=$gma('./pages/Home/Home.maml');
__maAppCode__['pages/orderDetail/orderDetail.maml']=$gma('./pages/orderDetail/orderDetail.maml');
__maAppCode__['pages/orderHistory/orderHistory.maml']=$gma('./pages/orderHistory/orderHistory.maml');
__maAppCode__['pages/products/products.maml']=$gma('./pages/products/products.maml');
__maAppCode__['pages/reciept/reciept.maml']=$gma('./pages/reciept/reciept.maml');

__mainPageFrameReady__();
var __pageFrameEndTime__=Date.now();
